# Mild form of aromatic L-amino acid decarboxylase deficiency

Metadata: pmid=42648782; pmcid=PMC13535655; doi=10.1136/bcr-2025-269867; journal=BMJ Case Reports; year=2026; license=This is an open access article distributed in accordance with the Creative Commons Attribution Non Commercial (CC BY-NC ; tier=epmc

## Abstract [abstract]
Aromatic L-amino acid decarboxylase (AADC) deficiency (Online Mendelian Inheritance in Man #608643) is a rare autosomal recessive neurometabolic disorder caused by pathogenic variants in the DDC gene, leading to impaired enzyme activity. Affected individuals typically develop symptoms in early infancy, including truncal hypotonia, global developmental delay and oculogyric crises, and the condition is generally associated with a severe clinical course and poor prognosis. We report a patient with a mild and atypical phenotype of AADC deficiency complicated by sensorineural hearing loss and oculocutaneous albinism. The clinical course and response to treatment are described. This unusual presentation raises the possibility of coexisting conditions contributing to the phenotype. This case highlights the clinical variability of AADC deficiency and underscores the importance of comprehensive genetic and biochemical investigations to achieve an accurate diagnosis and inform personalised management.

## Background [sec:1]

[sec:1 ¶1] Aromatic L-amino acid decarboxylase (AADC) is the enzyme that catalyses the synthesis of serotonin and catecholamines using pyridoxal phosphate as a cofactor.1 AADC deficiency (Online Mendelian Inheritance in Man #608643) is an autosomal recessive neurometabolic disorder caused by genetic variants affecting protein function in the DDC gene (dopa decarboxylase).2 The biochemical characteristics of the disorder are low levels of catecholamines and serotonin, as well as increased metabolites upstream of the metabolic block, such as L-Dopa, 3-O-methyl-L-dopa, vanillylactic acid and 5-hydroxytryptophan.2

[sec:1 ¶2] Most patients exhibit early-onset truncal hypotonia, global developmental delay and oculogyric crises, consistent with a severe neurometabolic disorder characterised by a poor prognosis. As the condition progresses, ptosis, dystonia and autonomic dysfunction may emerge.3 More recently, a milder phenotype of AADC deficiency has been recognised, typically marked by predominant autonomic symptoms, mild motor delay and mild intellectual disability, often with a non-progressive clinical course.3–9

[sec:1 ¶3] In this report, we describe a case of mild atypical AADC deficiency associated with sensorineural hearing loss and oculocutaneous albinism, outlining the natural disease course and treatment outcomes.

## Case presentation [sec:2]

[sec:2 ¶1] The patient is a man in his early 30s. He was first seen in a medical genetics clinic in middle childhood. He had ptosis and underwent seven eyelid surgeries, the last of which involved eyelid shortening. He had a fair complexion, mild bilateral sensorineural deafness, generalised muscle weakness, muscle atrophy and normal reflexes, as well as chronic malabsorption with alternating diarrhoea and constipation. Generalised muscular weakness significantly limited his participation in physical activities at school. Electromyography showed a generalised myogenic pattern. According to his parents’ records, he began walking at the age of 1.5 years, with otherwise normal motor development but with severe gastrointestinal problems in childhood. An investigation of mitochondrial pathology was initiated, including complete mitochondrial DNA (mtDNA) sequencing and analysis of copy number variants, both of which were negative.

[sec:2 ¶2] The patient’s next visit to the genetics clinic occurred at the age of 26 years because of progressive muscle weakness. At that time, gastrointestinal symptoms persisted and were characterised by frequent bowel movements of up to 15 episodes per day. His body mass index remained below the normal range at 17.5 kg/m².

[sec:2 ¶3] Whole exome sequencing (WES) was performed, and three genetic disorders were identified. Autosomal recessive deafness type 1A (DFNB1A) was confirmed by two well-known pathogenic compound heterozygous variants, c.35del, p.(Gly12Valfs*2), and c.101T>C, p.(Met34Thr), in the GJB2 gene (NM_004004.5) in trans.

[sec:2 ¶4] A known heterozygous pathogenic variant, c.650G>A, p.(Arg217Gln), in the TYR gene (NM_000372.4) was found together with the heterozygous risk allele c.1205G>A, p.(Arg402Gln) in trans, thereby establishing the diagnosis of type IB oculocutaneous albinism.

[sec:2 ¶5] Finally, the homozygous variant c.476C>T, p.(Ala159Val), initially classified as a variant of uncertain significance in the DDC gene (NM_000790.3), prompted further biochemical investigations for AADC deficiency. The level of 3-O-methyl-L-dopa in a dried blood spot was elevated to 3000 nmol/L (reference range <1000 nmol/L).

[sec:2 ¶6] The DDC variant c.476C>T is reported in ClinVar10 as a variant of uncertain significance. However, its frequency in gnomAD exomes is 0.0000117 in the European (non-Finnish) population,11 and no homozygous individuals have been reported. The Combined Annotation Dependent Depletion Phred score is 26.20,12 and multiple in silico prediction tools indicate a damaging, high-impact missense variant with a high conservation score (8.995) in vertebrates.13 The American College of Medical Genetics and Genomics classification allowed reclassification of the variant as likely pathogenic using the following criteria: PM1 (the variant lies within a helical region of the UniProt entity DDC_HUMAN containing four pathogenic changes and no benign changes), PM2 (very rare variant in population databases, with high coverage), and PP3 (MetaRNN computational evidence supports a deleterious effect; score 0.881).14

[sec:2 ¶7] The diagnosis of AADC deficiency was therefore confirmed, and treatment was initiated with vitamin B6 at 100 mg/day together with folic acid 5000 µg/day.

## Outcome and follow-up [sec:3]

[sec:3 ¶1] At his last visit, the patient was in his early 30s and reported improvement in his condition. At the time of examination, he reported three to four bowel movements per day. His body mass index was 24.4 kg/m². He remains on a daily regimen of vitamin B6 100 mg and folic acid 5000 µg. Neurological examination revealed a full range of eye movements with symmetrical pupils and corrected ptosis; the tongue was midline. Facial expression muscles exhibited full strength (5/5). The upper extremities (all muscle groups) showed full strength (5/5 by Medical Research Council scale) with elicitable tendon reflexes. The lower extremities (all muscle groups) also exhibited full strength (5/5 by Medical Research Council scale) with elicitable tendon reflexes. The patient had pes cavus deformity of the feet figure 1.

## Discussion [sec:4]

[sec:4 ¶1] The phenotypic spectrum of AADC deficiency is broad, ranging from severe to mild presentations. Our patient demonstrates a milder phenotype compared with other reported cases of AADC deficiency, which are typically associated with more severe neurological symptoms from early childhood. A similar presentation was previously described in a girl who had recurrent episodes of hypoglycaemia, diarrhoea and mild dyspraxia. She showed a good response to pyridoxine. Most other reported patients with mild AADC deficiency developed significant neurological sequelae table 1.

[sec:4 ¶2] Several factors may explain this variability in disease severity. A key determinant is the residual activity of the AADC enzyme. In cases where the enzyme retains some functionality, the phenotype tends to be milder. For example, a study found that heterozygous mutations resulting in heterodimeric AADC proteins with partially retained catalytic efficiency can lead to milder symptoms.15

[sec:4 ¶3] A structured differential diagnosis in this patient included mitochondrial disorders, congenital myopathies, congenital myasthenic syndromes and neurotransmitter defects. Based on the patient’s symptoms, the primary working hypothesis until the age of 26 years was a mitochondrial disorder. Initial symptoms of bilateral ptosis, sensorineural deafness and muscle weakness are commonly seen in mitochondrial disorders such as progressive external ophthalmoplegia and Kearns–Sayre syndrome. These disorders are characterised by ptosis, muscle weakness, tremor, ataxia and endocrine dysfunction. Additionally, patients with Kearns–Sayre syndrome may have pigmentary retinopathy and cardiac conduction defects. Both conditions show a broad clinical spectrum. The aetiology of these mitochondrial disorders includes large mitochondrial DNA deletions, single-nucleotide variants in mtDNA, and pathogenic variants in nuclear genes such as RRM2B, POLG and C10ORF2.16

[sec:4 ¶4] An mtDNA sequencing was subsequently performed on blood samples as part of a research protocol and yielded negative results. Importantly, these investigations do not definitively exclude mitochondrial disease, because mitochondrial disorders may result from both mtDNA and nuclear DNA variants, and blood-based testing may miss tissue-specific abnormalities. For further investigation, clinicians considered either muscle biopsy for mtDNA analysis or WES. Given that WES is less invasive while providing a comparable turnaround time, it was selected as the initial diagnostic approach.

[sec:4 ¶5] WES enabled comprehensive characterisation of the patient’s phenotype through the identification of three distinct genetic conditions that had not previously been suspected. The first diagnosis, AADC deficiency (OMIM #608643), explains the patient’s ptosis, poor feeding, diarrhoea, constipation, truncal hypotonia, generalised muscle weakness and muscle atrophy. The second condition, autosomal recessive deafness type 1A (DFNB1A, OMIM #220290), corresponds to the patient’s sensorineural hearing loss. Finally, the third identified disorder, oculocutaneous albinism type IB (OMIM #606952), accounts for the reduced skin pigmentation and fair complexion.

[sec:4 ¶6] The identification of autosomal recessive deafness type 1A revised the initial impression of a single mitochondrial disorder. The additional finding of a homozygous DDC variant further supported a multi-aetiological explanation for the patient’s phenotype and accounted for the remaining clinical features. Additionally, 3-O-methyldopa was elevated to 3000 nmol/L (reference range <1000 nmol/L), which is a biochemical hallmark of AADC deficiency and provides evidence of impaired decarboxylation of L-Dopa, consistent with a functional AADC deficit.

[sec:4 ¶7] The complex phenotype may also reflect the coexistence of two disorders affecting tyrosine metabolism. Partial tyrosinase deficiency in oculocutaneous albinism and AADC deficiency did not result in a more severe disease form in this patient. The absence of obvious additive clinical severity may be explained by differential tissue expression of the affected enzymes. Tyrosinase is expressed mainly in the skin, whereas dopa decarboxylase is predominantly expressed in the intestines, kidney, adrenal gland and brain (GTEx, 2024).

[sec:4 ¶8] Effective treatment regimens, including pyridoxine (B6), folinic acid and monoamine oxidase inhibitors, have significantly improved symptoms in patients with milder phenotypes. Early and targeted treatment can improve motor and functional outcomes.17 In our patient, pyridoxine monotherapy was associated with substantial clinical improvement, including reduced gastrointestinal symptoms, increased muscle strength and improved quality of life.

### Table Table 1 [tab:1]
Clinical presentation comparison between patients with mild AADC deficiency
| r1 |  | Current study | Arnoux et al6 | Hasegawa et al4 |  | Leuzzi et al5 |  | Tay et al9 |  |
|---|---|---|---|---|---|---|---|---|---|
| r2 | Patient 1 | Patient 1 | Patient 1 | Patient 2 | Patient 1 | Patient 2 | Patient 1 | Patient 2 |  |
| r3 | Genotype | Homozygous c.476C>T | c.1385G>C and c.97G>C | c.202G>A and c.254C>T |  | c.105delC and c.710T>C |  | c.853C>T and c.714+4A>T |  |
| r4 | Motor development delay/hypotonia | – | – | + | + | + | + | + | + |
| r5 | Speech delay | – | – | + | + | + | + | – | + |
| r6 | Cognitive impairment | – | – | + | + | + | + | + | + |
| r7 | Ptosis | + | – | + | + | + | + | + | + |
| r8 | Diarrhoea/obstipation | + | + | – | – | – | – | – | – |
| r9 | Oculogyric crisis |  | – | + | + | + | + | + | + |
| r10 | Dystonia |  |  |  |  |  |  | + | + |
| r11 | Low glucose |  | + | – | – | ND | ND | ND | ND |
| r12 | 3-OMD | 3× | ND | 8× | 11× | 10× | 6× | 3× |  |
| r13 | AADC activity |  | 25% from reference | ND |  | Undetectable |  | Undetectable |  |
| r14 | Vitamin B6 | 100 mg/day | 30 mg/kg/day | 20 mg/kg/day |  | 5 mg/kg/day |  | 5 mg/kg/day |  |
| r15 | Selegiline |  |  | 0.1–0.125 mg/kg/day |  |  |  | 10 mg/day |  |
| r16 | Rotigotine |  |  |  |  | 6 mg/day |  |  |  |
| r17 | Escitalopram |  |  |  |  | 200 mg/day |  |  |  |
| r18 | Bromocriptine |  |  |  |  |  |  | 10 mg/day |  |
Footnotes: AADC, aromatic L-amino acid decarboxylase; 3-OMD, 3-O-Methyldopa.

Figure Figure 1: Clinical appearance of the patient showing overall normal body habitus and mild foot deformity (pes cavus).