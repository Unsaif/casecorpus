# PMID_42309774_her_younger_brother
**Source:** PMID 42309774 · Journal of atherosclerosis and thrombosis 2026 · DOI 10.5551/jat.66218 · licence: None · tier: epmc
**Individual:** her younger brother · sex MALE · onset – · presentation – · last follow-up – · UNKNOWN
**Evidence verification:** 2/2 quotes found in their anchored unit, 2/2 anywhere in the document; narrative source: extractor

## Patient description (verbatim from the source, by anchor)

> **[sec:5 ¶5]** Her younger brother had experienced marked hypertriglyceridemia with recurrent episodes of acute pancreatitis. Other family members—including her parents, younger sister, two daughters, and the son of her hypertriglyceridemic brother—had no history of hypertriglyceridemia or pancreatitis. Her two daughters were unmarried, had never experienced pregnancy, and had normal TG levels. There was no family history of diabetes mellitus. The patient reported a history of consanguineous marriage in her family; however, the details were unclear.
>
> **[sec:13 ¶1]** This case report is based solely on findings from the index proband. We were unable to perform biochemical and genetic analyses in her brother, who had a history of marked hypertriglyceridemia and recurrent acute pancreatitis. Information regarding dietary habits was obtained through an interview conducted by a registered dietitian and may therefore be subject to recall bias. In addition, the therapeutic efficacy of pemafibrate in chylomicronemia requires confirmation in larger cohorts of patients with genetically confirmed FCS.
>

## Diagnoses


## Genetic findings


## Measurements

| ✓ | analyte | specimen | value | unit | ref | interp | timing | quote [anchor] |
|---|---|---|---|---|---|---|---|---|

## Phenotypes

- ✓ Hypertriglyceridemia → Hypertriglyceridemia HP:0002155 (grounded)  
  “Her younger brother had experienced marked hypertriglyceridemia with recurrent episodes of acute pancreatitis.” [sec:5 ¶5]
- ✓ Acute pancreatitis → Acute pancreatitis HP:0001735 (grounded)  
  “Her younger brother had experienced marked hypertriglyceridemia with recurrent episodes of acute pancreatitis.” [sec:5 ¶5]

## Model summary (not source text)

The younger brother of the index proband is reported to have had marked hypertriglyceridemia with recurrent episodes of acute pancreatitis. No biochemical or genetic analyses could be performed in him, and no age, treatment or laboratory values are given. His son had no history of hypertriglyceridemia or pancreatitis.

## Extractor notes

- The paper gives no diagnosis for the brother; the authors only state that he had marked hypertriglyceridemia with recurrent acute pancreatitis and that biochemical and genetic analyses could not be performed in him (sec:13 ¶1: 'We were unable to perform biochemical and genetic analyses in her brother'). No FINAL diagnosis is therefore recorded.
- No age, sex-specific details beyond 'brother', dates, values or treatments are reported for this individual.
- Consanguinity is set from the proband's statement of a history of consanguineous marriage in the family (sec:5 ¶5); details were unclear.