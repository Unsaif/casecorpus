# PMID_42309774_the_patient
**Source:** PMID 42309774 · Journal of atherosclerosis and thrombosis 2026 · DOI 10.5551/jat.66218 · licence: None · tier: epmc
**Individual:** the patient · sex FEMALE · onset ? (infancy) · presentation P47Y (47 years of age) · last follow-up ? (follow-up after discharge from the index hospitalization at 47 years; duration not stated) · ALIVE
**Evidence verification:** 66/99 quotes found in their anchored unit, 99/99 anywhere in the document; narrative source: extractor

## Patient description (verbatim from the source, by anchor)

> **[abstract]** Aim: Familial chylomicronemia syndrome (FCS) is a rare disorder characterized by the accumulation of chylomicrons in the circulation due to genetic defects or autoantibodies affecting lipoprotein lipase (LPL), the key enzyme responsible for the metabolism of chylomicrons and very-low-density lipoproteins (VLDL), or its associated proteins, including apolipoprotein (apo) C-II, apoA-V, glycosylphosphatidylinositol-anchored high-density lipoprotein-binding protein 1 (GPIHBP1), and lipase maturation factor 1 (LMF1). This condition is associated with markedly elevated serum triglyceride (TG) levels and, in severe cases, recurrent episodes of pancreatitis and eruptive xanthomas. Among these etiologies, genetic deficiency of GPIHBP1 is exceedingly rare. We aimed to clarify the clinical and genetic basis and treatment strategies of a patient with GPIHBP1 deficiency. Methods: A 47-year-old woman with a childhood diagnosis of FCS presented with severe epigastric pain and was admitted to Rinku General Medical Center for emergency management of acute pancreatitis secondary to severe chylomicronemia. She had a history of severe hypertriglyceridemia complicated by pancreatitis during her first pregnancy and extreme hypertriglyceridemia exceeding 6,000 mg/dL during her second pregnancy without the development of pancreatitis. DNA sequence analysis was performed as a clinical diagnostic test and outsourced to KUBIX Inc. (Hakusan, Ishikawa, Japan). Results: Laboratory evaluation revealed marked hypertriglyceridemia (1,262 mg/dL) with a type V hyperlipoproteinemia pattern. Serum preheparin LPL mass was markedly reduced, and circulating GPIHBP1 was undetectable. Genetic analysis identified a novel homozygous frameshift mutation in theGPIHBP1 gene (NM_178172.4:c.20del [p.Val7AlafsTer73]), which has not been previously reported in public databases. No pathogenic variants were detected in other LPL-related genes. Acute pancreatitis improved rapidly with fasting and intravenous fluid therapy. Strict dietary fat restriction, followed by the addition of the selective PPARα modulator pemafibrate, successfully maintained TG levels below 500 mg/dL during follow-up. Conclusion: We report an extremely rare case of FCS caused by a novel homozygous mutation in theGPIHBP1 gene, in which pregnancy served as a major trigger for severe hypertriglyceridemia. Early diagnosis and strict lipid control are essential to prevent recurrent pancreatitis in patients with GPIHBP1 deficiency.
>
> **[sec:1 ¶9]** In the present study, we describe an extremely rare case of FCS caused by a novel homozygous mutation in the GPIHBP1 gene, in which pregnancy served as a major trigger for severe hypertriglyceridemia. Strict dietary fat restriction combined with treatment using the selective PPARα modulator pemafibrate effectively reduced serum TG levels.
>
> **[sec:3 ¶1]** The patient was clinically evaluated at Rinku General Medical Center. Written informed consent was obtained for genetic testing, and verbal informed consent was obtained for publication of this case report.
>
> **[sec:3 ¶2]** Serum lipids, apolipoproteins, and lipoproteins were measured as previously described 11) . The LPL mass was determined in preheparin plasma using a sandwich enzyme-linked immunosorbent assay (ELISA) 12) . Serum levels of apoA-V and GPIHBP1 were measured using previously described ELISA methods 13 - 14) .
>
> **[sec:4 ¶1]** DNA sequence analysis was performed as a clinical diagnostic test and outsourced to KUBIX Inc. (Hakusan, Ishikawa, Japan). Sequencing was conducted as previously described with minor modifications 15) . Genomic DNA extracted from the patient’s peripheral blood leukocytes was used to construct sequencing libraries using the KAPA Library Preparation System. A custom target enrichment panel was designed to capture all exons of 21 Mendelian genes associated with dyslipidemia, encompassing 14 distinct dyslipidemia-related disorders, including LPL, apoC-II, apoA-V, GPIHBP1, and LMF1.
>
> **[sec:4 ¶2]** Target-enriched libraries were subjected to next-generation sequencing on the iSeq 100 platform (Illumina, San Diego, CA, USA). Paired-end reads were aligned to the human reference genome (GRCh38) using the Burrows–Wheeler Aligner (BWA) with the BWA-MEM algorithm. Variant calling was performed using GATK HaplotypeCaller.
>
> **[sec:5 ¶1]** The patient had been diagnosed with primary chylomicronemia at a university hospital during infancy and was followed until preschool age, during which she was managed solely with dietary fat restriction. At 23 years of age, during her first pregnancy, she developed severe hypertriglyceridemia complicated by acute pancreatitis, requiring hospitalization. During her second pregnancy at 29 years of age, serum TG levels exceeded 6,000 mg/dL; however, she delivered without developing pancreatitis and subsequently discontinued outpatient follow-up.
>
> **[sec:5 ¶2]** At 47 years of age, she was emergently transported to the Emergency Department of Rinku General Medical Center with severe epigastric pain. Based on markedly elevated pancreatic amylase levels, she was diagnosed with acute pancreatitis and admitted to the Department of Gastroenterology. She was subsequently referred to the Department of Diabetes, Endocrinology and Metabolism for further evaluation of severe hypertriglyceridemia.
>
> **[sec:5 ¶3]** In a dietary interview, her breakfast typically consisted of one slice of white bread with margarine and sweet toppings, along with coffee with milk, and occasionally fruit. Lunch was usually a boxed meal including a small portion of omelet, two frozen food items, vegetables, and sometimes okonomiyaki. Dinner always included rice and miso soup, with mainly chicken or pork dishes, and occasional fish. Side dishes included various stir-fried or simmered foods. She also consumed snacks such as rice crackers, chocolate, and ice cream, and drank coffee, tea, and other beverages. When eating out, she chose foods such as pizza, pasta, sushi, ramen, and yakiniku. Four days prior to the onset of abdominal pain, she had consumed approximately five to six pieces of grilled beef (yakiniku). Three days prior, she ate several servings of lettuce-wrapped pork. Two days before admission, she consumed four skewers of grilled chicken (yakitori), and on the day before hospitalization, she ate hotpot containing chicken.
>
> **[sec:5 ¶4]** She did not consume alcohol and had never smoked. She was not receiving any lipid-lowering therapy and was taking medication only intermittently for migraine. She had no history of diabetes mellitus or thyroid disease.
>
> **[sec:5 ¶5]** Her younger brother had experienced marked hypertriglyceridemia with recurrent episodes of acute pancreatitis. Other family members—including her parents, younger sister, two daughters, and the son of her hypertriglyceridemic brother—had no history of hypertriglyceridemia or pancreatitis. Her two daughters were unmarried, had never experienced pregnancy, and had normal TG levels. There was no family history of diabetes mellitus. The patient reported a history of consanguineous marriage in her family; however, the details were unclear.
>
> **[sec:5 ¶6]** On physical examination, she was not obese (height, 158 cm; weight, 53 kg; body mass index, 21.2 kg/m²). She was alert and oriented. Her body temperature was 37.3℃; blood pressure, 142/98 mmHg; heart rate, 76 beats/min and regular; respiratory rate, 16 breaths/min; and oxygen saturation, 98% on room air. No thyroid enlargement was noted. Abdominal examination revealed epigastric tenderness without rebound tenderness. No hepatosplenomegaly was detected. A single eruptive xanthoma was observed on the anterior tibial region. No Achilles tendon thickening was present.
>
> **[sec:6 ¶1]** Table 1 summarizes the laboratory findings on admission, which demonstrated markedly elevated pancreatic amylase levels (2,905 U/L; reference range, 16–52 U/L), along with a slight increase in white blood cell count (9,510/µL; reference range, 3,100–8,400/µL) and C-reactive protein (CRP) (1.76 mg/dL; reference range, 0.00–0.30 mg/dL). The CRP level subsequently increased to 14.01 mg/dL on hospital day 5.
>
> **[sec:6 ¶2]** Contrast-enhanced abdominal computed tomography (CT) revealed pancreatic enlargement with increased peripancreatic fat attenuation and mild dilation of the main pancreatic duct, findings consistent with acute pancreatitis. Splenomegaly was also observed ( Fig.1 ) .
>
> **[sec:6 ¶3]** Lipid analysis revealed marked hypertriglyceridemia (TG 1,262 mg/dL), while LDL-C and HDL-C levels were markedly reduced. After standing at 4℃ for 24 hours, the serum separated into a creamy supernatant layer and a turbid infranatant layer ( Fig.2A ) . Polyacrylamide gel (PAG) disc electrophoresis of serum lipoproteins demonstrated a marked increase in chylomicrons and an elevated VLDL fraction, consistent with a type V hyperlipoproteinemia phenotype ( Fig.2B, C ) .
>
> **[sec:6 ¶4]** Apolipoprotein analysis showed apoA-V levels of 381.8 ng/mL (reference range, 104–254 ng/mL) and apoC-II levels of 13.7 mg/dL (reference range, 1.5–3.8 mg/dL), with no evidence of deficiency. Because heparin administration may cause hemorrhagic complications, preheparin LPL mass was measured without heparin injection and was markedly reduced at 17 ng/mL (reference range, 45–63 ng/mL), suggesting impaired LPL activity. The serum GPIHBP1 level was below the limit of detection.
>
> **[sec:6 ¶5]** Glucose metabolism and thyroid function tests were within normal limits, and all tested autoantibodies were negative. The ankle–brachial index (ABI) and cardio–ankle vascular index (CAVI) showed no evidence of atherosclerosis. Resting electrocardiography demonstrated normal sinus rhythm without ischemic changes.
>
> **[sec:6 ¶6]** Genomic analysis was performed using hybrid capture–based targeted next-generation sequencing (NGS) covering protein-coding exon regions and adjacent intronic sequences. This analysis identified a novel homozygous mutation in the GPIHBP1 gene (NM_178172.4:c.20del [p.Val7AlafsTer73]) that has not been previously reported in public databases, including ClinVar ( Fig.3 ) . No pathogenic variants were detected in other genes associated with impaired LPL activity, including LPL, apoC-II, apoA-V, and LMF1.
>
> **[sec:6 ¶7]** Following admission, acute pancreatitis improved rapidly with continued fasting and intravenous fluid therapy alone. On hospital day 3, a strict fat-restricted diet (≤ 15 g/day) was initiated. Both fasting and postprandial TG levels decreased to 202–270 mg/dL during hospitalization, and the patient was discharged on hospital day 13 ( Fig.4 ) . After discharge, conventional fat-restricted diet at home was started. Furthermore, since postprandial chylomicronemia (TG, 1262 mg/dL) was observed despite the initiation of a strict low-fat diet during hospitalization, pemafibrate—a selective peroxisome proliferator–activated receptor-α (PPARα) modulator (extended-release formulation, 0.4 mg/day)—was added to dietary management to prevent recurrent pancreatitis, considering the potential for postprandial increases in TG levels with her conventional fat-restricted diet at home. During follow-up, serum TG levels remained stable at approximately 214–489 mg/dL, with no recurrence of pancreatitis.
>
> **[sec:8 ¶3]** In the present case, preheparin LPL mass was markedly reduced and circulating GPIHBP1 was undetectable, consistent with the classic biochemical phenotype of GPIHBP1 deficiency. Genetic analysis identified a novel homozygous frameshift mutation in the GPIHBP1 gene (NM_178172.4:c.20del [p.Val7AlafsTer73]) that has not been previously reported in public databases. Importantly, no pathogenic variants were detected in other genes involved in LPL maturation or activity, including LPL, apoC-II, apoA-V, and LMF1, supporting GPIHBP1 deficiency as the primary cause of the patient’s phenotype.
>
> **[sec:8 ¶4]** Mutations in the GPIHBP1 gene are exceedingly rare and account for fewer than 5% of all cases of FCS. Most previously reported pathogenic variants are missense mutations clustered within the conserved Ly6/uPAR (LU) domain, particularly affecting cysteine residues that are critical for disulfide bond formation and proper three-dimensional folding of the protein 18) . Disruption of these cysteine residues impairs LPL binding and endothelial transport, thereby abolishing intravascular lipolysis. In contrast, two variants were detected in the exon 1 of GPIHBP1, both in the homozygous state. One of them was a deletion of a thymine (“T”), which results in a frameshift. The present patient harbored a homozygous novel frameshift variant located near the extreme N-terminus, c.20del (p.Val7AlafsTer73). This deletion occurs within the region encoding the signal peptide and results in a premature termination codon at amino acid position 73 ( Fig.3 ) . Given that the mature GPIHBP1 protein consists of 184 amino acids and contains a structured Ly6 domain required for LPL binding and stabilization, this early truncation would completely prevent formation of the Ly6 domain. The predicted truncated protein would lack the characteristic disulfide-bonded LU domain as well as the C-terminal hydrophobic sequence required for glycosylphosphatidylinositol (GPI) anchoring. Therefore, this variant is expected to abolish endothelial localization and LPL transport, representing a complete loss-of-function allele and predicting a severe phenotype.
>
> **[sec:8 ¶5]** Analysis of previously reported cases 21) indicated that TG levels are severely elevated, with most values clustering between 673~40,141 mg/dL (mean approximately 5,000–6,000 mg/dL, influenced by extreme outliers). It remains unclear why our patient exhibited only modest TG elevation under strict dietary fat restriction despite the apparent absence of functional GPIHBP1. Eruptive xanthomas were present in approximately 30% of patients, while acute pancreatitis occurred in roughly half of cases. These findings highlight the heterogeneity of clinical phenotypes, with eruptive xanthomas present in only a subset of patients despite uniformly severe hypertriglyceridemia.
>
> **[sec:8 ¶6]** From a pathogenicity standpoint, this variant fulfills the ACMG/AMP criteria for pathogenic classification. Specifically, it meets PVS1 (very strong evidence), as it is a null variant (frameshift) in a gene where loss of function is an established disease mechanism. In addition, the absence of this variant in population databases such as gnomAD supports PM2 (moderate evidence), and the patient’s phenotype—lifelong severe chylomicronemia with recurrent pancreatitis—is highly specific for GPIHBP1 deficiency, supporting PP4 (supporting evidence). Taken together, these criteria strongly support classification of c.20del (p.Val7AlafsTer73) as a pathogenic variant.
>
> **[sec:8 ¶7]** Importantly, because the truncation occurs upstream of the Ly6 structural domain, this mutation is predicted to have a more profound functional impact than many previously reported missense variants that partially preserve protein folding. The extremely early stop codon may also trigger nonsense-mediated mRNA decay, further reducing or eliminating protein expression. This molecular mechanism is consistent with the undetectable circulating GPIHBP1 level observed in our patient and the markedly reduced preheparin LPL mass, reinforcing the biological plausibility of complete GPIHBP1 deficiency. To our knowledge, this variant has not been reported in ClinVar, HGMD, or other public mutation databases, indicating that it represents a novel and exceptionally rare pathogenic mutation that expands the mutational spectrum of GPIHBP1 deficiency.
>
> **[sec:8 ¶8]** Interestingly, the markedly low preheparin LPL mass observed in this case is consistent with previous reports of GPIHBP1 deficiency, in which reduced circulating LPL levels have also been described 17 , 19) . Mechanistically, GPIHBP1 plays a critical role in transporting LPL from the interstitial spaces to the luminal surface of capillary endothelial cells, where LPL mediates the hydrolysis of TG-rich lipoproteins. In the absence of functional GPIHBP1, LPL fails to reach the capillary lumen and may instead be retained within tissues and subjected to intracellular degradation, resulting in reduced levels of circulating LPL. Therefore, the low preheparin LPL mass in this patient likely reflects impaired LPL trafficking and stability rather than decreased LPL synthesis. This interpretation is consistent with the concept that GPIHBP1 deficiency causes a functional LPL deficiency despite preserved production.
>
> **[sec:9 ¶3]** In the present case, complete loss of functional GPIHBP1 would be expected to result in persistent severe hypertriglyceridemia and recurrent pancreatitis. Interestingly, however, the clinical phenotype varied between pregnancies: acute pancreatitis occurred during the first pregnancy, whereas during the second pregnancy, TG levels exceeded 6,000 mg/dL without pancreatitis. This observation highlights that absolute TG concentration alone does not fully determine pancreatitis risk. Rather, qualitative and dynamic factors—such as chylomicron particle size, remnant accumulation, pancreatic microvascular perfusion, and local lipotoxic injury mediated by excessive free fatty acid release—likely contribute to pancreatic susceptibility 28 - 29) . Although we could not obtain more detailed information on TG levels during her second pregnancy, it may be reasonable that she did not suffer from pancreatitis if this TG level of 6,000 mg/dL was only temporary. However, if high TG level even around 1,000 mg/dL lasted a little longer, there may be a possibility that it may have caused pancreatitis. This phenotypic variability despite a presumed identical genetic background underscores the importance of environmental and metabolic modifiers, including dietary fat intake and insulin sensitivity, in determining clinical expression in GPIHBP1 deficiency.
>
> **[sec:10 ¶1]** FCS is a lifelong metabolic disorder characterized by recurrent exacerbations, not limited to childhood 30 - 31) . Although this patient was diagnosed in infancy, regular follow-up was discontinued early and only resumed in adulthood after she developed acute pancreatitis during her first pregnancy at age 23. During her second pregnancy at age 29, TG levels exceeded 6,000 mg/dL, requiring hospitalization to prevent pancreatitis. She delivered without complications, but follow-up was again discontinued after her second child.
>
> **[sec:11 ¶3]** GPIHBP1 is required for trafficking LPL to the capillary lumen and thereby for efficient intravascular processing of TG-rich lipoproteins; consequently, GPIHBP1 deficiency causes severe chylomicronemia due to impaired capillary lipolysis. Nevertheless, reductions in plasma TG can still occur during fasting, intravenous supportive care, and/or stringent dietary fat restriction, which most directly reduces intestinal chylomicron production—the cornerstone of therapy in FCS phenotypes 34) . In the acute phase, fasting and intravenous fluids alone led to rapid resolution of pancreatitis 35) . TG levels decreased from 1,262 mg/dL to 225 mg/dL by day 5. Despite a predicted severe mutation, the clinical course was relatively mild, possibly due to long-term adherence to her conventional fat-restricted diet 36) . In the chronic phase, strict dietary fat restriction with adjunctive therapy maintained good TG control.
>
> **[sec:11 ¶5]** Until recently, treatment options for FCS were limited, especially in patients with complete LPL pathway deficiency. Conventional lipid-lowering agents, such as fibrates, nicotinic acid, and omega-3 fatty acids, have shown variable and often modest effects, reflecting impaired intravascular lipolysis as the main cause of the disease. Selective PPAR-α modulators, such as pemafibrate 40) , can reduce TG levels by decreasing VLDL production and enhancing remnant metabolism, although their effect may depend on residual LPL activity. Previous reports have shown that pemafibrate lowers TG levels in patients with chylomicronemia, including those with APOA5 mutations 41 - 43) . In our patient with GPIHBP1 deficiency, pemafibrate helped maintain TG levels at 200–500 mg/dL after discharge from hospital, suggesting a supportive role even with severe LPL pathway impairment. No recurrence of pancreatitis has been observed, but lifelong monitoring is required.
>
> **[sec:12 ¶1]** In this study, we reported an extremely rare case of familial chylomicronemia syndrome (FCS) caused by a novel homozygous frameshift mutation in the GPIHBP1 gene (NM_178172.4:c.20del [p.Val7AlafsTer73]), in which pregnancy acted as a major trigger for severe hypertriglyceridemia and acute pancreatitis. This case expands the mutational spectrum of GPIHBP1 deficiency and highlights the profound impact of pregnancy on TG metabolism in the setting of impaired intravascular lipolysis. Serum TG levels were successfully controlled with strict dietary fat restriction and adjunctive pharmacotherapy with the SPPARMα pemafibrate.
>
> **[sec:13 ¶1]** This case report is based solely on findings from the index proband. We were unable to perform biochemical and genetic analyses in her brother, who had a history of marked hypertriglyceridemia and recurrent acute pancreatitis. Information regarding dietary habits was obtained through an interview conducted by a registered dietitian and may therefore be subject to recall bias. In addition, the therapeutic efficacy of pemafibrate in chylomicronemia requires confirmation in larger cohorts of patients with genetically confirmed FCS.
>
> **[tab:1 r1]** <Blood cell count> |  |  | <Lipids> |  |  | <Reference> | <Glucose metabolism & Thyroid> |  | 
>
> **[tab:1 r2]** WBC | 9,510 | /μL | LDL-C | 15 | mg/dL | ＜120 | Fasting glucose | 106 | mg/dL
>
> **[tab:1 r3]** RBC | 519×104 | /μL | HDL-C | 13 | mg/dL | ≧40 | Insulin | 8.5 | μU/mL
>
> **[tab:1 r4]** Hb | 12.7 | g/dL | TG | 1,262 | mg/dL | 50~149 | HbA1c | 5.3 | %
>
> **[tab:1 r5]** PLT | 13.5×104 | /μL | RemL-C | 43.3 | mg/dL | 0~7.5 | TSH | 0.84 | μU/mL
>
> **[tab:1 r6]**  |  |  |  |  |  |  | FT4 | 1.06 | ng/dL
>
> **[tab:1 r7]** <Biochemistry> |  |  | <Apolipoproteins> |  |  |  |  |  | 
>
> **[tab:1 r8]** AST | 18 | U/L | A-Ⅰ | 74 | mg/dL | 65~126 | <Autoimmune> |  | 
>
> **[tab:1 r9]** ALT | 10 | U/L | A-Ⅱ | 16.5 | mg/dL | 24.6~33.3 | Antinucler Ab |  | 40-fold
>
> **[tab:1 r10]** γ-GTP | 17 | U/L | A-Ⅴ | 381.8 | ng/dL | 104~254 | Anti SS-A·SS-B Ab |  | negative
>
> **[tab:1 r11]** Pancreatic AMY | 2,905 | U/L | B | 55 | mg/dL | 66~101 | Rheumatoid factor |  | 6.2 U/mL
>
> **[tab:1 r12]** (Reference 16~52U/L) |  |  | C-Ⅱ | 13.7 | mg/dL | 1.5~3.8 |  |  | 
>
> **[tab:1 r13]** BUN | 12 | mg/dL | C-Ⅲ | 15.2 | mg/dL | 5.4~9 |  |  | 
>
> **[tab:1 r14]** Cre | 0.43 | mg/dL | E | 8.1 | mg/dL | 2.8~4.6 |  |  | 
>
> **[tab:1 r15]** Na | 138 | mEq/L |  |  |  |  |  |  | 
>
> **[tab:1 r16]** K | 3.6 | mEq/L | Preheparin LPL mass |  |  |  |  |  | 
>
> **[tab:1 r17]** Cl | 101 | mEq/L |  | 17 | ng/mL | 45~63 |  |  | 
>
> **[tab:1 r18]** Ca | 8.4 | mg/dL | GPIHBP1 |  |  |  |  |  | 
>
> **[tab:1 r19]** CRP | 1.76 | mg/dL |  | ＜1.98 | pg/mL | 740~1,014 |  |  | 
>

## Diagnoses

- ✓ **FINAL** Familial chylomicronemia syndrome (FCS) caused by a novel homozygous GPIHBP1 frameshift mutation (GPIHBP1 deficiency) → Hyperlipoproteinemia, type 1D (GPIHBP1 deficiency)  OMIM:615947 · tier MOLECULAR · route symptomatic  
  “we reported an extremely rare case of familial chylomicronemia syndrome (FCS) caused by a novel homozygous frameshift mutation in the GPIHBP1 gene (NM_178172.4:c.20del [p.Val7AlafsTer73]), in which pregnancy acted as a major trigger for severe hypertriglyceridemia and acute pancreatitis.” [sec:12 ¶1]
- ✓ **REVISED_FROM** Primary chylomicronemia (childhood clinical diagnosis, later specified as GPIHBP1 deficiency) → Familial chylomicronemia syndrome   · tier CLINICAL · route unknown  
  “The patient had been diagnosed with primary chylomicronemia at a university hospital during infancy and was followed until preschool age, during which she was managed solely with dietary fat restriction.” [sec:5 ¶1]
- ✓ **EXCLUDED** Lipoprotein lipase (LPL) deficiency → Familial lipoprotein lipase deficiency   · tier MOLECULAR · route –  
  “No pathogenic variants were detected in other genes associated with impaired LPL activity, including LPL, apoC-II, apoA-V, and LMF1.” [sec:6 ¶6]
- ✓ **EXCLUDED** ApoC-II deficiency → Apolipoprotein C-II deficiency   · tier MOLECULAR · route –  
  “Apolipoprotein analysis showed apoA-V levels of 381.8 ng/mL (reference range, 104–254 ng/mL) and apoC-II levels of 13.7 mg/dL (reference range, 1.5–3.8 mg/dL), with no evidence of deficiency.” [sec:6 ¶4]
- ✓ **EXCLUDED** ApoA-V deficiency → Apolipoprotein A-V deficiency   · tier MOLECULAR · route –  
  “Apolipoprotein analysis showed apoA-V levels of 381.8 ng/mL (reference range, 104–254 ng/mL) and apoC-II levels of 13.7 mg/dL (reference range, 1.5–3.8 mg/dL), with no evidence of deficiency.” [sec:6 ¶4]
- ✓ **EXCLUDED** LMF1 deficiency → Lipase maturation factor 1 deficiency   · tier MOLECULAR · route –  
  “No pathogenic variants were detected in other genes associated with impaired LPL activity, including LPL, apoC-II, apoA-V, and LMF1.” [sec:6 ¶6]

## Genetic findings

- ✓ **GPIHBP1** c.20del p.Val7AlafsTer73 · HOMOZYGOUS · pathogenic · targeted NGS gene panel (hybrid capture of 21 dyslipidemia genes; Illumina iSeq 100; BWA-MEM/GATK HaplotypeCaller; clinical test by KUBIX Inc.)  
  “This analysis identified a novel homozygous mutation in the GPIHBP1 gene (NM_178172.4:c.20del [p.Val7AlafsTer73]) that has not been previously reported in public databases, including ClinVar ( Fig.3 ) .” [sec:6 ¶6]
- ✓ **LPL** No pathogenic variant detected (written as LPL)  · UNKNOWN · – · targeted NGS gene panel (hybrid capture of 21 dyslipidemia genes; Illumina iSeq 100; BWA-MEM/GATK HaplotypeCaller; clinical test by KUBIX Inc.)  
  “No pathogenic variants were detected in other genes associated with impaired LPL activity, including LPL, apoC-II, apoA-V, and LMF1.” [sec:6 ¶6]
- ✓ **APOC2** No pathogenic variant detected (written as apoC-II)  · UNKNOWN · – · targeted NGS gene panel (hybrid capture of 21 dyslipidemia genes; Illumina iSeq 100; BWA-MEM/GATK HaplotypeCaller; clinical test by KUBIX Inc.)  
  “No pathogenic variants were detected in other genes associated with impaired LPL activity, including LPL, apoC-II, apoA-V, and LMF1.” [sec:6 ¶6]
- ✓ **APOA5** No pathogenic variant detected (written as apoA-V)  · UNKNOWN · – · targeted NGS gene panel (hybrid capture of 21 dyslipidemia genes; Illumina iSeq 100; BWA-MEM/GATK HaplotypeCaller; clinical test by KUBIX Inc.)  
  “No pathogenic variants were detected in other genes associated with impaired LPL activity, including LPL, apoC-II, apoA-V, and LMF1.” [sec:6 ¶6]
- ✓ **LMF1** No pathogenic variant detected (written as LMF1)  · UNKNOWN · – · targeted NGS gene panel (hybrid capture of 21 dyslipidemia genes; Illumina iSeq 100; BWA-MEM/GATK HaplotypeCaller; clinical test by KUBIX Inc.)  
  “No pathogenic variants were detected in other genes associated with impaired LPL activity, including LPL, apoC-II, apoA-V, and LMF1.” [sec:6 ¶6]

## Measurements

| ✓ | analyte | specimen | value | unit | ref | interp | timing | quote [anchor] |
|---|---|---|---|---|---|---|---|---|
| ~ | TG (serum triglyceride) → triglyceride | serum | 1262 | mg/dL | 50~149 | HIGH | on admission (Table 1) | “TG / 1,262 / mg/dL / 50~149” [tab:1 r4c4] |
| ~ | LDL-C → LDL cholesterol | serum | 15 | mg/dL | ＜120 | LOW | on admission (Table 1) | “LDL-C / 15 / mg/dL / ＜120” [tab:1 r2c4] |
| ~ | HDL-C → HDL cholesterol | serum | 13 | mg/dL | ≧40 | LOW | on admission (Table 1) | “HDL-C / 13 / mg/dL / ≧40” [tab:1 r3c4] |
| ~ | RemL-C (remnant lipoprotein cholesterol) → remnant lipoprotein cholesterol | serum | 43.3 | mg/dL | 0~7.5 | HIGH | on admission (Table 1) | “RemL-C / 43.3 / mg/dL / 0~7.5” [tab:1 r5c4] |
| ~ | apoA-I (A-Ⅰ) → apolipoprotein A-I | serum | 74 | mg/dL | 65~126 | NORMAL | on admission (Table 1) | “A-Ⅰ / 74 / mg/dL / 65~126” [tab:1 r8c4] |
| ~ | apoA-II (A-Ⅱ) → apolipoprotein A-II | serum | 16.5 | mg/dL | 24.6~33.3 | LOW | on admission (Table 1) | “A-Ⅱ / 16.5 / mg/dL / 24.6~33.3” [tab:1 r9c4] |
| ✓ | apoA-V → apolipoprotein A-V | serum | 381.8 | ng/mL | 104–254 ng/mL | HIGH | on admission (Table 1) | “Apolipoprotein analysis showed apoA-V levels of 381.8 ng/mL (reference range, 104–254 ng/mL) and apoC-II levels of 13.7 ” [sec:6 ¶4] |
| ~ | apoA-V (A-Ⅴ) [Table 1 unit as printed] → apolipoprotein A-V | serum | 381.8 | ng/dL | 104~254 | HIGH | on admission (Table 1) | “A-Ⅴ / 381.8 / ng/dL / 104~254” [tab:1 r10c4] |
| ~ | apoB (B) → apolipoprotein B | serum | 55 | mg/dL | 66~101 | LOW | on admission (Table 1) | “B / 55 / mg/dL / 66~101” [tab:1 r11c4] |
| ✓ | apoC-II (C-Ⅱ) → apolipoprotein C-II | serum | 13.7 | mg/dL | 1.5–3.8 mg/dL | HIGH | on admission (Table 1) | “Apolipoprotein analysis showed apoA-V levels of 381.8 ng/mL (reference range, 104–254 ng/mL) and apoC-II levels of 13.7 ” [sec:6 ¶4] |
| ~ | apoC-III (C-Ⅲ) → apolipoprotein C-III | serum | 15.2 | mg/dL | 5.4~9 | HIGH | on admission (Table 1) | “C-Ⅲ / 15.2 / mg/dL / 5.4~9” [tab:1 r13c4] |
| ~ | apoE (E) → apolipoprotein E | serum | 8.1 | mg/dL | 2.8~4.6 | HIGH | on admission (Table 1) | “E / 8.1 / mg/dL / 2.8~4.6” [tab:1 r14c4] |
| ✓ | Preheparin LPL mass → lipoprotein lipase mass | plasma | 17 | ng/mL | 45–63 ng/mL | LOW | on admission (Table 1) | “preheparin LPL mass was measured without heparin injection and was markedly reduced at 17 ng/mL (reference range, 45–63 ” [sec:6 ¶4] |
| ~ | GPIHBP1 → glycosylphosphatidylinositol-anchored HDL-binding protein 1 | serum | 1.98 | pg/mL | 740~1,014 | LOW | on admission (Table 1) | “＜1.98 / pg/mL / 740~1,014” [tab:1 r19c5] |
| ✓ | Chylomicrons (PAG disc electrophoresis) → chylomicrons | serum | marked increase |  |  | HIGH | on admission (Table 1) | “Polyacrylamide gel (PAG) disc electrophoresis of serum lipoproteins demonstrated a marked increase in chylomicrons and a” [sec:6 ¶3] |
| ✓ | VLDL fraction (PAG disc electrophoresis) → VLDL | serum | elevated / marked increase |  |  | HIGH | on admission (Table 1) | “Polyacrylamide gel (PAG) disc electrophoresis of serum lipoproteins demonstrated a marked increase in chylomicrons and a” [sec:6 ¶3] |
| ~ | IDL fraction (PAG electrophoresis densitometry) → IDL | serum | slight increase |  |  | HIGH | on admission (Table 1) | “Densitometric analysis of the PAG electrophoresis demonstrated a marked increase in the VLDL fraction, with slight incre” [fig:2] |
| ~ | Small dense LDL fraction (PAG electrophoresis densitometry) → small dense LDL | serum | slight increase |  |  | HIGH | on admission (Table 1) | “Densitometric analysis of the PAG electrophoresis demonstrated a marked increase in the VLDL fraction, with slight incre” [fig:2] |
| ✓ | Serum TG (second pregnancy) → triglyceride | serum | 6000 | mg/dL |  | HIGH | during second pregnancy (historical) | “During her second pregnancy at 29 years of age, serum TG levels exceeded 6,000 mg/dL; however, she delivered without dev” [sec:5 ¶1] |
| ✓ | TG (hospital day 5, after fasting/intravenous fluids and strict fat-restricted diet) → triglyceride | serum | 225 | mg/dL |  | HIGH | hospital day 5 | “TG levels decreased from 1,262 mg/dL to 225 mg/dL by day 5.” [sec:11 ¶3] |
| ✓ | TG (fasting and postprandial, during hospitalization on strict fat-restricted diet) → triglyceride | serum | 202–270 | mg/dL |  | HIGH | during hospitalization, on strict fat-restricted diet (≤ 15 g/day) | “On hospital day 3, a strict fat-restricted diet (≤ 15 g/day) was initiated. Both fasting and postprandial TG levels decr” [sec:6 ¶7] |
| ✓ | TG (postprandial chylomicronemia during hospitalization, as stated) → triglyceride | serum | 1262 | mg/dL |  | HIGH | during hospitalization despite strict low-fat diet (as stated; see extractor note) | “since postprandial chylomicronemia (TG, 1262 mg/dL) was observed despite the initiation of a strict low-fat diet during ” [sec:6 ¶7] |
| ✓ | Serum TG (follow-up on pemafibrate plus fat-restricted diet) → triglyceride | serum | approximately 214–489 | mg/dL |  | HIGH | follow-up after discharge | “During follow-up, serum TG levels remained stable at approximately 214–489 mg/dL, with no recurrence of pancreatitis.” [sec:6 ¶7] |
| ✓ | WBC (white blood cell count) → white blood cells | blood | 9510 | /μL | 3,100–8,400/µL | HIGH | on admission (Table 1) | “which demonstrated markedly elevated pancreatic amylase levels (2,905 U/L; reference range, 16–52 U/L), along with a sli” [sec:6 ¶1] |
| ~ | RBC → erythrocyte count | blood | 5190000 | /μL |  | UNKNOWN | on admission (Table 1) | “RBC / 519×104 / /μL” [tab:1 r3c1] |
| ~ | Hb → haemoglobin | blood | 12.7 | g/dL |  | UNKNOWN | on admission (Table 1) | “Hb / 12.7 / g/dL” [tab:1 r4c1] |
| ~ | PLT → platelet count | blood | 135000 | /μL |  | UNKNOWN | on admission (Table 1) | “PLT / 13.5×104 / /μL” [tab:1 r5c1] |
| ~ | AST → aspartate aminotransferase | blood | 18 | U/L |  | UNKNOWN | on admission (Table 1) | “AST / 18 / U/L” [tab:1 r8c1] |
| ~ | ALT → alanine aminotransferase | blood | 10 | U/L |  | UNKNOWN | on admission (Table 1) | “ALT / 10 / U/L” [tab:1 r9c1] |
| ~ | γ-GTP → gamma-glutamyl transferase | blood | 17 | U/L |  | UNKNOWN | on admission (Table 1) | “γ-GTP / 17 / U/L” [tab:1 r10c1] |
| ✓ | Pancreatic AMY (pancreatic amylase) → pancreatic amylase | blood | 2905 | U/L | 16–52 U/L | HIGH | on admission (Table 1) | “which demonstrated markedly elevated pancreatic amylase levels (2,905 U/L; reference range, 16–52 U/L), along with a sli” [sec:6 ¶1] |
| ~ | BUN → blood urea nitrogen | blood | 12 | mg/dL |  | UNKNOWN | on admission (Table 1) | “BUN / 12 / mg/dL” [tab:1 r13c1] |
| ~ | Cre (creatinine) → creatinine | blood | 0.43 | mg/dL |  | UNKNOWN | on admission (Table 1) | “Cre / 0.43 / mg/dL” [tab:1 r14c1] |
| ~ | Na → sodium | blood | 138 | mEq/L |  | UNKNOWN | on admission (Table 1) | “Na / 138 / mEq/L” [tab:1 r15c1] |
| ~ | K → potassium | blood | 3.6 | mEq/L |  | UNKNOWN | on admission (Table 1) | “K / 3.6 / mEq/L” [tab:1 r16c1] |
| ~ | Cl → chloride | blood | 101 | mEq/L |  | UNKNOWN | on admission (Table 1) | “Cl / 101 / mEq/L” [tab:1 r17c1] |
| ~ | Ca → calcium | blood | 8.4 | mg/dL |  | UNKNOWN | on admission (Table 1) | “Ca / 8.4 / mg/dL” [tab:1 r18c1] |
| ✓ | CRP (C-reactive protein) → C-reactive protein | blood | 1.76 | mg/dL | 0.00–0.30 mg/dL | HIGH | on admission (Table 1) | “which demonstrated markedly elevated pancreatic amylase levels (2,905 U/L; reference range, 16–52 U/L), along with a sli” [sec:6 ¶1] |
| ✓ | CRP (C-reactive protein), hospital day 5 → C-reactive protein | blood | 14.01 | mg/dL | 0.00–0.30 mg/dL | HIGH | hospital day 5 | “The CRP level subsequently increased to 14.01 mg/dL on hospital day 5.” [sec:6 ¶1] |
| ~ | Fasting glucose → glucose | blood | 106 | mg/dL |  | NORMAL | on admission (Table 1) | “Fasting glucose / 106 / mg/dL” [tab:1 r2c8] |
| ~ | Insulin → insulin | blood | 8.5 | μU/mL |  | NORMAL | on admission (Table 1) | “Insulin / 8.5 / μU/mL” [tab:1 r3c8] |
| ~ | HbA1c → hemoglobin A1c | blood | 5.3 | % |  | NORMAL | on admission (Table 1) | “HbA1c / 5.3 / %” [tab:1 r4c8] |
| ~ | TSH → thyroid stimulating hormone | blood | 0.84 | μU/mL |  | NORMAL | on admission (Table 1) | “TSH / 0.84 / μU/mL” [tab:1 r5c8] |
| ~ | FT4 → free T4 | blood | 1.06 | ng/dL |  | NORMAL | on admission (Table 1) | “FT4 / 1.06 / ng/dL” [tab:1 r6c8] |
| ~ | Antinuclear antibody (Antinucler Ab) → antinuclear antibody | blood | 40 | -fold (titer) |  | NORMAL | on admission (Table 1) | “Antinucler Ab /  / 40-fold” [tab:1 r9c8] |
| ~ | Anti SS-A·SS-B antibodies → anti-SS-A/SS-B antibodies | blood | negative |  |  | NORMAL | on admission (Table 1) | “Anti SS-A·SS-B Ab /  / negative” [tab:1 r10c8] |
| ~ | Rheumatoid factor → rheumatoid factor | blood | 6.2 | U/mL |  | NORMAL | on admission (Table 1) | “Rheumatoid factor /  / 6.2 U/mL” [tab:1 r11c8] |
| ✓ | Height → body height | other | 158 | cm |  | UNKNOWN | at presentation | “On physical examination, she was not obese (height, 158 cm; weight, 53 kg; body mass index, 21.2 kg/m²).” [sec:5 ¶6] |
| ✓ | Weight → body weight | other | 53 | kg |  | UNKNOWN | at presentation | “On physical examination, she was not obese (height, 158 cm; weight, 53 kg; body mass index, 21.2 kg/m²).” [sec:5 ¶6] |
| ✓ | Body mass index → body mass index | other | 21.2 | kg/m² |  | NORMAL | at presentation | “On physical examination, she was not obese (height, 158 cm; weight, 53 kg; body mass index, 21.2 kg/m²).” [sec:5 ¶6] |
| ✓ | Body temperature → body temperature | other | 37.3 | ℃ |  | UNKNOWN | at presentation | “Her body temperature was 37.3℃; blood pressure, 142/98 mmHg; heart rate, 76 beats/min and regular; respiratory rate, 16 ” [sec:5 ¶6] |
| ✓ | Blood pressure → blood pressure | other | 142/98 | mmHg |  | UNKNOWN | at presentation | “Her body temperature was 37.3℃; blood pressure, 142/98 mmHg; heart rate, 76 beats/min and regular; respiratory rate, 16 ” [sec:5 ¶6] |
| ✓ | Heart rate → heart rate | other | 76 | beats/min |  | UNKNOWN | at presentation | “Her body temperature was 37.3℃; blood pressure, 142/98 mmHg; heart rate, 76 beats/min and regular; respiratory rate, 16 ” [sec:5 ¶6] |
| ✓ | Respiratory rate → respiratory rate | other | 16 | breaths/min |  | UNKNOWN | at presentation | “Her body temperature was 37.3℃; blood pressure, 142/98 mmHg; heart rate, 76 beats/min and regular; respiratory rate, 16 ” [sec:5 ¶6] |
| ✓ | Oxygen saturation → oxygen saturation | other | 98 | % |  | UNKNOWN | at presentation | “Her body temperature was 37.3℃; blood pressure, 142/98 mmHg; heart rate, 76 beats/min and regular; respiratory rate, 16 ” [sec:5 ¶6] |

## Phenotypes

- ✓ Hypertriglyceridemia → Hypertriglyceridemia HP:0002155 (grounded)  
  “Laboratory evaluation revealed marked hypertriglyceridemia (1,262 mg/dL) with a type V hyperlipoproteinemia pattern.” [abstract]
- ✓ Chylomicronemia → –  (candidate)  
  “The patient had been diagnosed with primary chylomicronemia at a university hospital during infancy and was followed until preschool age, during which she was managed solely with dietary fat restriction.” [sec:5 ¶1]
- ✓ Lipemic serum with creamy supernatant (chylomicron) layer after standing → –  (unresolved)  
  “After standing at 4℃ for 24 hours, the serum separated into a creamy supernatant layer and a turbid infranatant layer ( Fig.2A ) .” [sec:6 ¶3]
- ✓ Type V hyperlipoproteinemia lipoprotein pattern → –  (candidate)  
  “Polyacrylamide gel (PAG) disc electrophoresis of serum lipoproteins demonstrated a marked increase in chylomicrons and an elevated VLDL fraction, consistent with a type V hyperlipoproteinemia phenotype ( Fig.2B, C ) .” [sec:6 ¶3]
- ✓ Acute pancreatitis → Acute pancreatitis HP:0001735 (grounded)  
  “At 23 years of age, during her first pregnancy, she developed severe hypertriglyceridemia complicated by acute pancreatitis, requiring hospitalization.” [sec:5 ¶1]
- ✓ Epigastric pain → Epigastric pain HP:0410019 (grounded)  
  “At 47 years of age, she was emergently transported to the Emergency Department of Rinku General Medical Center with severe epigastric pain.” [sec:5 ¶2]
- ✓ Epigastric tenderness → –  (candidate)  
  “Abdominal examination revealed epigastric tenderness without rebound tenderness. No hepatosplenomegaly was detected. A single eruptive xanthoma was observed on the anterior tibial region. No Achilles tendon thickening was present.” [sec:5 ¶6]
- ✓ NOT Rebound tenderness → –  (candidate)  
  “Abdominal examination revealed epigastric tenderness without rebound tenderness. No hepatosplenomegaly was detected. A single eruptive xanthoma was observed on the anterior tibial region. No Achilles tendon thickening was present.” [sec:5 ¶6]
- ✓ Eruptive xanthoma → –  (candidate)  
  “Abdominal examination revealed epigastric tenderness without rebound tenderness. No hepatosplenomegaly was detected. A single eruptive xanthoma was observed on the anterior tibial region. No Achilles tendon thickening was present.” [sec:5 ¶6]
- ✓ NOT Achilles tendon thickening → –  (candidate)  
  “Abdominal examination revealed epigastric tenderness without rebound tenderness. No hepatosplenomegaly was detected. A single eruptive xanthoma was observed on the anterior tibial region. No Achilles tendon thickening was present.” [sec:5 ¶6]
- ✓ NOT Hepatosplenomegaly → Hepatosplenomegaly HP:0001433 (grounded)  
  “Abdominal examination revealed epigastric tenderness without rebound tenderness. No hepatosplenomegaly was detected. A single eruptive xanthoma was observed on the anterior tibial region. No Achilles tendon thickening was present.” [sec:5 ¶6]
- ✓ NOT Thyroid enlargement → Goiter HP:0000853 (candidate)  
  “No thyroid enlargement was noted.” [sec:5 ¶6]
- ✓ NOT Obesity → Obesity HP:0001513 (grounded)  
  “On physical examination, she was not obese (height, 158 cm; weight, 53 kg; body mass index, 21.2 kg/m²).” [sec:5 ¶6]
- ✓ Splenomegaly → Splenomegaly HP:0001744 (grounded)  
  “Splenomegaly was also observed ( Fig.1 ) .” [sec:6 ¶2]
- ✓ Pancreatic enlargement → –  (candidate)  
  “Contrast-enhanced abdominal computed tomography (CT) revealed pancreatic enlargement with increased peripancreatic fat attenuation and mild dilation of the main pancreatic duct, findings consistent with acute pancreatitis.” [sec:6 ¶2]
- ✓ Increased peripancreatic fat attenuation (fat stranding) → –  (candidate)  
  “Contrast-enhanced abdominal computed tomography (CT) revealed pancreatic enlargement with increased peripancreatic fat attenuation and mild dilation of the main pancreatic duct, findings consistent with acute pancreatitis.” [sec:6 ¶2]
- ✓ Dilation of the main pancreatic duct → –  (candidate)  
  “Contrast-enhanced abdominal computed tomography (CT) revealed pancreatic enlargement with increased peripancreatic fat attenuation and mild dilation of the main pancreatic duct, findings consistent with acute pancreatitis.” [sec:6 ¶2]
- ✓ Elevated pancreatic amylase → –  (candidate)  
  “Based on markedly elevated pancreatic amylase levels, she was diagnosed with acute pancreatitis and admitted to the Department of Gastroenterology.” [sec:5 ¶2]
- ✓ Leukocytosis → Increased total leukocyte count HP:0001974 (grounded)  
  “which demonstrated markedly elevated pancreatic amylase levels (2,905 U/L; reference range, 16–52 U/L), along with a slight increase in white blood cell count (9,510/µL; reference range, 3,100–8,400/µL) and C-reactive protein (CRP) (1.76 mg/dL; reference range, 0.00–0.30 mg/dL).” [sec:6 ¶1]
- ✓ Elevated circulating C-reactive protein concentration → Elevated circulating C-reactive protein concentration HP:0011227 (grounded)  
  “which demonstrated markedly elevated pancreatic amylase levels (2,905 U/L; reference range, 16–52 U/L), along with a slight increase in white blood cell count (9,510/µL; reference range, 3,100–8,400/µL) and C-reactive protein (CRP) (1.76 mg/dL; reference range, 0.00–0.30 mg/dL).” [sec:6 ¶1]
- ✓ Decreased LDL cholesterol concentration → Decreased circulating LDL-C concentration HP:0003563 (candidate)  
  “Lipid analysis revealed marked hypertriglyceridemia (TG 1,262 mg/dL), while LDL-C and HDL-C levels were markedly reduced.” [sec:6 ¶3]
- ✓ Decreased HDL cholesterol concentration → Decreased circulating HDL-C concentration HP:0003233 (candidate)  
  “Lipid analysis revealed marked hypertriglyceridemia (TG 1,262 mg/dL), while LDL-C and HDL-C levels were markedly reduced.” [sec:6 ¶3]
- ✓ NOT Diabetes mellitus → Diabetes mellitus HP:0000819 (grounded)  
  “She had no history of diabetes mellitus or thyroid disease.” [sec:5 ¶4]
- ✓ NOT Thyroid disease → Abnormality of the thyroid gland HP:0000820 (grounded)  
  “She had no history of diabetes mellitus or thyroid disease.” [sec:5 ¶4]
- ✓ NOT Atherosclerosis → Atherosclerosis HP:0002621 (grounded)  
  “The ankle–brachial index (ABI) and cardio–ankle vascular index (CAVI) showed no evidence of atherosclerosis.” [sec:6 ¶5]
- ✓ NOT Ischemic changes on electrocardiography → –  (candidate)  
  “Resting electrocardiography demonstrated normal sinus rhythm without ischemic changes.” [sec:6 ¶5]
- ✓ Migraine → Migraine HP:0002076 (grounded)  
  “She was not receiving any lipid-lowering therapy and was taking medication only intermittently for migraine.” [sec:5 ¶4]

## Treatments

- ✓ diet: dietary fat restriction · response not_stated  
  “The patient had been diagnosed with primary chylomicronemia at a university hospital during infancy and was followed until preschool age, during which she was managed solely with dietary fat restriction.” [sec:5 ¶1]
- ✓ supportive: hospitalization · response not_stated  
  “During her second pregnancy at age 29, TG levels exceeded 6,000 mg/dL, requiring hospitalization to prevent pancreatitis. She delivered without complications, but follow-up was again discontinued after her second child.” [sec:10 ¶1]
- ✓ supportive: fasting and intravenous fluids · response improved  
  “Following admission, acute pancreatitis improved rapidly with continued fasting and intravenous fluid therapy alone.” [sec:6 ¶7]
- ✓ diet: strict fat-restricted diet (≤ 15 g/day) · response improved  
  “On hospital day 3, a strict fat-restricted diet (≤ 15 g/day) was initiated. Both fasting and postprandial TG levels decreased to 202–270 mg/dL during hospitalization, and the patient was discharged on hospital day 13 ( Fig.4 ) .” [sec:6 ¶7]
- ✓ diet: conventional fat-restricted diet · response stable  
  “After discharge, conventional fat-restricted diet at home was started.” [sec:6 ¶7]
- ✓ drug: pemafibrate · response stable  
  “since postprandial chylomicronemia (TG, 1262 mg/dL) was observed despite the initiation of a strict low-fat diet during hospitalization, pemafibrate—a selective peroxisome proliferator–activated receptor-α (PPARα) modulator (extended-release formulation, 0.4 mg/day)—was added to dietary management” [sec:6 ¶7]

## Outcome

Acute pancreatitis resolved rapidly with fasting and intravenous fluids; the patient was discharged on hospital day 13. On a fat-restricted diet plus pemafibrate 0.4 mg/day, serum TG remained approximately 214–489 mg/dL during follow-up with no recurrence of pancreatitis; the authors state lifelong monitoring is required.

## Model summary (not source text)

A 47-year-old Japanese woman, clinically diagnosed with primary chylomicronemia in infancy and managed with dietary fat restriction, had hypertriglyceridemia-induced acute pancreatitis during her first pregnancy at 23 years and serum TG exceeding 6,000 mg/dL during her second pregnancy at 29 years. At 47 years she presented with severe epigastric pain and acute pancreatitis (pancreatic amylase 2,905 U/L, CT showing pancreatic enlargement, peripancreatic fat stranding, mild main pancreatic duct dilation and splenomegaly); a single eruptive xanthoma was present on the anterior tibial region. Admission lipids showed TG 1,262 mg/dL, LDL-C 15 mg/dL, HDL-C 13 mg/dL, remnant cholesterol 43.3 mg/dL, a type V hyperlipoproteinemia pattern on PAG electrophoresis, elevated apoA-V, apoC-II, apoC-III and apoE, markedly reduced preheparin LPL mass (17 ng/mL) and undetectable serum GPIHBP1 (<1.98 pg/mL). Targeted NGS identified a novel homozygous GPIHBP1 frameshift variant NM_178172.4:c.20del (p.Val7AlafsTer73), classified as pathogenic, with no pathogenic variants in LPL, APOC2, APOA5 or LMF1. Pancreatitis improved with fasting and intravenous fluids; a strict fat-restricted diet lowered TG to 202–270 mg/dL, and after discharge pemafibrate 0.4 mg/day plus a conventional fat-restricted diet kept TG at approximately 214–489 mg/dL with no recurrence of pancreatitis.

## Extractor notes

- Table 1 (tab:1) is arranged in three column groups: c1-c3 blood cell count/biochemistry (name, value, unit), c4-c7 lipids/apolipoproteins/LPL mass/GPIHBP1 (name, value, unit, reference), c8-c10 glucose metabolism & thyroid / autoimmune (name, value, unit). The Preheparin LPL mass label is on r16c5 with its value on r17c5-c7; the GPIHBP1 label is on r18c5 with its value on r19c5-c7.
- apoA-V unit conflict: text (sec:6 ¶4) gives 381.8 ng/mL with reference 104–254 ng/mL, whereas Table 1 (r10c6) prints ng/dL; both entries are recorded. The text value/unit is likely correct (ELISA for apoA-V is usually reported in ng/mL).
- Specimen for general biochemistry, glucose/thyroid and autoantibody tests is not stated; recorded as 'blood'. Lipids/apolipoproteins/apoA-V/GPIHBP1 are stated to be serum; LPL mass was measured in preheparin plasma (sec:3 ¶2).
- Only LPL mass (ELISA) was measured, not LPL activity; the authors infer impaired LPL activity. No enzyme activity assay is reported, so enzyme_activities is empty and LPL mass is recorded under measurements.
- RBC and PLT are printed as '519×104' and '13.5×104' (superscript lost); interpreted as ×10^4/μL and converted to absolute counts (5,190,000/μL and 135,000/μL).
- Antinuclear antibody is listed as '40-fold' (titer 1:40) but the authors state all tested autoantibodies were negative; interpretation set to NORMAL per the authors.
- Physical examination reported no hepatosplenomegaly (sec:5 ¶6), whereas contrast-enhanced CT showed splenomegaly (sec:6 ¶2, Fig. 1); both are recorded.
- sec:6 ¶7 and the Fig. 4 legend state that 'postprandial chylomicronemia (TG, 1262 mg/dL)' was observed/persisted despite the strict low-fat diet during hospitalization, although the same paragraph says fasting and postprandial TG fell to 202–270 mg/dL; the 1,262 value is identical to the admission TG and may be a conflation. Recorded as a separate measurement flagged as ambiguous.
- Follow-up TG is given as 'approximately 214–489 mg/dL' (sec:6 ¶7, Fig. 4 legend) and as '200–500 mg/dL' / 'below 500 mg/dL' (sec:11 ¶5, abstract); the 214–489 range is recorded.
- Fig. 3 legend and sec:8 ¶4 state that two homozygous variants were detected in exon 1 of GPIHBP1, but only c.20del (p.Val7AlafsTer73) is described; the second variant is not specified anywhere in the text.
- ACMG/AMP classification 'pathogenic' (PVS1, PM2, PP4) is stated in sec:8 ¶6; the variant is reported as absent from ClinVar, HGMD and gnomAD. The p. notation is recorded exactly as written (p.Val7AlafsTer73).
- Negative results for LPL, apoC-II (APOC2), apoA-V (APOA5) and LMF1 are recorded as genetic_findings entries with variant_text 'No pathogenic variant detected' (HGNC symbols used; paper writes protein names apoC-II/apoA-V) and as EXCLUDED diagnoses.
- The childhood diagnosis of 'primary chylomicronemia' / 'FCS' was a clinical diagnosis later specified molecularly as GPIHBP1 deficiency; it is recorded as REVISED_FROM to preserve the age at clinical diagnosis (infancy), not because it was wrong.
- Consanguinity: the patient 'reported a history of consanguineous marriage in her family; however, the details were unclear' (sec:5 ¶5); parental consanguinity is not explicitly stated.
- Country of care (Japan) is inferred from the institution (Rinku General Medical Center) and the sequencing provider (KUBIX Inc., Hakusan, Ishikawa, Japan); ancestry is not stated.
- Age at last follow-up is not stated; Fig. 4 dates are anonymized (5/30/XXXX admission, 6/2/XXXX strict low-fat diet, 6/11/XXXX discharge).
- Regarding the second pregnancy, sec:5 ¶1 says she delivered without pancreatitis and discontinued follow-up, while sec:10 ¶1 adds that hospitalization was required to prevent pancreatitis.
- At presentation she was on no lipid-lowering therapy, did not drink alcohol and had never smoked (sec:5 ¶4). Blood pressure 142/98 mmHg is reported without comment by the authors and is not recorded as a phenotype.