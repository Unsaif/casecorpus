# PMID_42653298_father_II_1
**Source:** PMID 42653298 · International journal of molecular sciences 2026 · DOI 10.3390/ijms27167294 · licence: None · tier: epmc
**Individual:** father (II-1) · sex MALE · onset P19Y (At 19 years of age) · presentation – · last follow-up P45Y (45 years old (at study enrolment)) · ALIVE
**Evidence verification:** 17/45 quotes found in their anchored unit, 45/45 anywhere in the document; narrative source: extractor

## Patient description (verbatim from the source, by anchor)

> **[abstract]** Multiple acyl-CoA dehydrogenase deficiency (MADD) is considered an autosomal recessive disorder; yet, recent findings suggest up to 10% of cases may result from heterozygous electron transfer flavoprotein dehydrogenase (ETFDH) variants exhibiting dominant or dominant-like effects. Here, a novel heterozygous ETFDH variant (c.1798A>C, p.Asn600His) was identified within a three-generation family. The grandfather presented with muscular weakness at age 35, and the father developed similar symptoms at 19 following a tonsillectomy. Both were diagnosed with MADD based on muscle biopsies revealing neutral lipid accumulation and acylcarnitine profiles and responded fully to riboflavin therapy (150 mg/day). The two siblings, aged 8 and 10, carry the same mutation and show increased acyl-carnitine levels but remain asymptomatic due to early riboflavin treatment. Skin fibroblasts from affected individuals were immortalized and subjected to normal and reduced riboflavin levels. Gene expression analysis demonstrated unchanged ETFDH RNA but reduced protein levels in mutant cells, particularly under low riboflavin. Structural modelling suggested the Asn600His substitution destabilizes the protein, diminishing its mitochondrial function. Proximity ligation assays indicated a decreased interaction with mitochondrial complex III, while oxygen consumption via fatty acid oxidation was impaired, especially at reduced riboflavin. The novel ETFDH variant found in this family gives a possible dominant pattern of inheritance for MADD, where a single mutant allele impairs the mitochondrial metabolism, particularly under riboflavin-deficient conditions, and highlights the importance of early riboflavin supplementation in preventing clinical symptoms.
>
> **[sec:3 ¶1]** In this study, we report the biochemical profile of a family (grandfather, father, and two siblings; Supplementary Figure S1) in which the two older subjects (grandfather and father) display symptoms associated with MADD. In both the father and the siblings, riboflavin induced a dramatic change in the acylcarnitine pattern, with a complete normalization in the youngest sibling (Table 1).
>
> **[sec:4 ¶1]** The grandfather, the father, and the two siblings underwent Whole Exome Analysis; the only variation linked to the pathology was identified on the gene ETFDH, while, on the other genes linked to beta-oxidation, no other putative variations were found. The ETFDH (NM_004453.4): c.1798A>C, p. (Asn600His) variant was classified as likely pathogenic according to the ACGS/ACMG-AMP criteria PM1_moderate, PP2_supporting, PM2_moderate, and PP3_supporting (https://franklin.genoox.com/clinical-db/home, accessed on 10 February 2026). This variant is present in population databases (rs770905850, gnomAD 0.003%) and has not been reported in the literature in individuals affected with ETFDH-related conditions.
>
> **[sec:4 ¶2]** Whole genome analysis in the father revealed no other putative nucleotide variations that could be causative of the disease. Interestingly, the inheritance pattern in the family appears to be autosomal-dominant, while MADD is a typical autosomal-recessive disorder.
>
> **[sec:5 ¶1]** To perform functional studies in vitro, we obtained primary skin fibroblasts from a punch biopsy and immortalized them by hTERT-Cdk4 viral transduction. The Sanger sequencing of cDNA confirmed the presence of the c.1798A>C (p.Asn600His) ETFDH variant in RNA from fibroblasts of all the three affected family members, while the variant was absent in the healthy control (Supplementary Figure S2), thus representing a good cellular model for downstream analysis.
>
> **[sec:5 ¶2]** To further assess if the inheritance pattern could be explained by allelic variance, digital PCR analysis further quantified the allelic expression, showing that the mutant and wild-type transcripts in fibroblasts from the patients were each expressed at approximately 50%, indicating no allele-specific transcript imbalance (Supplementary Figure S3).
>
> **[sec:7 ¶1]** Aiming to confirm the in silico observation, we sought to assess the ETFDH protein levels. Fibroblasts from the affected father (HCM1) and his two children (HCM2 and HCM3) displayed approximately 50% of ETFDH protein levels (* = p < 0.05; ** = p < 0.01, one-way ANOVA) relative to the healthy control (HC0215) (Figure 3) even under standard riboflavin conditions, despite a similar mRNA expression (Figure 4A). Decreasing riboflavin concentrations (5 nM, 20 nM, 100 nM, and 500 nM) compared to standard culture medium (~1 μM riboflavin) were used to assess a minimum dose at which treatment can restore protein control levels. Western blot analysis showed no significant changes in ETFDH protein in HCM2, HCM3, or HC0215 cells under any of the tested conditions. In contrast, in HCM1 fibroblasts, the ETFDH protein expression was significantly lower in cells treated with 5 nM riboflavin compared with standard medium (Figure 4B, * = p < 0.05, one-way ANOVA, Dunnett’s post-test). To assess if the effect of riboflavin on the ETFDH expression is due to the modulation of RNA levels, RT-qPCR analysis was performed on immortalized fibroblasts from the affected father (HCM1), the two siblings (HCM2 and HCM3), and a healthy control (HC0215). Cells were thus treated for one week under varying riboflavin concentrations (5 nM, 20 nM, 100 nM, and 500 nM, compared with the standard medium at ~1 µM), and assessed for ETFDH-specific mRNA expression. No statistically significant differences in ETFDH mRNA levels were observed at any of the tested riboflavin concentrations within each cell line compared with standard culture conditions (Figure 4A).
>
> **[sec:7 ¶2]** Furthermore, to determine the mitochondrial mass and thus assessing if the reduction in mitochondrial ETFDH is due to the reduction in mitochondrial number/mass, an analysis of the mitochondrial number was performed using mitoRED staining (Supplementary Figure S5). No significant changes in riboflavin-supplemented cell lines were observed, while, after riboflavin withdrawal, only HCM1 displays a significantly increased mitochondrial content.
>
> **[sec:8 ¶2]** A quantitative analysis of the PLA signal revealed a significant reduction in the number of PLA dots per nucleus in HCM1 and HCM3 fibroblasts under riboflavin-depleted conditions compared to riboflavin-supplemented cells (* = p < 0.05; ** = p < 0.01, unpaired t test) (Figure 5C,E), indicating a reduction in the interaction between ETFDH and complex III. In contrast, no significant differences were observed in HCM2 or in the healthy control cell line HC0215 (Figure 5B,D). The absence of a significant difference in HCM2 is possibly due to the age of the patient, being the youngest of the family. These findings indicate a riboflavin-dependent modification of ETFDH and complex III interactions in a subset of patient-derived fibroblasts, consistent with a cell-line-specific vulnerability to flavin depletion.
>
> **[sec:9 ¶1]** To further assess the effect of riboflavine depletion, we decided to use HRR that permits the analysis of the respiratory state, separating them by the use of specific mitochondrial inhibitors. Using this approach, we estimate the oxygen consumption rate when octanolyl-carnitine (OCT) was used as the substrate and we found that, in low riboflavin concentrations (5 nM), the oxygen consumption was lower in respect to the standard riboflavine concentration (1 µM) in all the patients cell lines (HCM1, HCM2, and HCM3) but not in controls (HC0125) (Figure 6, * p < 0.05, ANOVA, Bonferroni’s correction).
>
> **[sec:10 ¶1]** Although Multiple Acyl-CoA Dehydrogenase Deficiency (MADD) is typically considered an autosomal recessive disorder, recent data suggest that a non-negligible fraction of patients may carry only a single pathogenic ETFDH allele. In fact, a recent meta-analysis found that approximately 10% of late-onset MADD patients harbour a single heterozygous ETFDH variant with a milder phenotype compared to bi-allelic carriers, raising the possibility of more complex inheritance or non–loss-of-function mechanisms [3]. Consistently, the family described here presents a clinically significant phenotype (fatigue, high carnitine levels, and lipid accumulation in muscles) carrying only one copy of the ETFDH c.1798A>C (p.Asn600His) variant. The presence of symptoms in both the grandfather and the father—despite carrying only one mutated allele—is unexpected for a recessive disorder and strongly supports a dominant or haploinsufficient contribution of this specific variant. Furthermore, the children display an altered acylcarnitine profile, compatible with MADD, further strengthening the dominant model of inheritance. Whole genome analysis (as suggested by Zhang et al., 2025) [3] did not reveal a “hidden” variant in the ETFDH gene. Indeed, these observations could suggest a dominant mode of inheritance; however, further data (i.e., the same mutation in other families, unrelated to this one) are needed to truly confirm the dominant pattern.
>
> **[sec:10 ¶2]** At the transcript level, digital PCR demonstrated an equal distribution of wild-type and mutant alleles (50% each), indicating that no allelic imbalance occurs. However, despite the equal transcript abundance, the total ETFDH protein levels were reduced by approximately 50% or more. This discrepancy between transcript levels and protein abundance indicates that the mutation does not affect transcription, but, rather, impairs post-transcriptional processes such as folding, stability, or degradation, as previously shown for other mutations [11,12].
>
> **[sec:10 ¶5]** Functionally, the reduced levels of total ETFDH protein were accompanied by decreased mitochondrial respiration in the FAO pathway (in the reduced riboflavin condition), while the total mitochondrial mass/number is unchanged (Supplementary Figure S5), indicating, once more, a defect in the electron chain transport from ETFDH to complex III. Moreover, mutant cells display a reduced association of ETFDH with complex III in the absence of riboflavin supplementation. These defects are consistent with the impaired electron transfer within the ETF–ETFDH–UQ axis, as indicated by the HRR results, where, in the depleted-riboflavin condition, the respiration rate is reduced in patients’ cells, while it does not change in control fibroblasts, suggesting, then, a defect in the entry of electrons’ mitochondrial respiratory chain from the fatty acid oxidation pathway. Under the conditions of limited riboflavin availability, the mitochondrial FAD is reduced and mutant ETFDH stability is impaired, as has been demonstrated by Xu et al. in other model systems [12]. Our results indicate that, when riboflavin was supplemented, mutant ETFDH rescued the interaction with complex III, accompanied by an overall improvement in cellular respiration. These effects are consistent with the known clinical response to riboflavin therapy, indicating that the biochemical defects caused by the mutation are at least partially reversible.
>
> **[sec:10 ¶6]** Interestingly, despite these molecular and bioenergetic defects, we did not observe significant differences in the mitochondrial membrane potential (Δψ) between patient fibroblasts and controls, both in the basal or under reduced riboflavin condition (Supplementary Figure S6). This observation reflects the finding detected in HRR, where only in the FAO pathway is the OCR reduced, while the total electron transfer capacity (ETC) is preserved. Indeed, ROS levels also did not show any changes (except for the father’s HCM1 cell line) (Supplementary Figure S7), indicating that the pathogenic mechanism relies only on the loss of electron flux from the FAO pathway. Together, these data support a model in which the p.Asn600His variant acts through a structurally disruptive mechanism, by reducing the total protein abundance, impairing the ETFDH function, and, ultimately, altering the mitochondrial energy metabolism even in the presence of one intact allele. This mechanistic insight may contribute to a better understanding of rare dominant presentations of riboflavin-responsive MADD and highlights the importance of evaluating the ETFDH protein stability and electron transfer efficiency in addition to genetic status alone.
>
> **[sec:12 ¶1]** The family was enrolled at the Rare Disease Unit of IRCCS Burlo Garofolo (Trieste, Italy). The study was conducted in accordance with the Declaration of Helsinki and approved by the Ethics Committee of I.R.C.C.S. “Burlo Garofolo” (protocol code 02/2024 22.02.2024 approved on 28 March 2024). Informed consent was obtained from all subjects involved in the study. It comprised a grandfather (71 years old) (I-1 in Supplementary Figure S1), father (45 years old) (II-1 in Supplementary Figure S1), both with a biochemical and histological diagnosis of MADD, and his daughter and his son (8 and 10 years old, respectively) (III-2 and III-1, respectively, in Supplementary Figure S1). Family history was carefully collected for all recruited individuals, including geographical origin and potential consanguinity. No family was found to originate from a genetic isolate or to report known consanguinity within the last three generations.
>
> **[sec:12 ¶2]** Specifically, the grandfather developed progressive muscle weakness in his thirties and was diagnosed with MADD based on muscle biopsy showing lipid accumulation and an altered blood acylcarnitine profile. At 19 years of age, the father developed muscle weakness following tonsillectomy and was subsequently diagnosed with MADD based on biochemical laboratory findings (elevated blood acylcarnitine levels) and mild lipid accumulation on muscle biopsy. In both patients, symptoms receded with riboflavin therapy (150 mg/day). Despite an altered blood acylcarnitine profile, the children were asymptomatic; nevertheless, riboflavin was administered as a preventive measure at a very early age (after weaning). All family members carried underwent Whole Exome Analysis and the only variant found linked to the phenotype is the ETFDH variant (NM_004453.4) c.1798A>C in heterozygosity.
>
> **[sec:13 ¶1]** Primary skin fibroblasts derived from a punch biopsy from the father and the two children were cultured in DMEM high-glucose supplemented with l-glutamine, 10% fetal bovine serum (FBS) and 1% penicillin/streptomycin, and vitamin solution (MEM, EuroClone, Milan, Italy, ECM0556D). Cultures were maintained at 37 °C and 5% CO2 following standard procedures. Cells were immortalized using a cell immortalization kit from ABM (Lenti-hTERT Virus, ABM, Richmond, BC, Canada) and these cell lines were employed in all experiments. Cell lines identification: HCM1 from father (II-1 Supplementary Figure S1), HCM2 from daughter (III-2 Supplementary Figure S1), and HCM3 from son (III-1 Supplementary Figure S1).
>
> **[sec:16 ¶1]** Sequencing of the whole gene was performed by Eurofins Genomics (Eurofins Scientific, Vimodrone, Italy). Briefly, DNA from whole blood of the father (M1) was extracted, and sent to the company. There, the DNA was amplified with specific primer for NGS sequencing (amplicon sequencing) covering the entire ETFDH sequence, and sequenced using NovaSeq (Illumina, San Diego, CA, USA). Data were subsequently analysed using Emdgene software (V35.9) (Illumina, San Diego, CA, USA).
>
> **[tab:1 c2]** : M1
C0: 58.71
C5DC + C6OH: 0.26
C6: 1.13
C6DC: 0.44
C8: 5.07
C10: 5.19
C10:1: 1.16
C12: 0.56
C12:1: 0.24
C14: 0.13
C14:1: 0.4
C14:2: 0.11
C16: 0.13
C16:1: 0.05
>
> **[tab:1 c3]** : B2
C0: \
C5DC + C6OH: 0.22
C6: 0.34
C6DC: 0.18
C8: 1.31
C10: 1.63
C10:1: \
C12: \
C12:1: \
C14: \
C14:1: 0.06
C14:2: \
C16: \
C16:1: \
>

## Diagnoses

- ✓ **FINAL** Multiple acyl-CoA dehydrogenase deficiency (MADD) → multiple acyl-CoA dehydrogenase deficiency MONDO:0009282 OMIM:231680 · tier MOLECULAR · route symptomatic  
  “At 19 years of age, the father developed muscle weakness following tonsillectomy and was subsequently diagnosed with MADD based on biochemical laboratory findings (elevated blood acylcarnitine levels) and mild lipid accumulation on muscle biopsy.” [sec:12 ¶2]

## Genetic findings

- ✓ **ETFDH** c.1798A>C p.(Asn600His) · HETEROZYGOUS · likely_pathogenic · WES; whole genome analysis; ETFDH amplicon NGS on whole-blood DNA; Sanger sequencing of fibroblast cDNA; digital PCR  
  “All family members carried underwent Whole Exome Analysis and the only variant found linked to the phenotype is the ETFDH variant (NM_004453.4) c.1798A>C in heterozygosity.” [sec:12 ¶2]

## Measurements

| ✓ | analyte | specimen | value | unit | ref | interp | timing | quote [anchor] |
|---|---|---|---|---|---|---|---|---|
| ✓ | blood acylcarnitine levels → acylcarnitine profile | blood | elevated |  |  | HIGH | at diagnosis (after onset at 19 years) | “At 19 years of age, the father developed muscle weakness following tonsillectomy and was subsequently diagnosed with MAD” [sec:12 ¶2] |
| ~ | C0 → free carnitine | blood | 58.71 |  | 19.93–52.78 | HIGH | before riboflavin treatment | “/ r2 / C0 / 58.71 / \ / 54.75 / \ / 41.06 / \ / 19.93–52.78 /” [tab:1 r2c2] |
| ~ | C0 → free carnitine | blood | \ (normalization of the parameter) |  | 19.93–52.78 | NORMAL | after riboflavin treatment (B2) | “/ r2 / C0 / 58.71 / \ / 54.75 / \ / 41.06 / \ / 19.93–52.78 /” [tab:1 r2c3] |
| ~ | C5DC + C6OH → glutarylcarnitine | blood | 0.26 |  | 0.04–0.11 | HIGH | before riboflavin treatment | “/ r3 / C5DC + C6OH / 0.26 / 0.22 /  /  /  /  / 0.04–0.11 /” [tab:1 r3c2] |
| ~ | C5DC + C6OH → glutarylcarnitine | blood | 0.22 |  | 0.04–0.11 | HIGH | after riboflavin treatment (B2) | “/ r3 / C5DC + C6OH / 0.26 / 0.22 /  /  /  /  / 0.04–0.11 /” [tab:1 r3c3] |
| ~ | C6 → hexanoylcarnitine | blood | 1.13 |  | 0.03–0.16 | HIGH | before riboflavin treatment | “/ r4 / C6 / 1.13 / 0.34 /  /  /  /  / 0.03–0.16 /” [tab:1 r4c2] |
| ~ | C6 → hexanoylcarnitine | blood | 0.34 |  | 0.03–0.16 | HIGH | after riboflavin treatment (B2) | “/ r4 / C6 / 1.13 / 0.34 /  /  /  /  / 0.03–0.16 /” [tab:1 r4c3] |
| ~ | C6DC → adipoylcarnitine (C6DC) | blood | 0.44 |  | 0.03–0.13 | HIGH | before riboflavin treatment | “/ r5 / C6DC / 0.44 / 0.18 /  /  /  /  / 0.03–0.13 /” [tab:1 r5c2] |
| ~ | C6DC → adipoylcarnitine (C6DC) | blood | 0.18 |  | 0.03–0.13 | HIGH | after riboflavin treatment (B2) | “/ r5 / C6DC / 0.44 / 0.18 /  /  /  /  / 0.03–0.13 /” [tab:1 r5c3] |
| ~ | C8 → octanoylcarnitine | blood | 5.07 |  | 0.05–0.46 | HIGH | before riboflavin treatment | “/ r6 / C8 / 5.07 / 1.31 / 2.33 / 0.66 / 0.93 / \ / 0.05–0.46 /” [tab:1 r6c2] |
| ~ | C8 → octanoylcarnitine | blood | 1.31 |  | 0.05–0.46 | HIGH | after riboflavin treatment (B2) | “/ r6 / C8 / 5.07 / 1.31 / 2.33 / 0.66 / 0.93 / \ / 0.05–0.46 /” [tab:1 r6c3] |
| ~ | C10 → decanoylcarnitine | blood | 5.19 |  | 0.09–0.87 | HIGH | before riboflavin treatment | “/ r7 / C10 / 5.19 / 1.63 / 4.11 / 1.11 / 1.45 / \ / 0.09–0.87 /” [tab:1 r7c2] |
| ~ | C10 → decanoylcarnitine | blood | 1.63 |  | 0.09–0.87 | HIGH | after riboflavin treatment (B2) | “/ r7 / C10 / 5.19 / 1.63 / 4.11 / 1.11 / 1.45 / \ / 0.09–0.87 /” [tab:1 r7c3] |
| ~ | C10:1 → decenoylcarnitine | blood | 1.16 |  | 0.04–0.37 | HIGH | before riboflavin treatment | “/ r8 / C10:1 / 1.16 / \ / 0.88 / \ / 0.51 / \ / 0.04–0.37 /” [tab:1 r8c2] |
| ~ | C10:1 → decenoylcarnitine | blood | \ (normalization of the parameter) |  | 0.04–0.37 | NORMAL | after riboflavin treatment (B2) | “/ r8 / C10:1 / 1.16 / \ / 0.88 / \ / 0.51 / \ / 0.04–0.37 /” [tab:1 r8c3] |
| ~ | C12 → dodecanoylcarnitine | blood | 0.56 |  | 0.03–0.25 | HIGH | before riboflavin treatment | “/ r9 / C12 / 0.56 / \ / 0.46 / \ / 0.13 / \ / 0.03–0.25 /” [tab:1 r9c2] |
| ~ | C12 → dodecanoylcarnitine | blood | \ (normalization of the parameter) |  | 0.03–0.25 | NORMAL | after riboflavin treatment (B2) | “/ r9 / C12 / 0.56 / \ / 0.46 / \ / 0.13 / \ / 0.03–0.25 /” [tab:1 r9c3] |
| ~ | C12:1 → dodecenoylcarnitine (C12:1) | blood | 0.24 |  | 0.03–0.25 | NORMAL | before riboflavin treatment | “/ r10 / C12:1 / 0.24 / \ / 0.24 / \ /  /  / 0.03–0.25 /” [tab:1 r10c2] |
| ~ | C12:1 → dodecenoylcarnitine (C12:1) | blood | \ (normalization of the parameter) |  | 0.03–0.25 | NORMAL | after riboflavin treatment (B2) | “/ r10 / C12:1 / 0.24 / \ / 0.24 / \ /  /  / 0.03–0.25 /” [tab:1 r10c3] |
| ~ | C14 → tetradecanoylcarnitine | blood | 0.13 |  | 0.01–0.05 | HIGH | before riboflavin treatment | “/ r11 / C14 / 0.13 / \ /  /  /  /  / 0.01–0.05 /” [tab:1 r11c2] |
| ~ | C14 → tetradecanoylcarnitine | blood | \ (normalization of the parameter) |  | 0.01–0.05 | NORMAL | after riboflavin treatment (B2) | “/ r11 / C14 / 0.13 / \ /  /  /  /  / 0.01–0.05 /” [tab:1 r11c3] |
| ~ | C14:1 → tetradecenoylcarnitine | blood | 0.4 |  | 0.03–0.23 | HIGH | before riboflavin treatment | “/ r12 / C14:1 / 0.4 / 0.06 / 0.3 / \ /  /  / 0.03–0.23 /” [tab:1 r12c2] |
| ~ | C14:1 → tetradecenoylcarnitine | blood | 0.06 |  | 0.03–0.23 | NORMAL | after riboflavin treatment (B2) | “/ r12 / C14:1 / 0.4 / 0.06 / 0.3 / \ /  /  / 0.03–0.23 /” [tab:1 r12c3] |
| ~ | C14:2 → tetradecadienoylcarnitine (C14:2) | blood | 0.11 |  | 0.01–0.10 | HIGH | before riboflavin treatment | “/ r13 / C14:2 / 0.11 / \ / 0.12 / \ / 0.06 / \ / 0.01–0.10 /” [tab:1 r13c2] |
| ~ | C14:2 → tetradecadienoylcarnitine (C14:2) | blood | \ (normalization of the parameter) |  | 0.01–0.10 | NORMAL | after riboflavin treatment (B2) | “/ r13 / C14:2 / 0.11 / \ / 0.12 / \ / 0.06 / \ / 0.01–0.10 /” [tab:1 r13c3] |
| ~ | C16 → palmitoylcarnitine | blood | 0.13 |  | 0.04–0.12 | HIGH | before riboflavin treatment | “/ r14 / C16 / 0.13 / \ /  /  /  /  / 0.04–0.12 /” [tab:1 r14c2] |
| ~ | C16 → palmitoylcarnitine | blood | \ (normalization of the parameter) |  | 0.04–0.12 | NORMAL | after riboflavin treatment (B2) | “/ r14 / C16 / 0.13 / \ /  /  /  /  / 0.04–0.12 /” [tab:1 r14c3] |
| ~ | C16:1 → hexadecenoylcarnitine (C16:1) | blood | 0.05 |  | 0.01–0.04 | HIGH | before riboflavin treatment | “/ r15 / C16:1 / 0.05 / \ / 0.05 / \ /  /  / 0.01–0.04 /” [tab:1 r15c2] |
| ~ | C16:1 → hexadecenoylcarnitine (C16:1) | blood | \ (normalization of the parameter) |  | 0.01–0.04 | NORMAL | after riboflavin treatment (B2) | “/ r15 / C16:1 / 0.05 / \ / 0.05 / \ /  /  / 0.01–0.04 /” [tab:1 r15c3] |
| ✓ | ETFDH protein level (immunoblot, immortalized skin fibroblasts HCM1) → ETFDH protein | fibroblasts | 50 | % of healthy control |  | LOW |  | “Fibroblasts from the affected father (HCM1) and his two children (HCM2 and HCM3) displayed approximately 50% of ETFDH pr” [sec:7 ¶1] |
| ✓ | ETFDH mRNA expression (RT-qPCR, immortalized skin fibroblasts HCM1) → ETFDH mRNA | fibroblasts | similar mRNA expression relative to the healthy control |  |  | NORMAL |  | “relative to the healthy control (HC0215) (Figure 3) even under standard riboflavin conditions, despite a similar mRNA ex” [sec:7 ¶1] |
| ✓ | ETFDH mRNA expression under reduced riboflavin (RT-qPCR, fibroblasts HCM1) → ETFDH mRNA | fibroblasts | no statistically significant differences at any tested riboflavin concentration compared with standard culture conditions |  |  | NORMAL |  | “No statistically significant differences in ETFDH mRNA levels were observed at any of the tested riboflavin concentratio” [sec:7 ¶1] |
| ✓ | ETFDH mutant vs wild-type transcript allelic expression (digital PCR, fibroblasts HCM1) → ETFDH c.1798A>C allele-specific transcript fraction | fibroblasts | 50 | % |  | NORMAL |  | “digital PCR analysis further quantified the allelic expression, showing that the mutant and wild-type transcripts in fib” [sec:5 ¶2] |
| ✓ | oxygen consumption rate with octanoylcarnitine substrate (high-resolution respirometry, fibroblasts HCM1) → fatty acid oxidation-supported oxygen consumption rate | fibroblasts | lower at 5 nM riboflavin than at the standard 1 µM riboflavin concentration (not in controls) |  |  | LOW |  | “in low riboflavin concentrations (5 nM), the oxygen consumption was lower in respect to the standard riboflavine concent” [sec:9 ¶1] |
| ✓ | mitochondrial membrane potential (JC-1, fibroblasts HCM1) → mitochondrial membrane potential | fibroblasts | no significant differences between patient fibroblasts and controls |  |  | NORMAL |  | “we did not observe significant differences in the mitochondrial membrane potential (Δψ) between patient fibroblasts and ” [sec:10 ¶6] |
| ✓ | ETFDH protein level under 5 nM riboflavin (immunoblot, fibroblasts HCM1) → ETFDH protein | fibroblasts | significantly lower in cells treated with 5 nM riboflavin compared with standard medium |  |  | LOW |  | “In contrast, in HCM1 fibroblasts, the ETFDH protein expression was significantly lower in cells treated with 5 nM ribofl” [sec:7 ¶1] |
| ✓ | mitochondrial content after riboflavin withdrawal (mitoRED staining, fibroblasts HCM1) → mitochondrial mass/number | fibroblasts | significantly increased mitochondrial content (only HCM1) |  |  | HIGH |  | “No significant changes in riboflavin-supplemented cell lines were observed, while, after riboflavin withdrawal, only HCM” [sec:7 ¶2] |
| ✓ | ETFDH-complex III interaction, PLA dots per nucleus (proximity ligation assay, fibroblasts HCM1) → ETFDH-complex III proximity ligation signal | fibroblasts | significant reduction in the number of PLA dots per nucleus under riboflavin-depleted conditions |  |  | LOW |  | “A quantitative analysis of the PLA signal revealed a significant reduction in the number of PLA dots per nucleus in HCM1” [sec:8 ¶2] |
| ✓ | intracellular reactive oxygen species (CellROX, fibroblasts HCM1) → reactive oxygen species | fibroblasts | ROS levels changed in the father's HCM1 cell line (direction not stated); unchanged in other lines |  |  | ABNORMAL |  | “Indeed, ROS levels also did not show any changes (except for the father’s HCM1 cell line) (Supplementary Figure S7)” [sec:10 ¶6] |

## Phenotypes

- ✓ Muscle weakness → Muscle weakness HP:0001324 (grounded)  
  “At 19 years of age, the father developed muscle weakness following tonsillectomy and was subsequently diagnosed with MADD based on biochemical laboratory findings (elevated blood acylcarnitine levels) and mild lipid accumulation on muscle biopsy.” [sec:12 ¶2]
- ✓ Increased muscle lipid content → Increased muscle lipid content HP:0009058 (grounded)  
  “At 19 years of age, the father developed muscle weakness following tonsillectomy and was subsequently diagnosed with MADD based on biochemical laboratory findings (elevated blood acylcarnitine levels) and mild lipid accumulation on muscle biopsy.” [sec:12 ¶2]
- ✓ Fatigue → Fatigue HP:0012378 (grounded)  
  “Consistently, the family described here presents a clinically significant phenotype (fatigue, high carnitine levels, and lipid accumulation in muscles) carrying only one copy of the ETFDH c.1798A>C (p.Asn600His) variant.” [sec:10 ¶1]

## Treatments

- ✓ cofactor_vitamin: riboflavin · response improved  
  “In both patients, symptoms receded with riboflavin therapy (150 mg/day).” [sec:12 ¶2]

## Outcome

Symptoms receded on riboflavin therapy (150 mg/day); acylcarnitine profile improved but not fully normalized after a first riboflavin treatment; alive at 45 years at study enrolment.

## Model summary (not source text)

The father (II-1; cell line HCM1, table label M1) developed muscle weakness at 19 years of age following tonsillectomy and was subsequently diagnosed with MADD on the basis of elevated blood acylcarnitine levels and mild lipid accumulation on muscle biopsy. His blood acylcarnitine profile before riboflavin showed elevated free carnitine (C0 58.71) and elevated medium- and long-chain species, most markedly C8 (5.07) and C10 (5.19); after riboflavin most species normalized while C5DC+C6OH, C6, C6DC, C8 and C10 remained above the reference range. Whole exome and whole genome analyses identified only the heterozygous ETFDH variant NM_004453.4:c.1798A>C, p.(Asn600His), classified as likely pathogenic, also carried by his father and his two children. Symptoms receded on riboflavin 150 mg/day. Immortalized skin fibroblasts (HCM1) showed approximately 50% ETFDH protein with normal mRNA levels and equal allelic transcript expression, a further fall in ETFDH protein at 5 nM riboflavin, reduced ETFDH-complex III interaction and reduced octanoylcarnitine-supported oxygen consumption under riboflavin depletion, with unchanged mitochondrial membrane potential.

## Extractor notes

- Table 1 gives no units for the acylcarnitine values (presumably µmol/L); unit left null. Reference ranges are taken from the 'Normal Ranges' column of the same row.
- Table 1 column mapping used: c2 = M1 (father) before riboflavin, c3 = M1 after riboflavin (B2); the symbol '\' in the table indicates normalization of the parameter and is recorded as value=null, interpretation=NORMAL.
- C12:1 before treatment (0.24) lies within the stated reference range 0.03–0.25 and is recorded as NORMAL even though the caption describes the profile as altered; C14:1 after riboflavin (0.06) is within range.
- Table caption notes that C8 and C10 (in bold in the original) are the most altered acylcarnitine species. Timing/age of the pre-treatment sample is not stated.
- Paternal inheritance of the variant is implied by its presence in the grandfather (I-1); the paper does not state transmission explicitly but describes an apparently autosomal dominant pattern.
- Variant classification (likely pathogenic; ACGS/ACMG-AMP PM1_moderate, PP2_supporting, PM2_moderate, PP3_supporting; rs770905850, gnomAD 0.003%; not previously reported in ETFDH-related conditions) is from sec:4 ¶1.
- Whole genome analysis in the father revealed no other putative causative variants; WES found no other putative variations in other beta-oxidation genes (sec:4).
- The father is also referred to as 'M1' (sec:16, Table 1) and his fibroblast line as 'HCM1'. Sec:9 refers to controls as 'HC0125' whereas elsewhere the control line is 'HC0215'.
- 'Fatigue', 'high carnitine levels' and 'lipid accumulation in muscles' are stated at family level (sec:10 ¶1); fatigue is included on that basis.
- The ROS change in HCM1 is reported only as an exception to 'no changes'; direction not stated (Supplementary Figure S7).
- Fibroblast assays are research measurements on an immortalized (hTERT) skin fibroblast line, not clinical laboratory values.