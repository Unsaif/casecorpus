# PMID_42653298_grandfather_I_1
**Source:** PMID 42653298 · International journal of molecular sciences 2026 · DOI 10.3390/ijms27167294 · licence: None · tier: epmc
**Individual:** grandfather (I-1) · sex MALE · onset P35Y (at age 35 (abstract); 'in his thirties' (Methods)) · presentation – · last follow-up P71Y (71 years old (at study enrolment)) · ALIVE
**Evidence verification:** 7/7 quotes found in their anchored unit, 7/7 anywhere in the document; narrative source: extractor

## Patient description (verbatim from the source, by anchor)

> **[abstract]** Multiple acyl-CoA dehydrogenase deficiency (MADD) is considered an autosomal recessive disorder; yet, recent findings suggest up to 10% of cases may result from heterozygous electron transfer flavoprotein dehydrogenase (ETFDH) variants exhibiting dominant or dominant-like effects. Here, a novel heterozygous ETFDH variant (c.1798A>C, p.Asn600His) was identified within a three-generation family. The grandfather presented with muscular weakness at age 35, and the father developed similar symptoms at 19 following a tonsillectomy. Both were diagnosed with MADD based on muscle biopsies revealing neutral lipid accumulation and acylcarnitine profiles and responded fully to riboflavin therapy (150 mg/day). The two siblings, aged 8 and 10, carry the same mutation and show increased acyl-carnitine levels but remain asymptomatic due to early riboflavin treatment. Skin fibroblasts from affected individuals were immortalized and subjected to normal and reduced riboflavin levels. Gene expression analysis demonstrated unchanged ETFDH RNA but reduced protein levels in mutant cells, particularly under low riboflavin. Structural modelling suggested the Asn600His substitution destabilizes the protein, diminishing its mitochondrial function. Proximity ligation assays indicated a decreased interaction with mitochondrial complex III, while oxygen consumption via fatty acid oxidation was impaired, especially at reduced riboflavin. The novel ETFDH variant found in this family gives a possible dominant pattern of inheritance for MADD, where a single mutant allele impairs the mitochondrial metabolism, particularly under riboflavin-deficient conditions, and highlights the importance of early riboflavin supplementation in preventing clinical symptoms.
>
> **[sec:3 ¶1]** In this study, we report the biochemical profile of a family (grandfather, father, and two siblings; Supplementary Figure S1) in which the two older subjects (grandfather and father) display symptoms associated with MADD. In both the father and the siblings, riboflavin induced a dramatic change in the acylcarnitine pattern, with a complete normalization in the youngest sibling (Table 1).
>
> **[sec:4 ¶1]** The grandfather, the father, and the two siblings underwent Whole Exome Analysis; the only variation linked to the pathology was identified on the gene ETFDH, while, on the other genes linked to beta-oxidation, no other putative variations were found. The ETFDH (NM_004453.4): c.1798A>C, p. (Asn600His) variant was classified as likely pathogenic according to the ACGS/ACMG-AMP criteria PM1_moderate, PP2_supporting, PM2_moderate, and PP3_supporting (https://franklin.genoox.com/clinical-db/home, accessed on 10 February 2026). This variant is present in population databases (rs770905850, gnomAD 0.003%) and has not been reported in the literature in individuals affected with ETFDH-related conditions.
>
> **[sec:10 ¶1]** Although Multiple Acyl-CoA Dehydrogenase Deficiency (MADD) is typically considered an autosomal recessive disorder, recent data suggest that a non-negligible fraction of patients may carry only a single pathogenic ETFDH allele. In fact, a recent meta-analysis found that approximately 10% of late-onset MADD patients harbour a single heterozygous ETFDH variant with a milder phenotype compared to bi-allelic carriers, raising the possibility of more complex inheritance or non–loss-of-function mechanisms [3]. Consistently, the family described here presents a clinically significant phenotype (fatigue, high carnitine levels, and lipid accumulation in muscles) carrying only one copy of the ETFDH c.1798A>C (p.Asn600His) variant. The presence of symptoms in both the grandfather and the father—despite carrying only one mutated allele—is unexpected for a recessive disorder and strongly supports a dominant or haploinsufficient contribution of this specific variant. Furthermore, the children display an altered acylcarnitine profile, compatible with MADD, further strengthening the dominant model of inheritance. Whole genome analysis (as suggested by Zhang et al., 2025) [3] did not reveal a “hidden” variant in the ETFDH gene. Indeed, these observations could suggest a dominant mode of inheritance; however, further data (i.e., the same mutation in other families, unrelated to this one) are needed to truly confirm the dominant pattern.
>
> **[sec:12 ¶1]** The family was enrolled at the Rare Disease Unit of IRCCS Burlo Garofolo (Trieste, Italy). The study was conducted in accordance with the Declaration of Helsinki and approved by the Ethics Committee of I.R.C.C.S. “Burlo Garofolo” (protocol code 02/2024 22.02.2024 approved on 28 March 2024). Informed consent was obtained from all subjects involved in the study. It comprised a grandfather (71 years old) (I-1 in Supplementary Figure S1), father (45 years old) (II-1 in Supplementary Figure S1), both with a biochemical and histological diagnosis of MADD, and his daughter and his son (8 and 10 years old, respectively) (III-2 and III-1, respectively, in Supplementary Figure S1). Family history was carefully collected for all recruited individuals, including geographical origin and potential consanguinity. No family was found to originate from a genetic isolate or to report known consanguinity within the last three generations.
>
> **[sec:12 ¶2]** Specifically, the grandfather developed progressive muscle weakness in his thirties and was diagnosed with MADD based on muscle biopsy showing lipid accumulation and an altered blood acylcarnitine profile. At 19 years of age, the father developed muscle weakness following tonsillectomy and was subsequently diagnosed with MADD based on biochemical laboratory findings (elevated blood acylcarnitine levels) and mild lipid accumulation on muscle biopsy. In both patients, symptoms receded with riboflavin therapy (150 mg/day). Despite an altered blood acylcarnitine profile, the children were asymptomatic; nevertheless, riboflavin was administered as a preventive measure at a very early age (after weaning). All family members carried underwent Whole Exome Analysis and the only variant found linked to the phenotype is the ETFDH variant (NM_004453.4) c.1798A>C in heterozygosity.
>

## Diagnoses

- ✓ **FINAL** Multiple acyl-CoA dehydrogenase deficiency (MADD) → multiple acyl-CoA dehydrogenase deficiency MONDO:0009282 OMIM:231680 · tier MOLECULAR · route symptomatic  
  “Specifically, the grandfather developed progressive muscle weakness in his thirties and was diagnosed with MADD based on muscle biopsy showing lipid accumulation and an altered blood acylcarnitine profile.” [sec:12 ¶2]

## Genetic findings

- ✓ **ETFDH** c.1798A>C p.(Asn600His) · HETEROZYGOUS · likely_pathogenic · WES  
  “All family members carried underwent Whole Exome Analysis and the only variant found linked to the phenotype is the ETFDH variant (NM_004453.4) c.1798A>C in heterozygosity.” [sec:12 ¶2]

## Measurements

| ✓ | analyte | specimen | value | unit | ref | interp | timing | quote [anchor] |
|---|---|---|---|---|---|---|---|---|
| ✓ | blood acylcarnitine profile → acylcarnitines | blood | altered |  |  | ABNORMAL | at diagnosis | “Specifically, the grandfather developed progressive muscle weakness in his thirties and was diagnosed with MADD based on” [sec:12 ¶2] |

## Phenotypes

- ✓ Muscle weakness → Muscle weakness HP:0001324 (grounded)  
  “Specifically, the grandfather developed progressive muscle weakness in his thirties and was diagnosed with MADD based on muscle biopsy showing lipid accumulation and an altered blood acylcarnitine profile.” [sec:12 ¶2]
- ✓ Increased muscle lipid content → Increased muscle lipid content HP:0009058 (grounded)  
  “Specifically, the grandfather developed progressive muscle weakness in his thirties and was diagnosed with MADD based on muscle biopsy showing lipid accumulation and an altered blood acylcarnitine profile.” [sec:12 ¶2]
- ✓ Fatigue → Fatigue HP:0012378 (grounded)  
  “Consistently, the family described here presents a clinically significant phenotype (fatigue, high carnitine levels, and lipid accumulation in muscles) carrying only one copy of the ETFDH c.1798A>C (p.Asn600His) variant.” [sec:10 ¶1]

## Treatments

- ✓ cofactor_vitamin: riboflavin · response improved  
  “In both patients, symptoms receded with riboflavin therapy (150 mg/day).” [sec:12 ¶2]

## Outcome

Symptoms receded on riboflavin therapy (150 mg/day); alive at 71 years at study enrolment.

## Model summary (not source text)

The grandfather (I-1) of a three-generation Italian family developed progressive muscle weakness in his thirties (age 35 per the abstract). He was diagnosed with MADD on the basis of a muscle biopsy showing lipid accumulation and an altered blood acylcarnitine profile. Whole exome analysis identified the heterozygous ETFDH variant NM_004453.4:c.1798A>C, p.(Asn600His), classified as likely pathogenic, as the only variant linked to the phenotype. His symptoms receded with riboflavin therapy (150 mg/day). He was 71 years old at study enrolment.

## Extractor notes

- Age at onset: abstract says 'muscular weakness at age 35', Methods says 'in his thirties'; P35Y taken from the abstract.
- No numeric acylcarnitine values are given for the grandfather (Table 1 covers only the father M1 and the two siblings M2/M3); only a qualitative 'altered blood acylcarnitine profile' is reported.
- 'Fatigue', 'high carnitine levels' and 'lipid accumulation in muscles' are stated at family level in the Discussion (sec:10 ¶1) for the symptomatic members; fatigue is included here on that basis.
- No fibroblasts were obtained from the grandfather (cell lines derive from the father and the two children).
- Variant classification (likely pathogenic, ACGS/ACMG-AMP PM1_moderate, PP2_supporting, PM2_moderate, PP3_supporting; rs770905850, gnomAD 0.003%) is stated at family level in sec:4 ¶1.
- Transmission direction not stated for the grandfather; the paper describes the family inheritance as apparently autosomal dominant.
- Muscle biopsy lipid accumulation is described as 'neutral lipid accumulation' in the abstract.