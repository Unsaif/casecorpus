# PMID_42581774_Patient_1
**Source:** PMID 42581774 · Molecular genetics genomic medicine 2026 · DOI 10.1002/mgg3.70278 · licence: None · tier: epmc
**Individual:** Patient 1 · sex MALE · onset ? (From 39 weeks postmenstrual age) · presentation ? (From 39 weeks postmenstrual age (multiple hospital admissions)) · last follow-up P4M (4 months of corrected age) · DECEASED
**Evidence verification:** 80/80 quotes found in their anchored unit, 80/80 anywhere in the document; narrative source: extractor

## Patient description (verbatim from the source, by anchor)

> **[abstract]** Introduction: Type VIII 3‐methylglutaconic aciduria (MGCA8) is a neurodegenerative disorder which involves biallelic pathogenic variants of HTRA2. This gene encodes a mitochondrial serine protease responsible for apoptosis regulation and mitochondrial proteins' quality. Clinical manifestations include dysfunctional muscle tone, movement disorder, severe encephalopathy, epileptic seizures, dysautonomia, feeding difficulty, intermittent neutropenia, bradycardia, and recurrent apneas, often progressing into respiratory failure.
Case Report: We describe a newborn presenting with abnormal muscle tone, progressive dystonic movements, recurrent apneas, feeding difficulties, and epileptic seizures. Biochemical analysis revealed a markedly elevated urinary 3‐methylglutaconic acid, and genetic test identified biallelic pathogenic variant in HTRA2. Brain MRI revealed progressive brain atrophy, thalamic hypoplasia, and ventriculomegaly. EEG recordings found organizational abnormalities that turned into epileptic spasms. Despite intensive care, the patient suffered rapid neurological decline and died following a prolonged apnea episode. Thereafter the family had another infant diagnosed with the same biallelic pathogenic variant in HTRA2, that died a few days after birth due to respiratory failure.
Discussion: MGCA8 is a lethal condition characterized by loss‐of‐function biallelic mutations in HTRA2, which lead to mitochondrial dysfunction and altered apoptosis regulation, especially in the brain. High levels of 3‐methylglutaconic acid in urine are one important early diagnostic marker, when associated with a consistent clinical phenotype. Our report contributes to the limited existing case series and provides a detailed characterization of the EEG findings associated with this rare condition.
>
> **[sec:2 ¶1]** We report the case of a neonate born to consanguineous Pakistani parents (cousins beyond the third degree) with a positive family history for intellectual disability and neonatal‐onset epilepsy of unknown etiology. Delivery occurred via cesarean section at 32 weeks +3 days gestational age, following a pregnancy complicated by multiple threatened abortions and premature rupture of membranes. At birth, neonatal parameters and neurological examination were within normal limits.
>
> **[sec:2 ¶2]** Due to prematurity and mild respiratory distress, the infant was initially admitted to the Neonatal Intensive Care Unit (NICU) and subsequently discharged in good general condition. From 39 weeks postmenstrual age, the patient required multiple admissions to our hospital for paroxysmal episodes characterized by apnea with desaturation and bradycardia, associated with dystonic posturing of the upper limbs with superimposed tremor, flushing and chewing movements; sucking difficulties were also observed. At almost 2 months of corrected age, he alternated between episodes of crying—during which hypertonicity was observed in all four limbs along with hyperextension of the head—and quieter but drowsy periods. Brief episodes of fixation and visual tracking were observed, although they were inconsistent and poorly sustained. Muscle trophism was normal, with slightly increased tone in all limbs. Deep tendon reflexes were within normal limits. Head control was incomplete, and in the prone position the patient was unable to free his airways. Spontaneous motor activity was poor, with motor patterns showing little variation and characterized by synchronous and symmetrical movements. No fidgety movements were observed.
>
> **[sec:2 ¶3]** A progressive clinical deterioration followed, with worsening apnea and bradycardia episodes, as well as neurological decline characterized by hypotonia and psychomotor delay. Transthoracic echocardiography demonstrated a globular left ventricle with upper reference range dimensions and features consistent with noncompacted myocardium. Urinary organic acid analysis revealed a significant increase of 3‐methylglutaric (70 mmol/mol; normal values 0–7) and 3‐methylglutaconic acids (present). Blood tests revealed intermittent neutropenia (17.6%, normal values 40.0–74.0; 0.98 × 103/uL normal values 1.10–9.00).
>
> **[sec:2 ¶4]** Given the clinical, echocardiographic, and urinary findings, genetic testing for Barth syndrome (3‐methylglutaconic aciduria type II) was performed, with negative results. Chromosomal microarray and mitochondrial DNA analyses were normal. Brain MRI at 7 weeks corrected age demonstrated delayed myelination in the supratentorial region. A follow‐up MRI at 13 weeks corrected age showed progressive cerebral atrophy with bilateral thalamic and corpus callosum hypotrophy, and supratentorial ventriculomegaly. No lactate peak signals were detected.
>
> **[sec:2 ¶5]** Electromyography showed mildly reduced sensorimotor conduction velocity for age, while neurophysiological tests (ERG, SEP of upper and lower limbs) revealed mild, nonspecific abnormalities. Muscle biopsy demonstrated histological features suggestive of myopathic changes of undefined interpretation, similar to those seen in neurodegenerative disorders such as spinal muscular atrophy type 1 (SMA1). Consequently, multiplex ligation‐dependent probe amplification (MLPA) testing for SMN1/SMN2 was performed and resulted negative.
>
> **[sec:2 ¶6]** To further investigate the clinical picture, multiple EEG recordings were conducted. Numerous apnea episodes were recorded without EEG correlates (Figure 1A). Initially, a poorly organized, monomorphic background activity was noted, with the presence of rhythmic, sinusoidal, α‐like fast activity in central regions during both wakefulness and sleep (Figure 1B), along with interictal epileptiform abnormalities predominantly in the right hemisphere.
>
> **[sec:2 ¶7]** During paroxysmal episodes characterized by irritability and dystonic movements with hyperextension of the head, trunk, and limbs, associated with oral automatisms, an increase in the described rhythmic sinusoidal activity was observed, although these episodes were not classified as epileptic seizures.
>
> **[sec:2 ¶8]** Regarding treatment, considering the presence of disorganized and paroxysmal brain activity, empirical treatment with levetiracetam, pyridoxine, pyridoxal phosphate, folinic acid, and biotin was started. This led to clinical improvement, with a reduction of paroxysmal episodes and apnea episodes, as well as an overall improvement in EEG organization, albeit with persistent interictal paroxysmal abnormalities.
>
> **[sec:2 ¶9]** Subsequently, along with clinical deterioration, the EEG worsened, showing major background abnormalities, with predominant bilateral interictal paroxysmal activity in temporo‐posterior and centro‐parieto‐posterior regions, with right‐sided predominance leading to an ipsarhythmic pattern (Figure 2A). At this stage, therapy for mitochondrial disease was introduced, including idebenone, thiamine, alpha‐lipoic acid, and riboflavin.
>
> **[sec:2 ¶10]** Seizures characterized by clustered spasms (Figure 2B) were recorded, accompanied by poor responsiveness, upward gaze deviation and opisthotonos of the trunk and upper limbs. Treatment with vigabatrin was initiated, resulting in good seizure control.
>
> **[sec:2 ¶11]** Due to progressive clinical worsening, with frequent daily apnoeas accompanied by desaturations and bradycardia or tachycardia, mechanical ventilation support and intensive monitoring were required. The patient died following a prolonged apnoea episode with progressive desaturation at 4 months of corrected age.
>
> **[sec:2 ¶12]** Postmortem whole‐exome sequencing (WES) identified two compound heterozygous variants in HTRA2 (NM_013247.5): the c.1015C>T (p.Arg339Ter) nonsense variant, maternally inherited, and the c.1211G>A (p.Arg404Gln) missense variant, inherited from the father, as assessed by Sanger sequencing. Both variants were classified as pathogenic according to The American College of Medical Genetics and Genomics (ACMG) guidelines (PVS1 + PM2 and PS3 + PM2 + PM3 + PM5, respectively) (Richards et al. 2015), confirming the diagnosis of type VIII 3‐methylglutaconic aciduria (Table S1). The c.1015C>T has not previously been reported, whereas c.1211G>A has been described in homozygosity in a female subject with MGCA8. This substitution affects the last nucleotide of exon 7, leading to exon 7 skipping, and previous Western blot analysis of patient‐derived fibroblasts demonstrated complete depletion of the corresponding protein (Mandel et al. 2016). The family had another baby born at 36.3 weeks GA that died a few days after birth due to respiratory failure. Urinary organic acid analysis revealed a significant increase of 3‐methylglutaric acid 60 H mM/M (normal values 0–7). Molecular analysis of the proband identified the two compound heterozygous variants in HTRA2 (NM_013247.5) previously reported in the deceased brother. The infant was born in another hospital so no information about neurological examination, EEG or neuroradiological findings are available.
>
> **[sec:2 ¶13]** Genetic variants and the family pedigree are detailed in Table 1, Figure 3 and Table S1, respectively.
>
> **[sec:3 ¶4]** Reported variants include missense (e.g., p.Arg404Gln, as identified in our case), nonsense (e.g., p.Arg339Ter, as identified in our case), and less frequent splice‐site or frameshift variants, all of which are associated with loss of function or reduced stability of the HTRA2 protein (Mandel et al. 2016; Gurusamy et al. 2024; Oláhová et al. 2017; Sreedhara et al. 2020; Kovacs‐Nagy et al. 2018). It's worth mentioning that significant clinical heterogeneity is observed even among individuals carrying the same variant, including affected siblings or other family members, this suggests that additional factors may contribute to phenotypic expressivity and disease severity. A possible association between heterozygous variants of HTRA2 and an increased risk of Parkinson's disease and/or essential tremor are also mentioned in literature (Simón‐Sánchez and Singleton 2008; Unal Gulsuner et al. 2014; Tzoulis et al. 2015; Youn et al. 2019). Consistent with the literature, our patient showed early neurological manifestations including changes in muscle tone, along with dystonic movements of the head, trunk, and limbs, followed by the onset of seizures.
>
> **[sec:3 ¶6]** Feeding and sucking difficulties, also observed in our patient, are frequently reported, as are respiratory problems, typically manifesting as central apnoeas and progressive respiratory failure requiring invasive mechanical ventilation (Mandel et al. 2016; Gurusamy et al. 2024; Oláhová et al. 2017; Sreedhara et al. 2020; Kovacs‐Nagy et al. 2018). All published cases, including this case report, exhibited a clinical course culminating in death due to progressive respiratory failure or related complications, underscoring the critical importance of early and intensive respiratory management in this disorder.
>
> **[sec:3 ¶7]** From a biochemical standpoint, elevated urinary 3‐methylglutaconic acid levels represent a recurrent and significant finding (Mandel et al. 2016; Oláhová et al. 2017; Sreedhara et al. 2020). In our patient, markedly increased levels were observed, supporting substantial mitochondrial dysfunction. Although elevated 3‐methylglutaconic acid is not specific to overt neurometabolic disorders (Jones et al. 2021; Ziats et al. 2021), its presence is particularly relevant when associated with a consistent clinical phenotype, serving as a crucial diagnostic marker.
>
> **[sec:3 ¶10]** Hematologic abnormalities, particularly intermittent neutropenia, frequently reported in the literature (Mandel et al. 2016; Oláhová et al. 2017; Kovacs‐Nagy et al. 2018) and confirmed in our case, represent an additional relevant diagnostic criterion.
>
> **[sec:3 ¶12]** The initial EEG recordings showed sequences of low‐voltage, monomorphic rhythmic activity in the alpha band over central regions, without clear clinical correlates. Rhythmic activity over central and vertex regions, similar to those observed in our patient, may resemble maturational patterns seen in term neonates, which are typically brief, decrease with cortical maturation and are usually present during quiet sleep. In this context, the persistence and marked prominence of this activity beyond term‐equivalent age may represent a pathological variant of a maturational rhythm, likely nonspecific to this severe disorder but suggestive of motor area dysmaturity.
>
> **[sec:3 ¶13]** Electroencephalographic evidence of neurodegenerative progression was observed, with an initially poorly organized tracing evolving toward ipsirhythmicity, accompanied by multifocal interictal abnormalities and the emergence of epileptic spasms. The literature confirms that metabolic etiologies associated with epileptic spasms frequently include acidurias related to mitochondrial and lysosomal dysfunction (Fusco et al. 2020).
>
> **[tab:1 r2]** HTRA2 | NM_013247.5 | *606441 | AR | c.1015C>T (p.Arg339Ter) | Het | 0.0008674 | P | Mat
>
> **[tab:1 r3]** HTRA2 | NM_013247.5 | *606441 | AR | c.1211G>A (p.Arg404Gln) | Het | 0.0008677 | P | Pat
>
> **[tab:2 c10]** : This paper
Individual (as in reference): Patient 1 (m); Patient 2 (m)
Age of onset: Neonatal; Neonatal
Age of death: 4 month; 3 days
Muscle tone: Hypotonia; hypotonia
Movement disorder: Dystonia, tremor, progressive akinesia; NA
Acquisition of milestones: No; No
Recurrent apnoea: Yes; Yes
Respiratory insufficiency: Yes; Yes
Dysphagia: Yes; NA
Tube feeding: Yes; NA
Seizures: Yes; No
Cerebral atrophy: Yes; NA
Neutropenia: Yes (intermittent); NA
Elevated serum lactate: NA; NA
Elevated urinary 3‐methylglutaconic acid: Yes; Yes
HTRA2Variant(s): c.1015C>T, p.Arg339Ter + c.1211G>A, p.Arg404Gln (comp het); c.1015C>T, p.Arg339Ter + c.1211G>A, p.Arg404Gln (comp het)
EEG: α‐like rhythmic activity; hypsarrhythmia; epileptic spasms; NA
>

## Diagnoses

- ✓ **FINAL** type VIII 3‐methylglutaconic aciduria (MGCA8) → 3-methylglutaconic aciduria type 8 MONDO:0044723 OMIM:617248 · tier MOLECULAR · route postmortem  
  “Both variants were classified as pathogenic according to The American College of Medical Genetics and Genomics (ACMG) guidelines (PVS1 + PM2 and PS3 + PM2 + PM3 + PM5, respectively) (Richards et al. 2015), confirming the diagnosis of type VIII 3‐methylglutaconic aciduria (Table S1).” [sec:2 ¶12]
- ✓ **EXCLUDED** Barth syndrome (3‐methylglutaconic aciduria type II) → Barth syndrome MONDO:0010543 OMIM:302060 · tier MOLECULAR · route –  
  “Given the clinical, echocardiographic, and urinary findings, genetic testing for Barth syndrome (3‐methylglutaconic aciduria type II) was performed, with negative results.” [sec:2 ¶4]
- ✓ **EXCLUDED** spinal muscular atrophy type 1 (SMA1) → spinal muscular atrophy, type 1 MONDO:0009669 OMIM:253300 · tier MOLECULAR · route –  
  “Consequently, multiplex ligation‐dependent probe amplification (MLPA) testing for SMN1/SMN2 was performed and resulted negative.” [sec:2 ¶5]
- ✓ **DIFFERENTIAL** mitochondrial disease → mitochondrial disease MONDO:0044970  · tier CLINICAL · route –  
  “At this stage, therapy for mitochondrial disease was introduced, including idebenone, thiamine, alpha‐lipoic acid, and riboflavin.” [sec:2 ¶9]

## Genetic findings

- ✓ **HTRA2** c.1015C>T p.Arg339Ter · COMPOUND_HETEROZYGOUS · pathogenic · WES (postmortem), confirmed by Sanger sequencing  
  “Postmortem whole‐exome sequencing (WES) identified two compound heterozygous variants in HTRA2 (NM_013247.5): the c.1015C>T (p.Arg339Ter) nonsense variant, maternally inherited, and the c.1211G>A (p.Arg404Gln) missense variant, inherited from the father, as assessed by Sanger sequencing.” [sec:2 ¶12]
- ✓ **HTRA2** c.1211G>A p.Arg404Gln · COMPOUND_HETEROZYGOUS · pathogenic · WES (postmortem), confirmed by Sanger sequencing  
  “Postmortem whole‐exome sequencing (WES) identified two compound heterozygous variants in HTRA2 (NM_013247.5): the c.1015C>T (p.Arg339Ter) nonsense variant, maternally inherited, and the c.1211G>A (p.Arg404Gln) missense variant, inherited from the father, as assessed by Sanger sequencing.” [sec:2 ¶12]

## Measurements

| ✓ | analyte | specimen | value | unit | ref | interp | timing | quote [anchor] |
|---|---|---|---|---|---|---|---|---|
| ✓ | urinary 3‐methylglutaric acid → 3-methylglutaric acid | urine | 70 | mmol/mol | normal values 0–7 | HIGH | during clinical deterioration, before genetic diagnosis | “Urinary organic acid analysis revealed a significant increase of 3‐methylglutaric (70 mmol/mol; normal values 0–7) and 3” [sec:2 ¶3] |
| ✓ | urinary 3‐methylglutaconic acid → 3-methylglutaconic acid | urine | present |  |  | HIGH | during clinical deterioration, before genetic diagnosis | “Urinary organic acid analysis revealed a significant increase of 3‐methylglutaric (70 mmol/mol; normal values 0–7) and 3” [sec:2 ¶3] |
| ✓ | urinary 3‐methylglutaconic acid → 3-methylglutaconic acid | urine | markedly elevated |  |  | HIGH |  | “Biochemical analysis revealed a markedly elevated urinary 3‐methylglutaconic acid, and genetic test identified biallelic” [abstract] |
| ✓ | neutrophils (percentage) → neutrophils | blood | 17.6 | % | normal values 40.0–74.0 | LOW | during clinical deterioration (intermittent neutropenia) | “Blood tests revealed intermittent neutropenia (17.6%, normal values 40.0–74.0; 0.98 × 103/uL normal values 1.10–9.00).” [sec:2 ¶3] |
| ✓ | neutrophils (absolute count) → neutrophils | blood | 0.98 | x10^3/uL | normal values 1.10–9.00 | LOW | during clinical deterioration (intermittent neutropenia) | “Blood tests revealed intermittent neutropenia (17.6%, normal values 40.0–74.0; 0.98 × 103/uL normal values 1.10–9.00).” [sec:2 ¶3] |

## Phenotypes

- ✓ Premature birth → Premature birth HP:0001622 (grounded)  
  “Delivery occurred via cesarean section at 32 weeks +3 days gestational age, following a pregnancy complicated by multiple threatened abortions and premature rupture of membranes.” [sec:2 ¶1]
- ✓ Premature rupture of membranes → Premature rupture of membranes HP:0001788 (grounded)  
  “following a pregnancy complicated by multiple threatened abortions and premature rupture of membranes.” [sec:2 ¶1]
- ✓ Multiple threatened abortions during pregnancy → –  (candidate)  
  “following a pregnancy complicated by multiple threatened abortions and premature rupture of membranes.” [sec:2 ¶1]
- ✓ NOT Abnormal neurological examination at birth → –  (candidate)  
  “At birth, neonatal parameters and neurological examination were within normal limits.” [sec:2 ¶1]
- ✓ Respiratory distress → Respiratory distress HP:0002098 (grounded)  
  “Due to prematurity and mild respiratory distress, the infant was initially admitted to the Neonatal Intensive Care Unit (NICU) and subsequently discharged in good general condition.” [sec:2 ¶2]
- ✓ Apnea → Apnea HP:0002104 (grounded)  
  “the patient required multiple admissions to our hospital for paroxysmal episodes characterized by apnea with desaturation and bradycardia” [sec:2 ¶2]
- ✓ Oxygen desaturation → –  (candidate)  
  “the patient required multiple admissions to our hospital for paroxysmal episodes characterized by apnea with desaturation and bradycardia” [sec:2 ¶2]
- ✓ Bradycardia → Bradycardia HP:0001662 (grounded)  
  “the patient required multiple admissions to our hospital for paroxysmal episodes characterized by apnea with desaturation and bradycardia” [sec:2 ¶2]
- ✓ Dystonic posturing of the upper limbs → Dystonia HP:0001332 (candidate)  
  “associated with dystonic posturing of the upper limbs with superimposed tremor, flushing and chewing movements; sucking difficulties were also observed.” [sec:2 ¶2]
- ✓ Tremor → Tremor HP:0001337 (grounded)  
  “associated with dystonic posturing of the upper limbs with superimposed tremor, flushing and chewing movements; sucking difficulties were also observed.” [sec:2 ¶2]
- ✓ Flushing → Flushing HP:0031284 (grounded)  
  “associated with dystonic posturing of the upper limbs with superimposed tremor, flushing and chewing movements; sucking difficulties were also observed.” [sec:2 ¶2]
- ✓ Chewing movements → –  (candidate)  
  “associated with dystonic posturing of the upper limbs with superimposed tremor, flushing and chewing movements; sucking difficulties were also observed.” [sec:2 ¶2]
- ✓ Poor suck → Poor suck HP:0002033 (grounded)  
  “associated with dystonic posturing of the upper limbs with superimposed tremor, flushing and chewing movements; sucking difficulties were also observed.” [sec:2 ¶2]
- ✓ Feeding difficulties → Feeding difficulties HP:0011968 (grounded)  
  “We describe a newborn presenting with abnormal muscle tone, progressive dystonic movements, recurrent apneas, feeding difficulties, and epileptic seizures.” [abstract]
- ✓ Dysphagia → Dysphagia HP:0002015 (grounded)  
  “Yes; NA” [tab:2 r10c10]
- ✓ Hypertonia of all four limbs during crying episodes → Hypertonia HP:0001276 (grounded)  
  “he alternated between episodes of crying—during which hypertonicity was observed in all four limbs along with hyperextension of the head—and quieter but drowsy periods.” [sec:2 ¶2]
- ✓ Hyperextension of the head → –  (candidate)  
  “he alternated between episodes of crying—during which hypertonicity was observed in all four limbs along with hyperextension of the head—and quieter but drowsy periods.” [sec:2 ¶2]
- ✓ Drowsiness → Drowsiness HP:0002329 (grounded)  
  “he alternated between episodes of crying—during which hypertonicity was observed in all four limbs along with hyperextension of the head—and quieter but drowsy periods.” [sec:2 ¶2]
- ✓ Poorly sustained visual fixation and tracking → –  (candidate)  
  “Brief episodes of fixation and visual tracking were observed, although they were inconsistent and poorly sustained.” [sec:2 ¶2]
- ✓ NOT Skeletal muscle atrophy → Skeletal muscle atrophy HP:0003202 (grounded)  
  “Muscle trophism was normal, with slightly increased tone in all limbs.” [sec:2 ¶2]
- ✓ Limb hypertonia → Limb hypertonia HP:0002509 (grounded)  
  “Muscle trophism was normal, with slightly increased tone in all limbs.” [sec:2 ¶2]
- ✓ NOT Abnormal deep tendon reflexes → –  (candidate)  
  “Deep tendon reflexes were within normal limits.” [sec:2 ¶2]
- ✓ Poor head control → Poor head control HP:0002421 (grounded)  
  “Head control was incomplete, and in the prone position the patient was unable to free his airways.” [sec:2 ¶2]
- ✓ Reduced spontaneous motor activity → –  (candidate)  
  “Spontaneous motor activity was poor, with motor patterns showing little variation and characterized by synchronous and symmetrical movements.” [sec:2 ¶2]
- ✓ Absent fidgety movements → –  (candidate)  
  “No fidgety movements were observed.” [sec:2 ¶2]
- ✓ Progressive neurological deterioration → –  (candidate)  
  “A progressive clinical deterioration followed, with worsening apnea and bradycardia episodes, as well as neurological decline characterized by hypotonia and psychomotor delay.” [sec:2 ¶3]
- ✓ Hypotonia → Hypotonia HP:0001252 (grounded)  
  “A progressive clinical deterioration followed, with worsening apnea and bradycardia episodes, as well as neurological decline characterized by hypotonia and psychomotor delay.” [sec:2 ¶3]
- ✓ Psychomotor delay → Global developmental delay HP:0001263 (grounded)  
  “A progressive clinical deterioration followed, with worsening apnea and bradycardia episodes, as well as neurological decline characterized by hypotonia and psychomotor delay.” [sec:2 ¶3]
- ✓ No acquisition of developmental milestones → –  (candidate)  
  “No; No” [tab:2 r7c10]
- ✓ Globular left ventricle → –  (candidate)  
  “Transthoracic echocardiography demonstrated a globular left ventricle with upper reference range dimensions and features consistent with noncompacted myocardium.” [sec:2 ¶3]
- ✓ Left ventricular noncompaction → Left ventricular noncompaction HP:0030682 (grounded)  
  “Transthoracic echocardiography demonstrated a globular left ventricle with upper reference range dimensions and features consistent with noncompacted myocardium.” [sec:2 ¶3]
- ✓ Neutropenia → Decreased total neutrophil count HP:0001875 (grounded)  
  “Blood tests revealed intermittent neutropenia (17.6%, normal values 40.0–74.0; 0.98 × 103/uL normal values 1.10–9.00).” [sec:2 ¶3]
- ✓ Delayed myelination → Delayed myelination HP:0012448 (grounded)  
  “Brain MRI at 7 weeks corrected age demonstrated delayed myelination in the supratentorial region.” [sec:2 ¶4]
- ✓ Cerebral atrophy → Cerebral atrophy HP:0002059 (grounded)  
  “A follow‐up MRI at 13 weeks corrected age showed progressive cerebral atrophy with bilateral thalamic and corpus callosum hypotrophy, and supratentorial ventriculomegaly.” [sec:2 ¶4]
- ✓ Bilateral thalamic hypotrophy → –  (candidate)  
  “A follow‐up MRI at 13 weeks corrected age showed progressive cerebral atrophy with bilateral thalamic and corpus callosum hypotrophy, and supratentorial ventriculomegaly.” [sec:2 ¶4]
- ✓ Corpus callosum hypotrophy → –  (candidate)  
  “A follow‐up MRI at 13 weeks corrected age showed progressive cerebral atrophy with bilateral thalamic and corpus callosum hypotrophy, and supratentorial ventriculomegaly.” [sec:2 ¶4]
- ✓ Supratentorial ventriculomegaly → Ventriculomegaly HP:0002119 (grounded)  
  “A follow‐up MRI at 13 weeks corrected age showed progressive cerebral atrophy with bilateral thalamic and corpus callosum hypotrophy, and supratentorial ventriculomegaly.” [sec:2 ¶4]
- ✓ NOT Elevated brain lactate level by MRS → Elevated brain lactate level by MRS HP:0012707 (grounded)  
  “No lactate peak signals were detected.” [sec:2 ¶4]
- ✓ Reduced sensorimotor nerve conduction velocity → Decreased nerve conduction velocity HP:0000762 (grounded)  
  “Electromyography showed mildly reduced sensorimotor conduction velocity for age” [sec:2 ¶5]
- ✓ Abnormal electroretinogram → Abnormal electroretinogram HP:0000512 (grounded)  
  “neurophysiological tests (ERG, SEP of upper and lower limbs) revealed mild, nonspecific abnormalities.” [sec:2 ¶5]
- ✓ Abnormal somatosensory evoked potentials → –  (candidate)  
  “neurophysiological tests (ERG, SEP of upper and lower limbs) revealed mild, nonspecific abnormalities.” [sec:2 ¶5]
- ✓ Myopathic changes on muscle biopsy → –  (candidate)  
  “Muscle biopsy demonstrated histological features suggestive of myopathic changes of undefined interpretation, similar to those seen in neurodegenerative disorders such as spinal muscular atrophy type 1 (SMA1).” [sec:2 ¶5]
- ✓ Poorly organized monomorphic EEG background activity → –  (candidate)  
  “Initially, a poorly organized, monomorphic background activity was noted” [sec:2 ¶6]
- ✓ Rhythmic sinusoidal alpha-like fast activity in central regions on EEG → –  (candidate)  
  “with the presence of rhythmic, sinusoidal, α‐like fast activity in central regions during both wakefulness and sleep” [sec:2 ¶6]
- ✓ Interictal epileptiform activity → Interictal epileptiform activity HP:0011182 (grounded)  
  “along with interictal epileptiform abnormalities predominantly in the right hemisphere.” [sec:2 ¶6]
- ✓ Paroxysmal non-epileptic dystonic episodes → –  (candidate)  
  “During paroxysmal episodes characterized by irritability and dystonic movements with hyperextension of the head, trunk, and limbs, associated with oral automatisms” [sec:2 ¶7]
- ✓ Irritability → Irritability HP:0000737 (grounded)  
  “During paroxysmal episodes characterized by irritability and dystonic movements with hyperextension of the head, trunk, and limbs, associated with oral automatisms” [sec:2 ¶7]
- ✓ Oral automatisms → –  (candidate)  
  “During paroxysmal episodes characterized by irritability and dystonic movements with hyperextension of the head, trunk, and limbs, associated with oral automatisms” [sec:2 ¶7]
- ✓ Hypsarrhythmia → Hypsarrhythmia HP:0002521 (grounded)  
  “the EEG worsened, showing major background abnormalities, with predominant bilateral interictal paroxysmal activity in temporo‐posterior and centro‐parieto‐posterior regions, with right‐sided predominance leading to an ipsarhythmic pattern (Figure 2A).” [sec:2 ¶9]
- ✓ Seizure → Seizure HP:0001250 (grounded)  
  “Seizures characterized by clustered spasms (Figure 2B) were recorded, accompanied by poor responsiveness, upward gaze deviation and opisthotonos of the trunk and upper limbs.” [sec:2 ¶10]
- ✓ Epileptic spasm → Epileptic spasm HP:0011097 (grounded)  
  “Seizures characterized by clustered spasms (Figure 2B) were recorded, accompanied by poor responsiveness, upward gaze deviation and opisthotonos of the trunk and upper limbs.” [sec:2 ¶10]
- ✓ Poor responsiveness during seizures → –  (candidate)  
  “Seizures characterized by clustered spasms (Figure 2B) were recorded, accompanied by poor responsiveness, upward gaze deviation and opisthotonos of the trunk and upper limbs.” [sec:2 ¶10]
- ✓ Upward gaze deviation → –  (candidate)  
  “Seizures characterized by clustered spasms (Figure 2B) were recorded, accompanied by poor responsiveness, upward gaze deviation and opisthotonos of the trunk and upper limbs.” [sec:2 ¶10]
- ✓ Opisthotonus → Opisthotonus HP:0002179 (grounded)  
  “Seizures characterized by clustered spasms (Figure 2B) were recorded, accompanied by poor responsiveness, upward gaze deviation and opisthotonos of the trunk and upper limbs.” [sec:2 ¶10]
- ✓ Tachycardia → Tachycardia HP:0001649 (grounded)  
  “with frequent daily apnoeas accompanied by desaturations and bradycardia or tachycardia, mechanical ventilation support and intensive monitoring were required.” [sec:2 ¶11]
- ✓ Respiratory insufficiency → Respiratory insufficiency HP:0002093 (grounded)  
  “with frequent daily apnoeas accompanied by desaturations and bradycardia or tachycardia, mechanical ventilation support and intensive monitoring were required.” [sec:2 ¶11]
- ✓ Progressive akinesia → –  (candidate)  
  “Dystonia, tremor, progressive akinesia; NA” [tab:2 r6c10]

## Treatments

- ✓ drug: levetiracetam · response improved  
  “empirical treatment with levetiracetam, pyridoxine, pyridoxal phosphate, folinic acid, and biotin was started.” [sec:2 ¶8]
- ✓ cofactor_vitamin: pyridoxine · response improved  
  “empirical treatment with levetiracetam, pyridoxine, pyridoxal phosphate, folinic acid, and biotin was started.” [sec:2 ¶8]
- ✓ cofactor_vitamin: pyridoxal phosphate · response improved  
  “empirical treatment with levetiracetam, pyridoxine, pyridoxal phosphate, folinic acid, and biotin was started.” [sec:2 ¶8]
- ✓ cofactor_vitamin: folinic acid · response improved  
  “empirical treatment with levetiracetam, pyridoxine, pyridoxal phosphate, folinic acid, and biotin was started.” [sec:2 ¶8]
- ✓ cofactor_vitamin: biotin · response improved  
  “This led to clinical improvement, with a reduction of paroxysmal episodes and apnea episodes, as well as an overall improvement in EEG organization, albeit with persistent interictal paroxysmal abnormalities.” [sec:2 ¶8]
- ✓ cofactor_vitamin: idebenone · response not_stated  
  “At this stage, therapy for mitochondrial disease was introduced, including idebenone, thiamine, alpha‐lipoic acid, and riboflavin.” [sec:2 ¶9]
- ✓ cofactor_vitamin: thiamine · response not_stated  
  “At this stage, therapy for mitochondrial disease was introduced, including idebenone, thiamine, alpha‐lipoic acid, and riboflavin.” [sec:2 ¶9]
- ✓ cofactor_vitamin: alpha-lipoic acid · response not_stated  
  “At this stage, therapy for mitochondrial disease was introduced, including idebenone, thiamine, alpha‐lipoic acid, and riboflavin.” [sec:2 ¶9]
- ✓ cofactor_vitamin: riboflavin · response not_stated  
  “At this stage, therapy for mitochondrial disease was introduced, including idebenone, thiamine, alpha‐lipoic acid, and riboflavin.” [sec:2 ¶9]
- ✓ drug: vigabatrin · response improved  
  “Treatment with vigabatrin was initiated, resulting in good seizure control.” [sec:2 ¶10]
- ✓ supportive: mechanical ventilation · response worsened  
  “with frequent daily apnoeas accompanied by desaturations and bradycardia or tachycardia, mechanical ventilation support and intensive monitoring were required.” [sec:2 ¶11]
- ✓ supportive: tube feeding · response not_stated  
  “Yes; NA” [tab:2 r11c10]

## Outcome

Progressive clinical worsening with frequent daily apnoeas requiring mechanical ventilation; died following a prolonged apnoea episode with progressive desaturation at 4 months of corrected age. Diagnosis of MGCA8 was made by postmortem WES.

## Model summary (not source text)

A male neonate born at 32 weeks +3 days to consanguineous Pakistani parents was normal at birth but from 39 weeks postmenstrual age had recurrent paroxysmal episodes of apnea with desaturation and bradycardia, upper-limb dystonic posturing with tremor, flushing, chewing movements and sucking difficulties. Examination at almost 2 months corrected age showed episodic hypertonia with head hyperextension, slightly increased limb tone, incomplete head control, poor spontaneous motor activity and absent fidgety movements, followed by progressive deterioration with hypotonia and psychomotor delay. Work-up showed left ventricular noncompaction features on echocardiography, urinary 3-methylglutaric acid 70 mmol/mol (normal 0-7) with 3-methylglutaconic acid present, intermittent neutropenia (17.6%, 0.98 x10^3/uL), delayed myelination then progressive cerebral atrophy with thalamic and corpus callosum hypotrophy and ventriculomegaly on MRI, and negative testing for Barth syndrome, chromosomal microarray, mtDNA and SMN1/SMN2 MLPA. EEG evolved from a poorly organized background with central alpha-like rhythmic activity and right-sided interictal abnormalities to hypsarrhythmia with clustered epileptic spasms, which responded to vigabatrin. Despite empirical antiseizure/vitamin therapy, a mitochondrial cocktail and mechanical ventilation, he died after a prolonged apnea at 4 months of corrected age. Postmortem WES identified compound heterozygous pathogenic HTRA2 variants c.1015C>T (p.Arg339Ter, maternal, novel) and c.1211G>A (p.Arg404Gln, paternal), confirming 3-methylglutaconic aciduria type VIII.

## Extractor notes

- Individual is unnamed in the text ('the patient', 'our proband', 'the neonate'); local_id 'Patient 1' is taken from Table 2 column 'This paper' ('Patient 1 (m); Patient 2 (m)'). Table 2 c10 cells give values for Patient 1 and Patient 2 separated by semicolons; the first value refers to this individual.
- Ages are given as postmenstrual or corrected ages (born at 32+3 weeks): onset from 39 weeks postmenstrual age (about 6-7 weeks chronological, not computed here), exam at almost 2 months corrected age, MRI at 7 and 13 weeks corrected age, death at 4 months of corrected age (recorded as P4M; chronological age at death would be roughly 8 weeks more). Table 2 gives age of onset 'Neonatal' and age of death '4 month'.
- Quantified urinary organic acid is reported as 3-methylglutaric acid (70 mmol/mol, normal 0-7) with 3-methylglutaconic acid only 'present' (sec:2 ¶3), whereas the abstract ('markedly elevated urinary 3-methylglutaconic acid'), discussion (sec:3 ¶7 'markedly increased levels') and Table 2 r16 ('Elevated urinary 3-methylglutaconic acid: Yes') describe elevated 3-methylglutaconic acid. Both are recorded; possible analyte mislabelling by the authors. The unit 'mmol/mol' is presumably per mol creatinine (not stated).
- Absolute neutrophil count unit is rendered in the source as '0.98 × 103/uL' (lost superscript, i.e. ×10^3/µL); recorded as 'x10^3/uL'.
- Elevated serum lactate is 'NA' for this patient in Table 2 r15 (not reported). Brain MRI/MRS showed no lactate peak (recorded as an excluded phenotype).
- Negative genetic work-up not recorded as genetic_findings: genetic testing for Barth syndrome negative (gene not named), chromosomal microarray normal, mitochondrial DNA analyses normal, MLPA for SMN1/SMN2 negative (sec:2 ¶4-5). Barth syndrome and SMA1 are recorded as EXCLUDED diagnoses.
- Table 2 r6c10 lists 'progressive akinesia' for this patient, which is not mentioned in the text (text describes poor spontaneous motor activity); recorded from the table only. Table 2 r5c10 gives muscle tone 'Hypotonia' whereas the text describes initial hypertonia/increased tone followed by hypotonia during deterioration.
- Dysphagia and tube feeding are recorded from Table 2 (r10c10, r11c10) only; the text mentions sucking/feeding difficulties.
- Response to the empirical regimen (levetiracetam, pyridoxine, pyridoxal phosphate, folinic acid, biotin) is reported for the combination, not per agent; the same response is attached to each agent entry. No response is stated for the mitochondrial cocktail (idebenone, thiamine, alpha-lipoic acid, riboflavin).
- The paper spells hypsarrhythmia as 'ipsarhythmic'/'ipsirhythmicity' in the text and 'hypsarrhythmia' in Table 2 r18c10.
- Table 1 gives GnomAD v4.1.1 frequencies (0.0008674% for c.1015C>T, 0.0008677% for c.1211G>A) and ACMG class P for both variants with segregation Mat/Pat; Table S1 (CADD scores) is not available in the rendering.
- In sec:2 ¶12 the sentence 'Molecular analysis of the proband identified the two compound heterozygous variants ... previously reported in the deceased brother' refers to the younger sibling (Patient 2) as 'the proband', inconsistent with the rest of the paper where the proband is this individual.
- OMIM:617248 for MGCA8 is stated in the paper (sec:1 ¶1); OMIM ids for Barth syndrome and SMA1 are supplied from curator knowledge, not the paper.