# PMID_42581774_Patient_2
**Source:** PMID 42581774 · Molecular genetics genomic medicine 2026 · DOI 10.1002/mgg3.70278 · licence: None · tier: epmc
**Individual:** Patient 2 · sex MALE · onset ? (Neonatal) · presentation – · last follow-up P3D (3 days) · DECEASED
**Evidence verification:** 11/11 quotes found in their anchored unit, 11/11 anywhere in the document; narrative source: extractor

## Patient description (verbatim from the source, by anchor)

> **[abstract]** Introduction: Type VIII 3‐methylglutaconic aciduria (MGCA8) is a neurodegenerative disorder which involves biallelic pathogenic variants of HTRA2. This gene encodes a mitochondrial serine protease responsible for apoptosis regulation and mitochondrial proteins' quality. Clinical manifestations include dysfunctional muscle tone, movement disorder, severe encephalopathy, epileptic seizures, dysautonomia, feeding difficulty, intermittent neutropenia, bradycardia, and recurrent apneas, often progressing into respiratory failure.
Case Report: We describe a newborn presenting with abnormal muscle tone, progressive dystonic movements, recurrent apneas, feeding difficulties, and epileptic seizures. Biochemical analysis revealed a markedly elevated urinary 3‐methylglutaconic acid, and genetic test identified biallelic pathogenic variant in HTRA2. Brain MRI revealed progressive brain atrophy, thalamic hypoplasia, and ventriculomegaly. EEG recordings found organizational abnormalities that turned into epileptic spasms. Despite intensive care, the patient suffered rapid neurological decline and died following a prolonged apnea episode. Thereafter the family had another infant diagnosed with the same biallelic pathogenic variant in HTRA2, that died a few days after birth due to respiratory failure.
Discussion: MGCA8 is a lethal condition characterized by loss‐of‐function biallelic mutations in HTRA2, which lead to mitochondrial dysfunction and altered apoptosis regulation, especially in the brain. High levels of 3‐methylglutaconic acid in urine are one important early diagnostic marker, when associated with a consistent clinical phenotype. Our report contributes to the limited existing case series and provides a detailed characterization of the EEG findings associated with this rare condition.
>
> **[sec:2 ¶1]** We report the case of a neonate born to consanguineous Pakistani parents (cousins beyond the third degree) with a positive family history for intellectual disability and neonatal‐onset epilepsy of unknown etiology. Delivery occurred via cesarean section at 32 weeks +3 days gestational age, following a pregnancy complicated by multiple threatened abortions and premature rupture of membranes. At birth, neonatal parameters and neurological examination were within normal limits.
>
> **[sec:2 ¶12]** Postmortem whole‐exome sequencing (WES) identified two compound heterozygous variants in HTRA2 (NM_013247.5): the c.1015C>T (p.Arg339Ter) nonsense variant, maternally inherited, and the c.1211G>A (p.Arg404Gln) missense variant, inherited from the father, as assessed by Sanger sequencing. Both variants were classified as pathogenic according to The American College of Medical Genetics and Genomics (ACMG) guidelines (PVS1 + PM2 and PS3 + PM2 + PM3 + PM5, respectively) (Richards et al. 2015), confirming the diagnosis of type VIII 3‐methylglutaconic aciduria (Table S1). The c.1015C>T has not previously been reported, whereas c.1211G>A has been described in homozygosity in a female subject with MGCA8. This substitution affects the last nucleotide of exon 7, leading to exon 7 skipping, and previous Western blot analysis of patient‐derived fibroblasts demonstrated complete depletion of the corresponding protein (Mandel et al. 2016). The family had another baby born at 36.3 weeks GA that died a few days after birth due to respiratory failure. Urinary organic acid analysis revealed a significant increase of 3‐methylglutaric acid 60 H mM/M (normal values 0–7). Molecular analysis of the proband identified the two compound heterozygous variants in HTRA2 (NM_013247.5) previously reported in the deceased brother. The infant was born in another hospital so no information about neurological examination, EEG or neuroradiological findings are available.
>
> **[sec:2 ¶13]** Genetic variants and the family pedigree are detailed in Table 1, Figure 3 and Table S1, respectively.
>
> **[sec:3 ¶6]** Feeding and sucking difficulties, also observed in our patient, are frequently reported, as are respiratory problems, typically manifesting as central apnoeas and progressive respiratory failure requiring invasive mechanical ventilation (Mandel et al. 2016; Gurusamy et al. 2024; Oláhová et al. 2017; Sreedhara et al. 2020; Kovacs‐Nagy et al. 2018). All published cases, including this case report, exhibited a clinical course culminating in death due to progressive respiratory failure or related complications, underscoring the critical importance of early and intensive respiratory management in this disorder.
>
> **[tab:2 c10]** : This paper
Individual (as in reference): Patient 1 (m); Patient 2 (m)
Age of onset: Neonatal; Neonatal
Age of death: 4 month; 3 days
Muscle tone: Hypotonia; hypotonia
Movement disorder: Dystonia, tremor, progressive akinesia; NA
Acquisition of milestones: No; No
Recurrent apnoea: Yes; Yes
Respiratory insufficiency: Yes; Yes
Dysphagia: Yes; NA
Tube feeding: Yes; NA
Seizures: Yes; No
Cerebral atrophy: Yes; NA
Neutropenia: Yes (intermittent); NA
Elevated serum lactate: NA; NA
Elevated urinary 3‐methylglutaconic acid: Yes; Yes
HTRA2Variant(s): c.1015C>T, p.Arg339Ter + c.1211G>A, p.Arg404Gln (comp het); c.1015C>T, p.Arg339Ter + c.1211G>A, p.Arg404Gln (comp het)
EEG: α‐like rhythmic activity; hypsarrhythmia; epileptic spasms; NA
>

## Diagnoses

- ✓ **FINAL** 3‐methylglutaconic aciduria type VIII (MGCA8), same biallelic pathogenic variant in HTRA2 as the brother → 3-methylglutaconic aciduria type 8 MONDO:0044723 OMIM:617248 · tier MOLECULAR · route unknown  
  “Thereafter the family had another infant diagnosed with the same biallelic pathogenic variant in HTRA2, that died a few days after birth due to respiratory failure.” [abstract]

## Genetic findings

- ✓ **HTRA2** c.1015C>T p.Arg339Ter · COMPOUND_HETEROZYGOUS · pathogenic · –  
  “Molecular analysis of the proband identified the two compound heterozygous variants in HTRA2 (NM_013247.5) previously reported in the deceased brother.” [sec:2 ¶12]
- ✓ **HTRA2** c.1211G>A p.Arg404Gln · COMPOUND_HETEROZYGOUS · pathogenic · –  
  “c.1015C>T, p.Arg339Ter + c.1211G>A, p.Arg404Gln (comp het); c.1015C>T, p.Arg339Ter + c.1211G>A, p.Arg404Gln (comp het)” [tab:2 r17c10]

## Measurements

| ✓ | analyte | specimen | value | unit | ref | interp | timing | quote [anchor] |
|---|---|---|---|---|---|---|---|---|
| ✓ | urinary 3‐methylglutaric acid → 3-methylglutaric acid | urine | 60 | mM/M | normal values 0–7 | HIGH | neonatal period (before death a few days after birth) | “Urinary organic acid analysis revealed a significant increase of 3‐methylglutaric acid 60 H mM/M (normal values 0–7).” [sec:2 ¶12] |
| ✓ | urinary 3‐methylglutaconic acid → 3-methylglutaconic acid | urine | Yes (elevated) |  |  | HIGH |  | “Yes; Yes” [tab:2 r16c10] |

## Phenotypes

- ✓ Premature birth → Premature birth HP:0001622 (grounded)  
  “The family had another baby born at 36.3 weeks GA that died a few days after birth due to respiratory failure.” [sec:2 ¶12]
- ✓ Respiratory failure → Respiratory failure HP:0002878 (grounded)  
  “The family had another baby born at 36.3 weeks GA that died a few days after birth due to respiratory failure.” [sec:2 ¶12]
- ✓ Respiratory insufficiency → Respiratory insufficiency HP:0002093 (grounded)  
  “Yes; Yes” [tab:2 r9c10]
- ✓ Recurrent apnea → Apnea HP:0002104 (grounded)  
  “Yes; Yes” [tab:2 r8c10]
- ✓ Hypotonia → Hypotonia HP:0001252 (grounded)  
  “Hypotonia; hypotonia” [tab:2 r5c10]
- ✓ NOT Seizure → Seizure HP:0001250 (grounded)  
  “Yes; No” [tab:2 r12c10]

## Outcome

Died a few days after birth (3 days per Table 2) due to respiratory failure.

## Model summary (not source text)

A male infant, younger brother of Patient 1, was born at 36.3 weeks of gestation to consanguineous Pakistani parents. He had hypotonia, recurrent apnea and respiratory insufficiency, and died a few days after birth (3 days per Table 2) due to respiratory failure; no seizures were reported. Urinary organic acid analysis showed a significant increase of 3-methylglutaric acid (60 mM/M, normal 0-7), and Table 2 reports elevated urinary 3-methylglutaconic acid. Molecular analysis identified the same compound heterozygous pathogenic HTRA2 variants as in his deceased brother, c.1015C>T (p.Arg339Ter, maternal) and c.1211G>A (p.Arg404Gln, paternal), establishing the diagnosis of 3-methylglutaconic aciduria type VIII. He was born in another hospital, so no neurological examination, EEG or neuroimaging data are available.

## Extractor notes

- Individual is unnamed in the text ('another baby', 'another infant', 'the proband' in one sentence of sec:2 ¶12); local_id 'Patient 2' is taken from Table 2 column 'This paper' ('Patient 1 (m); Patient 2 (m)'), where this individual is the second (post-semicolon) value in each c10 cell.
- In sec:2 ¶12 'Molecular analysis of the proband identified the two compound heterozygous variants in HTRA2 (NM_013247.5) previously reported in the deceased brother' uses 'proband' for this infant, inconsistent with the rest of the paper and Figure 3 ('The proband and his brother'), where the proband is Patient 1. Sex (male) is taken from Table 2 'Patient 2 (m)' and Figure 3 'his brother'.
- Gestational age is written as '36.3 weeks GA'; this may mean 36 weeks + 3 days (36.43) rather than the decimal 36.3; recorded as written.
- Age at death: text says 'a few days after birth'; Table 2 r4c10 gives '3 days' (recorded as P3D). Table 2 r3c10 gives age of onset 'Neonatal'.
- Urinary organic acid value is written as '3-methylglutaric acid 60 H mM/M (normal values 0–7)'; 'H' is presumably a laboratory high flag and 'mM/M' presumably mmol/mol creatinine. As for Patient 1, the text names 3-methylglutaric acid whereas the abstract and Table 2 r16 describe elevated urinary 3-methylglutaconic acid; possible analyte mislabelling by the authors.
- Molecular method for this infant is not stated ('Molecular analysis'); inheritance (maternal c.1015C>T, paternal c.1211G>A) and the pathogenic classification are taken from Figure 3 legend and Table 1 for the family, not restated specifically for this infant. Diagnostic route not stated (recorded as unknown); the infant was likely tested because of the brother's diagnosis but the paper does not say so.
- Table 2 c10 entries for this infant: movement disorder NA, milestones 'No' (not recorded: infant died at 3 days), dysphagia NA, tube feeding NA, cerebral atrophy NA, neutropenia NA, serum lactate NA, EEG NA. The paper states no neurological examination, EEG or neuroradiological findings are available because the infant was born in another hospital.
- Ancestry (Pakistani) and consanguinity are stated for the parents of Patient 1 and carried over to this sibling of the same family.