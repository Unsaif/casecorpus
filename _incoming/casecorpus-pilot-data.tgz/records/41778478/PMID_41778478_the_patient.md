# PMID_41778478_the_patient
**Source:** PMID 41778478 · Annals of African medicine 2026 · DOI 10.4103/aam.aam_624_25 · licence: None · tier: epmc
**Individual:** the patient · sex MALE · onset – · presentation P24D (24-day-old) · last follow-up – · DECEASED
**Evidence verification:** 50/55 quotes found in their anchored unit, 55/55 anywhere in the document; narrative source: manifest

## Patient description (verbatim from the source, by anchor)

> **[abstract]** Familial hyperchylomicronemia syndrome, which is also known as type 1 hyperlipoproteinemia, is a very rare autosomal recessive disorder of lipoprotein metabolism which affects approximately one per million individuals. Familial hyperchylomicronemia is characterized by severe hypertriglyceridemia,with triglyceride level>880 mg/L. This is result of excessive accumulation of chylomicron and inherited defect in hydrolysis of circulating triglyceride. A 24-day-old male admitted to the neonatal intensive care unit with complaints of excessive crying with refusal to feed. During routine blood sampling, blood was found viscous and turned milky white after few seconds. So we diagnosed as a case of familial hyperchylomicronemia with late onset sepsis ,on the basis of high index of suspicion, high plasma triglyceride level, with second degree of early cardiac disease in family which was further genetically confirmed by whole exome sequencing, showing homozygous lipoprotein lipase gene mutation.
>
> **[sec:2 ¶1]** A 24-day-old male admitted to the neonatal intensive care unit (NICU) with complaints of excessive crying with refusal to feed. The baby had no history of fever, vomiting, abdominal distension, or any cyclic movement. In birth history, the baby was delivered by lower section cesarean section and cried immediately after birth and no history of NICU admission. The marriage was nonconsanguineous. The mother had no history of any significant medical disease, fever, or drug intake except iron and folic acid. Hence, provisional diagnosis of late-onset sepsis was made. During sampling, blood was found to be highly viscous and turned milky white after few seconds [Figure 1]. The baby was exclusively breastfed. On head-to-toe examination, the baby had no dysmorphic face or any skin lesion. In vitals – capillary refill time was <2 s, respiratory rate was 34/min, and heart rate was 140/min. In systemic central nervous system examination, the anterior fontanelle was open, normal, and in the neonatal reflex, sucking and rooting were poor and depressed. Other cardiac, respiratory, and per abdomen examinations were normal. Hence, familial hyperchylomicronemia was suspected. In reviewing of family history, parents had no history of any xanthelasma or cardiac disease. However, grandfather had a history of cardiac disease diagnosed at the age of 30 years.
>
> **[sec:3 ¶1]** In septic screen, total leukocyte count was 12780/cmm (range 4000–11000 u/L) (neutrophil: 45.7% [40%–75%] and lymphocyte: 43.3% [20%–45%]), Hb was 35.1 g/dl (range 12–16 g/dl), platelet count was 5.53 lakh/cmm (range 1.–4.5 lakh/uL), and C-reactive protein was 48 mg/L (0–6 mg/l), and peripheral smear showed normocytic normochromic blood cells. Blood culture and urine culture were sterile. Other evaluations, including random blood sugar, serum electrolyte, and kidney and liver function, were normal. Parental lipid profile was normal. However, lipid profile of baby showed very high triglyceride (1180 mg/dl),ratio of triglyceride-cholesterol 4.06, low level of low-density lipoprotein (LDL), VLDL and high-density lipoprotein [Table 1]. Ophthalmological examination showed lipemia retinalis [Figure 2]. In genetic study, Whole Exome Sequencing showed homozygous pathogenic variant in the LPL gene associated with hyperlipoprotenemia, type 1 (location exon 5, variant c. 644>A).
>
> **[sec:3 ¶2]** The baby was treated with broad-spectrum antibiotics (injection ceftriaxone and injection amikacin) and supportive isolyte P IV fluid. In feeding, breast milk was replaced with low-fat formula feed and MCT oil (medium-chain triglyceride), and fat-soluble vitamins were added. After 10 days of treatment, the baby was discharged from NICU.At the time of discharge, lipid profile of baby was repeated, which showed mild decrease in the triglyceride level (980 mg/dl). The baby was brought dead in emergency after 17 days of discharge, and the cause of death was unexplained
>
> **[sec:4 ¶1]** In this case report, we have described a newborn which was suffering from familial hyperchylomicronemia with LONS (Late onset neonatal sepsis), who was suspected on the basis of white plasma during sampling, and confirmed by abnormal lipid profile and whole exome sequencing showed homozygous pathogenic variant in the LPL gene associated with hyperlipoprotenemia, type 1 (location Exon 5, variant c.644>A). FCS occurs due to biallelic loss of the functional LPL gene or 1 of 4 other genes that encode the other cofactor and regulator.[8910] FCS, is caused by loss of both copies of LPL gene, like to my case.[11] Severe hypertriglyceridemia may occur secondary due to diabetes, hypothyroidism, poor diet, nephrotic syndrome, obesity, and medicine.[9] FCS is diagnosed commonly at the childhood or adolescence , presenting with failure to thrive, recurrent abdominal pain with recurrent pancreatitis, lipemia retinalis, eruptive xanthoma, and hepatosplenomegaly.[12] In neonate and young children can be diagnosed during blood sampling when blood appears milky white with a high index of suspicion.[7] Patients with FCS have chances of 60%–90% lifetime risk of pancreatitis with at least 1 recurrence.[13] In laboratory investigations, all suspected patients of FCS include fasting lipid profile, plasma apo B concentration, thyroid-stimulating hormone, glycosated hemoglobin (Hb), serum transaminase, serum creatinine, and urine examination for glucose, protein, and albumin–creatinine ratio. In genetic testing, next-generation DNA sequencing is the gold standard for diagnosing the FCS.[14] In this case, report of false high level of Hb (35.1 g/dl) and platelets( 5.53 lakh) was found, which may be occurred due to increase sample turbidity. Hence, clinicians must be aware of it. In the treatment of FCS, multidisciplinary approach is required. In infancy, breastfeeding should pause due to high fat content and be replaced with low-fat formula with added MCT oil and fat-soluble micronutrient.[710] During the weaning period, <10%–15% of total daily caloric intake, approximately 5–10 gr of fat per day, should come from fat.[15] Family education is also an important part of management, in which awareness about preparation of low-fat diet, adherence to treatment and recognizing the sign of pancreatitis is essential. Fibrates, statins, omega-3 fatty acid, niacin, and ezetimbe are ineffective in treatment of FCS because of PCSK9 inhibitors don’t work in lipolytic pathway.[16] Plasmapheresis or plasma exchange in which direct removal of TG is useful.[12] Genetic counseling is important for care of index case, inheritance pattern, and potential risk for first-degree relatives.[17] Hence, genetic screening should be done in all siblings with a genetically confirmed case of FCS.
>
> **[tab:1 r1]** Biochemical parameters | Patient value (mg/dl) | Normal value (mg/dl)
>
> **[tab:1 r2]** Serum cholesterol | 290 | <200
>
> **[tab:1 r3]** Serum TG | 1180 | <150
>
> **[tab:1 r4]** HDL | 34 | More than 60
>
> **[tab:1 r5]** LDL | 126 | <130
>
> **[tab:1 r6]** VLDL | 16 | <30
>

## Diagnoses

- ✓ **FINAL** Familial hyperchylomicronemia syndrome (type 1 hyperlipoproteinemia) → Familial chylomicronemia (hyperlipoproteinemia type I, lipoprotein lipase deficiency)  OMIM:238600 · tier MOLECULAR · route incidental  
  “So we diagnosed as a case of familial hyperchylomicronemia with late onset sepsis ,on the basis of high index of suspicion, high plasma triglyceride level” [abstract]
- ✓ **FINAL** Late-onset neonatal sepsis → Late-onset neonatal sepsis   · tier CLINICAL · route symptomatic  
  “we have described a newborn which was suffering from familial hyperchylomicronemia with LONS (Late onset neonatal sepsis), who was suspected on the basis of white plasma during sampling, and confirmed by abnormal lipid profile and whole exome sequencing” [sec:4 ¶1]

## Genetic findings

- ✓ **LPL** exon 5, variant c. 644>A (as written; reference nucleotide not given)  · HOMOZYGOUS · pathogenic · WES  
  “In genetic study, Whole Exome Sequencing showed homozygous pathogenic variant in the LPL gene associated with hyperlipoprotenemia, type 1 (location exon 5, variant c. 644>A).” [sec:3 ¶1]

## Measurements

| ✓ | analyte | specimen | value | unit | ref | interp | timing | quote [anchor] |
|---|---|---|---|---|---|---|---|---|
| ✓ | total leukocyte count | blood | 12780 | /cmm | range 4000–11000 u/L | HIGH | at presentation (NICU admission, septic screen) | “In septic screen, total leukocyte count was 12780/cmm (range 4000–11000 u/L)” [sec:3 ¶1] |
| ✓ | neutrophil → neutrophils | blood | 45.7 | % | 40%–75% | NORMAL | at presentation (NICU admission, septic screen) | “neutrophil: 45.7% [40%–75%]” [sec:3 ¶1] |
| ✓ | lymphocyte | blood | 43.3 | % | 20%–45% | NORMAL | at presentation (NICU admission, septic screen) | “lymphocyte: 43.3% [20%–45%]” [sec:3 ¶1] |
| ✓ | Hb → haemoglobin | blood | 35.1 | g/dl | range 12–16 g/dl | HIGH | at presentation (NICU admission, septic screen) | “Hb was 35.1 g/dl (range 12–16 g/dl)” [sec:3 ¶1] |
| ✓ | platelet count → platelets | blood | 5.53 | lakh/cmm | range 1.–4.5 lakh/uL | HIGH | at presentation (NICU admission, septic screen) | “platelet count was 5.53 lakh/cmm (range 1.–4.5 lakh/uL)” [sec:3 ¶1] |
| ✓ | C-reactive protein | blood | 48 | mg/L | 0–6 mg/l | HIGH | at presentation (NICU admission, septic screen) | “C-reactive protein was 48 mg/L (0–6 mg/l)” [sec:3 ¶1] |
| ✓ | Blood culture | blood | sterile |  |  | NORMAL | at presentation (NICU admission, septic screen) | “Blood culture and urine culture were sterile.” [sec:3 ¶1] |
| ✓ | urine culture | urine | sterile |  |  | NORMAL | at presentation (NICU admission, septic screen) | “Blood culture and urine culture were sterile.” [sec:3 ¶1] |
| ✓ | random blood sugar | blood | normal |  |  | NORMAL | at presentation (NICU admission, septic screen) | “Other evaluations, including random blood sugar, serum electrolyte, and kidney and liver function, were normal.” [sec:3 ¶1] |
| ✓ | serum electrolyte | serum | normal |  |  | NORMAL | at presentation (NICU admission, septic screen) | “Other evaluations, including random blood sugar, serum electrolyte, and kidney and liver function, were normal.” [sec:3 ¶1] |
| ✓ | kidney function | unknown | normal |  |  | NORMAL | at presentation (NICU admission, septic screen) | “Other evaluations, including random blood sugar, serum electrolyte, and kidney and liver function, were normal.” [sec:3 ¶1] |
| ✓ | liver function | unknown | normal |  |  | NORMAL | at presentation (NICU admission, septic screen) | “Other evaluations, including random blood sugar, serum electrolyte, and kidney and liver function, were normal.” [sec:3 ¶1] |
| ~ | Serum cholesterol → cholesterol | serum | 290 | mg/dl | <200 | HIGH | initial lipid profile during NICU admission (before dietary change) | “Serum cholesterol / 290 / <200” [tab:1 r2c2] |
| ~ | Serum TG | serum | 1180 | mg/dl | <150 | HIGH | initial lipid profile during NICU admission (before dietary change) | “Serum TG / 1180 / <150” [tab:1 r3c2] |
| ~ | HDL | serum | 34 | mg/dl | More than 60 | LOW | initial lipid profile during NICU admission (before dietary change) | “HDL / 34 / More than 60” [tab:1 r4c2] |
| ~ | LDL | serum | 126 | mg/dl | <130 | NORMAL | initial lipid profile during NICU admission (before dietary change) | “LDL / 126 / <130” [tab:1 r5c2] |
| ~ | VLDL | serum | 16 | mg/dl | <30 | NORMAL | initial lipid profile during NICU admission (before dietary change) | “VLDL / 16 / <30” [tab:1 r6c2] |
| ✓ | ratio of triglyceride-cholesterol | serum | 4.06 |  |  | UNKNOWN | initial lipid profile during NICU admission (before dietary change) | “ratio of triglyceride-cholesterol 4.06” [sec:3 ¶1] |
| ✓ | triglyceride | serum | 980 | mg/dl |  | HIGH | at discharge, after 10 days of treatment (on low-fat formula, MCT oil) | “At the time of discharge, lipid profile of baby was repeated, which showed mild decrease in the triglyceride level (980 ” [sec:3 ¶2] |
| ✓ | capillary refill time | other | <2 s | s |  | UNKNOWN | at presentation | “In vitals – capillary refill time was <2 s, respiratory rate was 34/min, and heart rate was 140/min.” [sec:2 ¶1] |
| ✓ | respiratory rate | other | 34 | /min |  | UNKNOWN | at presentation | “In vitals – capillary refill time was <2 s, respiratory rate was 34/min, and heart rate was 140/min.” [sec:2 ¶1] |
| ✓ | heart rate | other | 140 | /min |  | UNKNOWN | at presentation | “In vitals – capillary refill time was <2 s, respiratory rate was 34/min, and heart rate was 140/min.” [sec:2 ¶1] |

## Phenotypes

- ✓ Excessive crying → –  (candidate)  
  “A 24-day-old male admitted to the neonatal intensive care unit (NICU) with complaints of excessive crying with refusal to feed.” [sec:2 ¶1]
- ✓ Feeding difficulties → Feeding difficulties HP:0011968 (grounded)  
  “A 24-day-old male admitted to the neonatal intensive care unit (NICU) with complaints of excessive crying with refusal to feed.” [sec:2 ¶1]
- ✓ NOT Fever → Fever HP:0001945 (grounded)  
  “The baby had no history of fever, vomiting, abdominal distension, or any cyclic movement.” [sec:2 ¶1]
- ✓ NOT Vomiting → Vomiting HP:0002013 (grounded)  
  “The baby had no history of fever, vomiting, abdominal distension, or any cyclic movement.” [sec:2 ¶1]
- ✓ NOT Abdominal distention → Abdominal distention HP:0003270 (grounded)  
  “The baby had no history of fever, vomiting, abdominal distension, or any cyclic movement.” [sec:2 ¶1]
- ✓ NOT Cyclic movements → –  (candidate)  
  “The baby had no history of fever, vomiting, abdominal distension, or any cyclic movement.” [sec:2 ¶1]
- ✓ NOT Abnormal facial shape → Abnormal facial shape HP:0001999 (grounded)  
  “On head-to-toe examination, the baby had no dysmorphic face or any skin lesion.” [sec:2 ¶1]
- ✓ NOT Skin lesion → Abnormality of the skin HP:0000951 (candidate)  
  “On head-to-toe examination, the baby had no dysmorphic face or any skin lesion.” [sec:2 ¶1]
- ✓ Poor suck → Poor suck HP:0002033 (grounded)  
  “in the neonatal reflex, sucking and rooting were poor and depressed” [sec:2 ¶1]
- ✓ Weak rooting reflex → –  (candidate)  
  “in the neonatal reflex, sucking and rooting were poor and depressed” [sec:2 ¶1]
- ✓ NOT Abnormal anterior fontanelle morphology → Abnormal anterior fontanelle morphology HP:0000236 (grounded)  
  “the anterior fontanelle was open, normal” [sec:2 ¶1]
- ✓ NOT Abnormality of the cardiovascular system → Abnormality of the cardiovascular system HP:0001626 (grounded)  
  “Other cardiac, respiratory, and per abdomen examinations were normal.” [sec:2 ¶1]
- ✓ NOT Abnormality of the respiratory system → Abnormality of the respiratory system HP:0002086 (grounded)  
  “Other cardiac, respiratory, and per abdomen examinations were normal.” [sec:2 ¶1]
- ✓ NOT Abnormality of the abdomen → Abnormal abdomen morphology HP:0001438 (grounded)  
  “Other cardiac, respiratory, and per abdomen examinations were normal.” [sec:2 ¶1]
- ✓ Increased blood viscosity → –  (candidate)  
  “During sampling, blood was found to be highly viscous and turned milky white after few seconds” [sec:2 ¶1]
- ✓ Lactescent (milky white) plasma → –  (candidate)  
  “During sampling, blood was found to be highly viscous and turned milky white after few seconds” [sec:2 ¶1]
- ✓ Lipemia retinalis → Lipemia retinalis HP:0000660 (grounded)  
  “Ophthalmological examination showed lipemia retinalis” [sec:3 ¶1]
- ✓ Hypertriglyceridemia → Hypertriglyceridemia HP:0002155 (grounded)  
  “lipid profile of baby showed very high triglyceride (1180 mg/dl)” [sec:3 ¶1]
- ✓ Decreased HDL cholesterol concentration → Decreased circulating HDL-C concentration HP:0003233 (candidate)  
  “low level of low-density lipoprotein (LDL), VLDL and high-density lipoprotein” [sec:3 ¶1]
- ✓ Decreased LDL cholesterol concentration → Decreased circulating LDL-C concentration HP:0003563 (candidate)  
  “low level of low-density lipoprotein (LDL), VLDL and high-density lipoprotein” [sec:3 ¶1]
- ✓ Decreased VLDL cholesterol concentration → Decreased circulating VLDL-C concentration HP:0031243 (candidate)  
  “low level of low-density lipoprotein (LDL), VLDL and high-density lipoprotein” [sec:3 ¶1]
- ✓ Elevated circulating C-reactive protein concentration → Elevated circulating C-reactive protein concentration HP:0011227 (grounded)  
  “C-reactive protein was 48 mg/L (0–6 mg/l)” [sec:3 ¶1]
- ✓ NOT Abnormal erythrocyte morphology → Abnormal erythrocyte morphology HP:0001877 (grounded)  
  “peripheral smear showed normocytic normochromic blood cells” [sec:3 ¶1]
- ✓ Late-onset neonatal sepsis → Neonatal sepsis HP:0040187 (grounded)  
  “we have described a newborn which was suffering from familial hyperchylomicronemia with LONS (Late onset neonatal sepsis), who was suspected on the basis of white plasma during sampling, and confirmed by abnormal lipid profile and whole exome sequencing” [sec:4 ¶1]
- ✓ Death in infancy → Death in infancy HP:0001522 (grounded)  
  “The baby was brought dead in emergency after 17 days of discharge, and the cause of death was unexplained” [sec:3 ¶2]

## Treatments

- ✓ drug: ceftriaxone and amikacin · response not_stated  
  “The baby was treated with broad-spectrum antibiotics (injection ceftriaxone and injection amikacin) and supportive isolyte P IV fluid.” [sec:3 ¶2]
- ✓ supportive: isolyte P intravenous fluid · response not_stated  
  “The baby was treated with broad-spectrum antibiotics (injection ceftriaxone and injection amikacin) and supportive isolyte P IV fluid.” [sec:3 ¶2]
- ✓ diet: low-fat formula feed · response improved  
  “In feeding, breast milk was replaced with low-fat formula feed and MCT oil (medium-chain triglyceride), and fat-soluble vitamins were added.” [sec:3 ¶2]
- ✓ diet: medium-chain triglyceride oil · response improved  
  “In feeding, breast milk was replaced with low-fat formula feed and MCT oil (medium-chain triglyceride), and fat-soluble vitamins were added.” [sec:3 ¶2]
- ✓ cofactor_vitamin: fat-soluble vitamins · response not_stated  
  “In feeding, breast milk was replaced with low-fat formula feed and MCT oil (medium-chain triglyceride), and fat-soluble vitamins were added.” [sec:3 ¶2]

## Outcome

Discharged from the NICU after 10 days of treatment with a mild decrease in triglyceride (980 mg/dl). Brought dead to the emergency department 17 days after discharge; the cause of death was unexplained.

## Model summary (not source text)

A 24-day-old male born at term by lower-segment caesarean section to nonconsanguineous parents was admitted to the NICU with excessive crying and refusal to feed, and a provisional diagnosis of late-onset sepsis was made. During blood sampling the blood was highly viscous and turned milky white; examination showed poor sucking and rooting reflexes without dysmorphism, and ophthalmological examination showed lipemia retinalis. Septic screen showed leukocyte count 12780/cmm and CRP 48 mg/L with sterile blood and urine cultures; haemoglobin (35.1 g/dl) and platelets (5.53 lakh/cmm) were reported as falsely high due to sample turbidity. Lipid profile showed serum triglyceride 1180 mg/dl, cholesterol 290 mg/dl and HDL 34 mg/dl, while parental lipid profiles were normal; whole exome sequencing showed a homozygous pathogenic LPL variant (exon 5, c. 644>A), confirming familial hyperchylomicronemia syndrome. He was treated with ceftriaxone, amikacin, IV fluids, low-fat formula with MCT oil and fat-soluble vitamins; triglyceride fell to 980 mg/dl at discharge after 10 days. He was brought dead 17 days after discharge and the cause of death was unexplained.

## Extractor notes

- Text vs Table 1 conflict: sec:3 ¶1 states 'low level of low-density lipoprotein (LDL), VLDL and high-density lipoprotein', but Table 1 gives LDL 126 mg/dl (normal <130) and VLDL 16 mg/dl (normal <30), i.e. within the stated normal ranges. Table values are recorded as measurements with interpretation by reference range (NORMAL); the text claim is kept as phenotypes 'Decreased LDL/VLDL cholesterol concentration'. HDL 34 (normal >60) is low in both.
- Triglyceride 1180 mg/dl appears in text (sec:3 ¶1) and Table 1 (r3); recorded once from the table. The abstract/introduction give the disease-defining threshold as '>880 mg/L', which is probably a typo for mg/dL; it is not patient data and was not extracted.
- Authors state in the discussion that the haemoglobin (35.1 g/dl) and platelet count (5.53 lakh) were falsely high because of sample turbidity; both are recorded as HIGH by reference range with the artefact noted in 'condition'.
- LPL variant is written only as 'location exon 5, variant c. 644>A'; the reference nucleotide, transcript and protein change are not given, so variant_hgvs_c is left null and the string is kept in variant_text. Parental genotypes were not reported (inheritance_as_stated null).
- Age at death is not stated explicitly; it can be derived (admitted at 24 days, discharged after 10 days of treatment, died 17 days after discharge, i.e. roughly 51 days) but was not estimated in iso8601.
- Gestational age is only given as 'term' in the title; no weeks or birth weight are reported.
- Late-onset sepsis was a provisional diagnosis at admission and is retained by the authors in the final diagnosis ('familial hyperchylomicronemia with late onset sepsis') although blood and urine cultures were sterile.
- Diagnostic route recorded as 'incidental' because FCS was suspected from milky plasma during routine sampling for a sepsis work-up; the admission itself was symptomatic (crying, refusal to feed).
- 'no history of ... any cyclic movement' (sec:2 ¶1) is ambiguous (possibly seizure-like movements); recorded as excluded phenotype 'Cyclic movements' without HPO id.
- Specimen for the discharge lipid profile is not stated; recorded as serum by analogy with Table 1 ('Serum TG'). CRP and blood counts recorded with specimen 'blood'.
- Disease grounded to MONDO:0009387 familial lipoprotein lipase deficiency (OMIM:238600, ORPHA:309015) because the authors equate the diagnosis with hyperlipoproteinemia type 1 and report a homozygous LPL variant; the broader umbrella term 'familial chylomicronemia syndrome' is MONDO:0018637 (ORPHA:444490).
- Parental lipid profile normal (sec:3 ¶1) is relative data, not recorded as a measurement for the patient; captured in family_history_text.