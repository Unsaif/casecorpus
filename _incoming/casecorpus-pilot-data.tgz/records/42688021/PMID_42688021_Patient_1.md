# PMID_42688021_Patient_1
**Source:** PMID 42688021 · Frontiers in endocrinology 2026 · DOI 10.3389/fendo.2026.1912249 · licence: None · tier: epmc
**Individual:** Patient 1 · sex FEMALE · onset P6M (six months of age) · presentation P6M (six months of age) · last follow-up P9Y (9 years of age) · ALIVE
**Evidence verification:** 29/39 quotes found in their anchored unit, 39/39 anywhere in the document; narrative source: extractor

## Patient description (verbatim from the source, by anchor)

> **[abstract]** Background: Lipoid congenital adrenal hyperplasia (LCAH) is an uncommon but life-threatening autosomal recessive disorder. It is caused by a mutation in the steroidogenic acute regulatory protein (StAR), encoded by the STAR gene.
Methods: Clinical manifestations of two siblings with primary adrenal insufficiency (PAI) were described. A female infant was admitted to the hospital at six months of age for vomiting and failure to thrive. The diagnosis of PAI of unknown etiology was established. The girl’s younger brother was diagnosed with PAI at the age of 1.5 years during a febrile illness. His external genitalia showed undescended testes, scrotal hypoplasia, and hypospadia. Their family history was normal, and both parents were healthy. Clinical exome sequencing was used to identify mutations in candidate genes.
Results: Two heterozygous STAR mutations, p.Trp250Ter and p.Arg188Cys, were identified in both children. The mother was heterozygous for the p.Trp250Ter mutation, and the father was heterozygous for the p.Arg188Cys mutation.
Conclusion: Glucocorticoid, mineralocorticoid, and sex hormone therapy should be individualized according to the clinical presentation and laboratory findings. Because genotype and phenotype do not correlate consistently in LCAH, therapy and follow-up must be individualized.
>
> **[sec:3 ¶1]** Both patients, a sister and a brother, underwent clinical examination with assessment of growth and sexual development. Clinical data included birth measurements and birth history; family history was obtained. Routine laboratory analyses included adrenocorticotropic hormone (ACTH), cortisol, 17-hydroxyprogesterone, plasma renin activity (PRA), androstenedione, and testosterone. Genetic testing was performed, and written informed consent was obtained from both parents.
>
> **[sec:4 ¶1]** Genomic DNA was extracted from peripheral blood using the DNA extraction kit (Qiagen, Hilden, Germany). Clinical exome sequencing was performed using the TruSight One panel (Illumina), which targets the coding exons and exon–intron boundaries of 4,813 clinically relevant genes selected based on their established associations with human genetic disorders, as curated from OMIM, ClinVar, HGMD, and current clinical literature. Sequencing reads were aligned to the human reference genome (hg19). Variant analysis was initially focused on the congenital adrenal hyperplasia (CAH) gene panel (HP:0008258, Human Phenotype Ontology), with particular emphasis on CYP21A2, the most common genetic cause of CAH. Because of the high sequence homology between CYP21A2 and its pseudogene CYP21A1P, gene conversions and large deletions were additionally assessed by gene-specific PCR amplification, as previously described (7–9). Since no causative variants were identified in CYP21A2, the remaining genes in the CAH panel, along with all other genes covered by the TruSight One panel, were systematically evaluated. Common variants (minor allele frequency >1%) reported in the gnomAD Genomes, gnomAD Exomes, and 1000 Genomes databases were excluded. All pathogenic, likely pathogenic, and variants of uncertain significance (VUS) relevant to the patient’s phenotype were systematically reviewed. Variant interpretation and prioritization were performed using VarSome Professional (Saphetor SA, Lausanne, Switzerland) (10), taking into account the inheritance pattern, gene–disease association, available literature, and in silico predictions within the ACMG/AMP variant interpretation framework. Familial segregation of the identified STAR variants was evaluated using clinical exome sequencing data from both parents.
>
> **[sec:9 ¶1]** A Serbian female infant was born at 40 gestational weeks with a normal birth weight of 3710 g, a birth length of 54 cm, and normal external female genitalia without signs of virilization. She was treated with phototherapy for neonatal unconjugated hyperbilirubinemia. At six months of age, she was admitted to the hospital for vomiting and failure to thrive. Her length was 70 cm (95th percentile), weight was 6650 g (25th percentile), and external genitalia were of a normal female. Laboratory analyses showed hyponatremia at 123 mmol/l, hyperkalemia at 7 mmol/l, and normoglycemia at 5.3 mmol/l (Table 1). Basal cortisol was 8.8 µg/dl (normal 2.97-23.4 µg/dl). The ACTH stimulation test showed no significant rise in cortisol levels (0 minute 8.8 ug/dl, 30 minute 8.9 ug/dl, 60 minute 9 ug/dl), while 17-hydroxyprogesterone levels were normal (0 minute 0.42 ng/ml, 30 minute 0.43 ng/ml, 60 minute 0.33 ng/ml). Karyotype was female 46, XX. The diagnosis of primary adrenal insufficiency (PAI) of unknown etiology was established. Hydrocortisone and fludrocortisone substitutional therapy was started.
>
> **[sec:9 ¶2]** Clinical exome sequencing revealed two heterozygous pathogenic variants in the STAR gene, c.749G>A(p.Trp250Ter) and c.562C>T(p.Arg188Cys), that are associated with LCAH.
>
> **[sec:10 ¶2]** Neither parent showed any symptoms of LCAH. The mother was heterozygous for the p.Trp250Ter mutation, and the father was heterozygous for the p.Arg188Cys mutation (Figure 1).
>
> **[sec:10 ¶3]** Representative IGV screenshots of both variants in the affected siblings, together with their familial segregation, are shown in Figure 2.
>
> **[sec:11 ¶1]** The patients attended regular endocrinology follow-up visits every 6 months. Their growth was appropriate for age. They were treated with hydrocortisone (∼10 mg/m2/day) and fludrocortisone (0.05-0.1 mg/day), and their blood pressure, sodium, potassium, and PRA levels remained normal.
>
> **[sec:11 ¶3]** The girl was last seen at 9 years of age. Her height was 134 cm (50-75th percentile), and her weight was 34.5 kg (75-90th percentile). She had no clinical signs of puberty. During follow-up, patients did not develop adrenal crisis.
>
> **[sec:15 ¶1]** To our knowledge, this is the first report of siblings with LCAH in Serbia, carrying the same compound heterozygous STAR genotype: c.749G>A (p.Trp250Ter) and c.562C>T (p.Arg188Cys). The same compound variants were reported in a 46, XY male infant in Switzerland. He presented at age 3.5 months with generalized hyperpigmentation, cryptorchidism, micropenis, but no hypospadias (15).
>
> **[sec:15 ¶2]** In our two patients, LCAH was diagnosed in mid-infancy and early childhood. In the case of LCAH, even when StAR loses its function, a StAR-independent steroidogenesis continues in some organs, which explains why PAI manifests after a few months of life (4). It is shown that 14% of the cholesterol import is StAR-independent (24).
>
> **[sec:15 ¶3]** The girl presented with the most common clinical signs of PAI: failure to thrive and vomiting. Because cortisol levels did not rise significantly during the electrolyte imbalance, ACTH stimulation test was performed. The inadequate cortisol response confirmed PAI of unknown etiology (Table 1). During the first year of life, PAI may be caused by CAH due to CYP21A2 gene mutation, various syndromes, adrenal dysgenesis and hypoplasia, disorders characterized by ACTH resistance, metabolic conditions with mitochondrial or peroxisomal defects, as well as disorders of cholesterol synthesis (25, 26). The ACTH stimulation test helped exclude CAH, the most common adrenal disorder in the first few months of life. In contrast to LCAH, patients with CAH due to 21-hydroxylase deficiency have elevated levels of 17-hydroxyprogesterone, and in patients with a 46, XX karyotype, virilized external genitalia. The second most common adrenal disorder in early childhood is adrenal hypoplasia, which can be distinguished from LCAH by the presence of hypoplastic adrenals on ultrasound (3). The definitive diagnosis was made using clinical exome sequencing.
>
> **[sec:15 ¶5]** Patients with LCAH typically have low steroid hormone levels and female-appearing external genitalia in both XX and XY karyotypes. Genetic testing identified the same STAR gene variants as those found in his sister.
>
> **[tab:1 r1]** Analyses | Result | Normal range
>
> **[tab:1 r2]** Natrium (mmol/l) | 123 | 135-145
>
> **[tab:1 r3]** Potassium (mmol/l) | 7 | 3.5-5
>
> **[tab:1 r4]** Glycemia (mmol/l) | 5.3 | 3.6-6.1
>
> **[tab:1 r5]** Cortisol (µg/dl) | 8.8 | 2.97-23.4
>
> **[tab:1 r6]** PRA (ng/ml/h) | 11 | 0.3-3.9
>
> **[tab:1 r7]** Aldosterone (ng/dl) | 24.5 | 3-35
>
> **[tab:1 r8]** 17-hydroxyprogesterone (ng/ml) | 0.42 | <2
>
> **[tab:1 r9]** ACTH stimulation test (0 minute) |  | 
>
> **[tab:1 r10]** Cortisol (µg/dl) | 8.8 | 2.97-23.4
>
> **[tab:1 r11]** 17-hydroxyprogesterone (ng/ml) | 0.33 | <2
>
> **[tab:1 r12]** ACTH stimulation test (60 minute) |  | 
>
> **[tab:1 r13]** Cortisol (µg/dl) | 9 | >18
>
> **[tab:1 r14]** 17-hydroxyprogesterone (ng/ml) | 0.43 | <9.8
>
> **[tab:3 r1]** Number | Gender | Age | Presentation | Externalgenitalia | Kariotype | Variants of STAR gene (ACMG/AMP class) | Reference
>
> **[tab:3 r19]** 18. | F | 6 months | Failure to thrive, PAI | Normal female | 46, XX | Compound heterozygosity:c.749G>A, p.Trp250Ter (P)andc.562C>T, p.Arg188Cys (P) | Present case
>

## Diagnoses

- ✓ **FINAL** Lipoid congenital adrenal hyperplasia (LCAH) → congenital lipoid adrenal hyperplasia due to STAR deficency MONDO:0008725 OMIM:201710 · tier MOLECULAR · route symptomatic  
  “Clinical exome sequencing revealed two heterozygous pathogenic variants in the STAR gene, c.749G>A(p.Trp250Ter) and c.562C>T(p.Arg188Cys), that are associated with LCAH.” [sec:9 ¶2]
- ✓ **REVISED_FROM** Primary adrenal insufficiency (PAI) of unknown etiology → Primary adrenal insufficiency (PAI) of unknown etiology   · tier BIOCHEMICAL · route symptomatic  
  “The diagnosis of primary adrenal insufficiency (PAI) of unknown etiology was established.” [sec:9 ¶1]
- ✓ **EXCLUDED** Congenital adrenal hyperplasia due to 21-hydroxylase deficiency (CYP21A2) → Congenital adrenal hyperplasia due to 21-hydroxylase deficiency (CYP21A2)   · tier BIOCHEMICAL · route –  
  “The ACTH stimulation test helped exclude CAH, the most common adrenal disorder in the first few months of life.” [sec:15 ¶3]

## Genetic findings

- ✓ **STAR** c.749G>A p.Trp250Ter · COMPOUND_HETEROZYGOUS · pathogenic · clinical exome sequencing (TruSight One panel, Illumina); parental segregation by clinical exome sequencing  
  “Clinical exome sequencing revealed two heterozygous pathogenic variants in the STAR gene, c.749G>A(p.Trp250Ter) and c.562C>T(p.Arg188Cys), that are associated with LCAH.” [sec:9 ¶2]
- ✓ **STAR** c.562C>T p.Arg188Cys · COMPOUND_HETEROZYGOUS · pathogenic · clinical exome sequencing (TruSight One panel, Illumina); parental segregation by clinical exome sequencing  
  “Clinical exome sequencing revealed two heterozygous pathogenic variants in the STAR gene, c.749G>A(p.Trp250Ter) and c.562C>T(p.Arg188Cys), that are associated with LCAH.” [sec:9 ¶2]

## Measurements

| ✓ | analyte | specimen | value | unit | ref | interp | timing | quote [anchor] |
|---|---|---|---|---|---|---|---|---|
| ~ | Natrium | blood | 123 | mmol/l | 135-145 | LOW | at presentation | “/ r2 / Natrium (mmol/l) / 123 / 135-145 /” [tab:1 r2c2] |
| ~ | Potassium → potassium | blood | 7 | mmol/l | 3.5-5 | HIGH | at presentation | “/ r3 / Potassium (mmol/l) / 7 / 3.5-5 /” [tab:1 r3c2] |
| ~ | Glycemia → glucose | blood | 5.3 | mmol/l | 3.6-6.1 | NORMAL | at presentation | “/ r4 / Glycemia (mmol/l) / 5.3 / 3.6-6.1 /” [tab:1 r4c2] |
| ✓ | Cortisol (basal) → cortisol | blood | 8.8 | µg/dl | 2.97-23.4 | NORMAL | at presentation | “Basal cortisol was 8.8 µg/dl (normal 2.97-23.4 µg/dl).” [sec:9 ¶1] |
| ~ | PRA | plasma | 11 | ng/ml/h | 0.3-3.9 | HIGH | at presentation | “/ r6 / PRA (ng/ml/h) / 11 / 0.3-3.9 /” [tab:1 r6c2] |
| ~ | Aldosterone | blood | 24.5 | ng/dl | 3-35 | NORMAL | at presentation | “/ r7 / Aldosterone (ng/dl) / 24.5 / 3-35 /” [tab:1 r7c2] |
| ~ | 17-hydroxyprogesterone | blood | 0.42 | ng/ml | <2 | NORMAL | at presentation | “/ r8 / 17-hydroxyprogesterone (ng/ml) / 0.42 / <2 /” [tab:1 r8c2] |
| ~ | Cortisol → cortisol | blood | 8.8 | µg/dl | 2.97-23.4 | NORMAL | at presentation | “/ r10 / Cortisol (µg/dl) / 8.8 / 2.97-23.4 /” [tab:1 r10c2] |
| ✓ | Cortisol → cortisol | blood | 8.9 | ug/dl |  | LOW | at presentation | “The ACTH stimulation test showed no significant rise in cortisol levels (0 minute 8.8 ug/dl, 30 minute 8.9 ug/dl, 60 min” [sec:9 ¶1] |
| ~ | Cortisol → cortisol | blood | 9 | µg/dl | >18 | LOW | at presentation | “/ r13 / Cortisol (µg/dl) / 9 / >18 /” [tab:1 r13c2] |
| ~ | 17-hydroxyprogesterone | blood | 0.33 | ng/ml | <2 | NORMAL | at presentation | “/ r11 / 17-hydroxyprogesterone (ng/ml) / 0.33 / <2 /” [tab:1 r11c2] |
| ~ | 17-hydroxyprogesterone | blood | 0.43 | ng/ml | <9.8 | NORMAL | at presentation | “/ r14 / 17-hydroxyprogesterone (ng/ml) / 0.43 / <9.8 /” [tab:1 r14c2] |
| ✓ | 17-hydroxyprogesterone | blood | 0.42 | ng/ml |  | NORMAL | at presentation | “while 17-hydroxyprogesterone levels were normal (0 minute 0.42 ng/ml, 30 minute 0.43 ng/ml, 60 minute 0.33 ng/ml)” [sec:9 ¶1] |
| ✓ | 17-hydroxyprogesterone | blood | 0.43 | ng/ml |  | NORMAL | at presentation | “while 17-hydroxyprogesterone levels were normal (0 minute 0.42 ng/ml, 30 minute 0.43 ng/ml, 60 minute 0.33 ng/ml)” [sec:9 ¶1] |
| ✓ | 17-hydroxyprogesterone | blood | 0.33 | ng/ml |  | NORMAL | at presentation | “while 17-hydroxyprogesterone levels were normal (0 minute 0.42 ng/ml, 30 minute 0.43 ng/ml, 60 minute 0.33 ng/ml)” [sec:9 ¶1] |
| ✓ | sodium → sodium | blood | remained normal |  |  | NORMAL | follow-up | “They were treated with hydrocortisone (∼10 mg/m2/day) and fludrocortisone (0.05-0.1 mg/day), and their blood pressure, s” [sec:11 ¶1] |
| ✓ | potassium → potassium | blood | remained normal |  |  | NORMAL | follow-up | “They were treated with hydrocortisone (∼10 mg/m2/day) and fludrocortisone (0.05-0.1 mg/day), and their blood pressure, s” [sec:11 ¶1] |
| ✓ | PRA | plasma | remained normal |  |  | NORMAL | follow-up | “They were treated with hydrocortisone (∼10 mg/m2/day) and fludrocortisone (0.05-0.1 mg/day), and their blood pressure, s” [sec:11 ¶1] |

## Phenotypes

- ✓ Neonatal unconjugated hyperbilirubinemia → Neonatal unconjugated hyperbilirubinemia HP:0008176 (grounded)  
  “She was treated with phototherapy for neonatal unconjugated hyperbilirubinemia.” [sec:9 ¶1]
- ✓ Vomiting → Vomiting HP:0002013 (grounded)  
  “At six months of age, she was admitted to the hospital for vomiting and failure to thrive.” [sec:9 ¶1]
- ✓ Failure to thrive → Failure to thrive HP:0001508 (grounded)  
  “At six months of age, she was admitted to the hospital for vomiting and failure to thrive.” [sec:9 ¶1]
- ✓ Hyponatremia → Hyponatremia HP:0002902 (grounded)  
  “Laboratory analyses showed hyponatremia at 123 mmol/l, hyperkalemia at 7 mmol/l, and normoglycemia at 5.3 mmol/l (Table 1).” [sec:9 ¶1]
- ✓ Hyperkalemia → Hyperkalemia HP:0002153 (grounded)  
  “Laboratory analyses showed hyponatremia at 123 mmol/l, hyperkalemia at 7 mmol/l, and normoglycemia at 5.3 mmol/l (Table 1).” [sec:9 ¶1]
- ✓ NOT Hypoglycemia → Hypoglycemia HP:0001943 (grounded)  
  “Laboratory analyses showed hyponatremia at 123 mmol/l, hyperkalemia at 7 mmol/l, and normoglycemia at 5.3 mmol/l (Table 1).” [sec:9 ¶1]
- ✓ Primary adrenal insufficiency → Primary adrenal insufficiency HP:0008207 (grounded)  
  “The diagnosis of primary adrenal insufficiency (PAI) of unknown etiology was established.” [sec:9 ¶1]
- ✓ Inadequate cortisol response to ACTH stimulation → –  (candidate)  
  “The ACTH stimulation test showed no significant rise in cortisol levels (0 minute 8.8 ug/dl, 30 minute 8.9 ug/dl, 60 minute 9 ug/dl)” [sec:9 ¶1]
- ✓ NOT Virilization of external genitalia → –  (candidate)  
  “normal external female genitalia without signs of virilization” [sec:9 ¶1]
- ✓ NOT Ambiguous genitalia → Ambiguous genitalia HP:0000062 (grounded)  
  “Her length was 70 cm (95th percentile), weight was 6650 g (25th percentile), and external genitalia were of a normal female.” [sec:9 ¶1]
- ✓ NOT Growth delay → Growth delay HP:0001510 (grounded)  
  “The patients attended regular endocrinology follow-up visits every 6 months. Their growth was appropriate for age.” [sec:11 ¶1]
- ✓ NOT Clinical signs of puberty → –  (candidate)  
  “She had no clinical signs of puberty.” [sec:11 ¶3]
- ✓ NOT Adrenal crisis → –  (candidate)  
  “During follow-up, patients did not develop adrenal crisis.” [sec:11 ¶3]

## Treatments

- ✓ other: phototherapy · response –  
  “She was treated with phototherapy for neonatal unconjugated hyperbilirubinemia.” [sec:9 ¶1]
- ✓ drug: hydrocortisone · response stable  
  “Hydrocortisone and fludrocortisone substitutional therapy was started.” [sec:9 ¶1]
- ✓ drug: fludrocortisone · response stable  
  “They were treated with hydrocortisone (∼10 mg/m2/day) and fludrocortisone (0.05-0.1 mg/day), and their blood pressure, sodium, potassium, and PRA levels remained normal.” [sec:11 ¶1]

## Outcome

Alive at last follow-up at 9 years of age on hydrocortisone and fludrocortisone; growth appropriate for age (height 134 cm, 50-75th percentile; weight 34.5 kg, 75-90th percentile); no clinical signs of puberty; no adrenal crisis during follow-up.

## Model summary (not source text)

Patient 1 is a Serbian girl born at 40 weeks (birth weight 3710 g, length 54 cm) with normal female external genitalia, treated with phototherapy for neonatal unconjugated hyperbilirubinemia. At six months she was admitted with vomiting and failure to thrive; laboratory analyses showed hyponatremia (123 mmol/l), hyperkalemia (7 mmol/l), normoglycemia (5.3 mmol/l), basal cortisol 8.8 µg/dl with no significant rise on ACTH stimulation (8.9 and 9 µg/dl at 30 and 60 minutes), normal 17-hydroxyprogesterone, elevated PRA (11 ng/ml/h) and normal aldosterone (24.5 ng/dl); karyotype was 46,XX. Primary adrenal insufficiency of unknown etiology was diagnosed and hydrocortisone and fludrocortisone were started. Clinical exome sequencing identified compound heterozygous pathogenic STAR variants c.749G>A (p.Trp250Ter, maternal) and c.562C>T (p.Arg188Cys, paternal), establishing lipoid congenital adrenal hyperplasia. At last follow-up at 9 years she had appropriate growth, no clinical signs of puberty, normal sodium, potassium and PRA on treatment, and no adrenal crisis.

## Extractor notes

- Text vs Table 1 discrepancy for 17-hydroxyprogesterone during the ACTH stimulation test: text (sec:9 ¶1) gives 0/30/60 min = 0.42/0.43/0.33 ng/ml; Table 1 gives basal 0.42 (r8), ACTH 0 minute 0.33 (r11) and 60 minute 0.43 (r14). Both series were extracted; the 30-minute values appear only in the text.
- Table 1 rows r9 and r12 are block headers ('ACTH stimulation test (0 minute)' / '(60 minute)') without values; cortisol at 60 minutes is judged against a stimulated cutoff of >18 µg/dl.
- Basal cortisol 8.8 µg/dl lies within the stated reference range (2.97-23.4) and is recorded as NORMAL, but the authors judged the cortisol response inadequate ('no significant rise', 'inadequate cortisol response confirmed PAI').
- Specimen for the laboratory analyses is not stated; circulating analytes recorded as 'blood' (PRA as 'plasma' since it is plasma renin activity).
- Units copied as written: the text uses 'ug/dl' for the ACTH-test cortisol values and 'µg/dl' elsewhere.
- Karyotype 46,XX (sec:9 ¶1) is not representable as a gene variant and is recorded here only.
- Anthropometrics: birth length 54 cm; at 6 months length 70 cm (95th percentile) and weight 6650 g (25th percentile); at 9 years height 134 cm (50-75th percentile) and weight 34.5 kg (75-90th percentile).
- Age at molecular diagnosis of LCAH is not stated precisely ('mid-infancy', sec:15 ¶2); PAI was diagnosed at six months.
- PAI is recorded as REVISED_FROM because 'PAI of unknown etiology' was superseded by the etiological diagnosis of LCAH; PAI remains the clinical manifestation and is also listed as a phenotype.
- CYP21A2 sequencing and gene-conversion/deletion analysis were negative (sec:4 ¶1), supporting the exclusion of 21-hydroxylase deficiency.
- Zygosity: the text for Patient 1 says 'two heterozygous pathogenic variants'; compound heterozygosity (trans configuration) is stated in Table 3 r19, sec:15 ¶1 and Figure 2, with maternal origin of p.Trp250Ter and paternal origin of p.Arg188Cys (sec:10 ¶2).
- Table 3 row r19 corresponds to this patient ('Present case'). The paper assigns no family identifier.
- Hydrocortisone dose (∼10 mg/m2/day) and fludrocortisone dose (0.05-0.1 mg/day) are given for both siblings together in sec:11 ¶1.