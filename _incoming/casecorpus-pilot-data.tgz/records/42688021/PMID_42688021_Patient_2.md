# PMID_42688021_Patient_2
**Source:** PMID 42688021 · Frontiers in endocrinology 2026 · DOI 10.3389/fendo.2026.1912249 · licence: None · tier: epmc
**Individual:** Patient 2 · sex MALE · onset P3M (three months (referred to a urologist for undescended testes, scrotal hypoplasia and hypospadias)) · presentation P1Y6M (1.5 years (hospitalized with electrolyte imbalance)) · last follow-up P5Y6M (5.5 years of age) · ALIVE
**Evidence verification:** 32/35 quotes found in their anchored unit, 35/35 anywhere in the document; narrative source: extractor

## Patient description (verbatim from the source, by anchor)

> **[abstract]** Background: Lipoid congenital adrenal hyperplasia (LCAH) is an uncommon but life-threatening autosomal recessive disorder. It is caused by a mutation in the steroidogenic acute regulatory protein (StAR), encoded by the STAR gene.
Methods: Clinical manifestations of two siblings with primary adrenal insufficiency (PAI) were described. A female infant was admitted to the hospital at six months of age for vomiting and failure to thrive. The diagnosis of PAI of unknown etiology was established. The girl’s younger brother was diagnosed with PAI at the age of 1.5 years during a febrile illness. His external genitalia showed undescended testes, scrotal hypoplasia, and hypospadia. Their family history was normal, and both parents were healthy. Clinical exome sequencing was used to identify mutations in candidate genes.
Results: Two heterozygous STAR mutations, p.Trp250Ter and p.Arg188Cys, were identified in both children. The mother was heterozygous for the p.Trp250Ter mutation, and the father was heterozygous for the p.Arg188Cys mutation.
Conclusion: Glucocorticoid, mineralocorticoid, and sex hormone therapy should be individualized according to the clinical presentation and laboratory findings. Because genotype and phenotype do not correlate consistently in LCAH, therapy and follow-up must be individualized.
>
> **[sec:3 ¶1]** Both patients, a sister and a brother, underwent clinical examination with assessment of growth and sexual development. Clinical data included birth measurements and birth history; family history was obtained. Routine laboratory analyses included adrenocorticotropic hormone (ACTH), cortisol, 17-hydroxyprogesterone, plasma renin activity (PRA), androstenedione, and testosterone. Genetic testing was performed, and written informed consent was obtained from both parents.
>
> **[sec:4 ¶1]** Genomic DNA was extracted from peripheral blood using the DNA extraction kit (Qiagen, Hilden, Germany). Clinical exome sequencing was performed using the TruSight One panel (Illumina), which targets the coding exons and exon–intron boundaries of 4,813 clinically relevant genes selected based on their established associations with human genetic disorders, as curated from OMIM, ClinVar, HGMD, and current clinical literature. Sequencing reads were aligned to the human reference genome (hg19). Variant analysis was initially focused on the congenital adrenal hyperplasia (CAH) gene panel (HP:0008258, Human Phenotype Ontology), with particular emphasis on CYP21A2, the most common genetic cause of CAH. Because of the high sequence homology between CYP21A2 and its pseudogene CYP21A1P, gene conversions and large deletions were additionally assessed by gene-specific PCR amplification, as previously described (7–9). Since no causative variants were identified in CYP21A2, the remaining genes in the CAH panel, along with all other genes covered by the TruSight One panel, were systematically evaluated. Common variants (minor allele frequency >1%) reported in the gnomAD Genomes, gnomAD Exomes, and 1000 Genomes databases were excluded. All pathogenic, likely pathogenic, and variants of uncertain significance (VUS) relevant to the patient’s phenotype were systematically reviewed. Variant interpretation and prioritization were performed using VarSome Professional (Saphetor SA, Lausanne, Switzerland) (10), taking into account the inheritance pattern, gene–disease association, available literature, and in silico predictions within the ACMG/AMP variant interpretation framework. Familial segregation of the identified STAR variants was evaluated using clinical exome sequencing data from both parents.
>
> **[sec:10 ¶1]** The girl’s younger brother was born at 40 gestational weeks with a normal birth weight of 3920g and a birth length of 57cm, Apgar score 9. He was referred to a urologist for examination at the age of three months due to undescended testes, scrotal hypoplasia, and hypospadias. Ultrasound showed both testes were located in the inguinal canals, so he was followed up for the next period. At the age of 1.5 years, he was hospitalized due to an electrolyte imbalance (hyponatremia 125 mmol/l, hyperkalemia 6.1 mmol/l, hypoglycemia 2.7 mmol/l) during a febrile respiratory illness (Table 2). Laboratory analyses showed a low cortisol level of 5.2 µg/dl (normal 2.97-23.4 µg/dl), a normal 17-hydroxyprogesterone level of 0.6 ng/ml (normal range <2 ng/ml), a high PRA of 19 ng/ml/h (normal range 0.3-3.9), a low androstenedione of 0.11 ng/ml (normal range 0.15-3.1 ng/ml), and a low testosterone level of 0.06 ng/ml (normal range 1.75-7.81 ng/ml). Karyotype was normal male 46, XY, and adrenal ultrasound was described as normal. PAI was diagnosed, so hydrocortisone and fludrocortisone therapy was started. At the time of diagnosis, the boy was of normal height, 84 cm (75th percentile), and weight 10 kg (7th percentile). Clinical exome sequencing showed the same result as in the sister, compound heterozygosity for pathogenic variants in the STAR gene.
>
> **[sec:10 ¶2]** Neither parent showed any symptoms of LCAH. The mother was heterozygous for the p.Trp250Ter mutation, and the father was heterozygous for the p.Arg188Cys mutation (Figure 1).
>
> **[sec:10 ¶3]** Representative IGV screenshots of both variants in the affected siblings, together with their familial segregation, are shown in Figure 2.
>
> **[sec:11 ¶1]** The patients attended regular endocrinology follow-up visits every 6 months. Their growth was appropriate for age. They were treated with hydrocortisone (∼10 mg/m2/day) and fludrocortisone (0.05-0.1 mg/day), and their blood pressure, sodium, potassium, and PRA levels remained normal.
>
> **[sec:11 ¶2]** The boy underwent right orchiopexy at the age of four years, because he had migratory testicle. At 5.5 years of age, his height was 114 cm (50-75th percentile), and his weight was 17 kg (10th percentile). Physical examination showed that both testes were in the scrotum, with a volume of 2 mL each.
>
> **[sec:11 ¶3]** The girl was last seen at 9 years of age. Her height was 134 cm (50-75th percentile), and her weight was 34.5 kg (75-90th percentile). She had no clinical signs of puberty. During follow-up, patients did not develop adrenal crisis.
>
> **[sec:15 ¶1]** To our knowledge, this is the first report of siblings with LCAH in Serbia, carrying the same compound heterozygous STAR genotype: c.749G>A (p.Trp250Ter) and c.562C>T (p.Arg188Cys). The same compound variants were reported in a 46, XY male infant in Switzerland. He presented at age 3.5 months with generalized hyperpigmentation, cryptorchidism, micropenis, but no hypospadias (15).
>
> **[sec:15 ¶2]** In our two patients, LCAH was diagnosed in mid-infancy and early childhood. In the case of LCAH, even when StAR loses its function, a StAR-independent steroidogenesis continues in some organs, which explains why PAI manifests after a few months of life (4). It is shown that 14% of the cholesterol import is StAR-independent (24).
>
> **[sec:15 ¶4]** In the boy, the major clinical indicators suggesting PAI were significant electrolyte imbalance, low cortisol level, and high PRA during a febrile infection (Table 2). Because his older sister had genetically confirmed LCAH, basic laboratory analyses were sufficient to support the diagnosis of PAI. Impaired testicular androgen secretion in utero resulted in insufficient prenatal androgenization and affected genital development in the boy. In patients with LCAH, reduced prenatal androgen exposure may lead to complete female external genitalia in 46, XY boys or to milder forms of differences in sex development.
>
> **[sec:15 ¶5]** Patients with LCAH typically have low steroid hormone levels and female-appearing external genitalia in both XX and XY karyotypes. Genetic testing identified the same STAR gene variants as those found in his sister.
>
> **[tab:2 r1]** Analyses | Result | Normal range
>
> **[tab:2 r2]** Natrium (mmol/l) | 125 | 135-145
>
> **[tab:2 r3]** Potassium (mmol/l) | 6.1 | 3.5-5
>
> **[tab:2 r4]** Glycemia (mmol/l) | 2.7 | 3.6-6.1
>
> **[tab:2 r5]** Cortisol (µg/dl) | 5.2 | 2.97-23.4
>
> **[tab:2 r6]** PRA ng/ml/h | 19 | 0.3-3.9
>
> **[tab:2 r7]** Aldosterone (ng/dl) | 22.4 | 3-35
>
> **[tab:2 r8]** 17-hydroxyprogesterone (ng/ml) | 0.6 | <2
>
> **[tab:2 r9]** Androstenedione (ng/ml) | 0.11 | 0.15-3.1
>
> **[tab:2 r10]** Testosterone (ng/ml) | 0.06 | 1.75-7.81
>
> **[tab:3 r1]** Number | Gender | Age | Presentation | Externalgenitalia | Kariotype | Variants of STAR gene (ACMG/AMP class) | Reference
>
> **[tab:3 r20]** 19. | M | 1,5 years | PAI due to infection | CryptorchidismHypospadia | 46, XY | Compound heterozygosity:c.749G>A, p.Trp250Ter (P)andc.562C>T, p.Arg188Cys (P) | Present case
>

## Diagnoses

- ✓ **FINAL** Lipoid congenital adrenal hyperplasia (LCAH) → congenital lipoid adrenal hyperplasia due to STAR deficency MONDO:0008725 OMIM:201710 · tier MOLECULAR · route symptomatic  
  “Clinical exome sequencing showed the same result as in the sister, compound heterozygosity for pathogenic variants in the STAR gene.” [sec:10 ¶1]
- ✓ **REVISED_FROM** Primary adrenal insufficiency (PAI) → Primary adrenal insufficiency (PAI)   · tier BIOCHEMICAL · route symptomatic  
  “PAI was diagnosed, so hydrocortisone and fludrocortisone therapy was started.” [sec:10 ¶1]

## Genetic findings

- ~ **STAR** c.749G>A p.Trp250Ter · COMPOUND_HETEROZYGOUS · pathogenic · clinical exome sequencing (TruSight One panel, Illumina); parental segregation by clinical exome sequencing  
  “(D) Familial segregation of the c.749G>A (p.Trp250Ter) variant, demonstrating its presence in the affected siblings and their mother.” [fig:2]
- ~ **STAR** c.562C>T p.Arg188Cys · COMPOUND_HETEROZYGOUS · pathogenic · clinical exome sequencing (TruSight One panel, Illumina); parental segregation by clinical exome sequencing  
  “(C) Familial segregation of the c.562C>T (p.Arg188Cys) variant, demonstrating its presence in the affected siblings and their father.” [fig:2]

## Measurements

| ✓ | analyte | specimen | value | unit | ref | interp | timing | quote [anchor] |
|---|---|---|---|---|---|---|---|---|
| ✓ | sodium (reported as hyponatremia; Natrium in Table 2) → sodium | blood | 125 | mmol/l | 135-145 | LOW | at presentation | “At the age of 1.5 years, he was hospitalized due to an electrolyte imbalance (hyponatremia 125 mmol/l, hyperkalemia 6.1 ” [sec:10 ¶1] |
| ✓ | potassium (reported as hyperkalemia) → potassium | blood | 6.1 | mmol/l | 3.5-5 | HIGH | at presentation | “At the age of 1.5 years, he was hospitalized due to an electrolyte imbalance (hyponatremia 125 mmol/l, hyperkalemia 6.1 ” [sec:10 ¶1] |
| ✓ | glycemia (reported as hypoglycemia) → glucose | blood | 2.7 | mmol/l | 3.6-6.1 | LOW | at presentation | “At the age of 1.5 years, he was hospitalized due to an electrolyte imbalance (hyponatremia 125 mmol/l, hyperkalemia 6.1 ” [sec:10 ¶1] |
| ✓ | cortisol → cortisol | blood | 5.2 | µg/dl | 2.97-23.4 | LOW | at presentation | “Laboratory analyses showed a low cortisol level of 5.2 µg/dl (normal 2.97-23.4 µg/dl)” [sec:10 ¶1] |
| ✓ | 17-hydroxyprogesterone | blood | 0.6 | ng/ml | <2 | NORMAL | at presentation | “a normal 17-hydroxyprogesterone level of 0.6 ng/ml (normal range <2 ng/ml)” [sec:10 ¶1] |
| ✓ | PRA | plasma | 19 | ng/ml/h | 0.3-3.9 | HIGH | at presentation | “a high PRA of 19 ng/ml/h (normal range 0.3-3.9)” [sec:10 ¶1] |
| ~ | Aldosterone | blood | 22.4 | ng/dl | 3-35 | NORMAL | at presentation | “/ r7 / Aldosterone (ng/dl) / 22.4 / 3-35 /” [tab:2 r7c2] |
| ✓ | androstenedione | blood | 0.11 | ng/ml | 0.15-3.1 | LOW | at presentation | “a low androstenedione of 0.11 ng/ml (normal range 0.15-3.1 ng/ml)” [sec:10 ¶1] |
| ✓ | testosterone | blood | 0.06 | ng/ml | 1.75-7.81 | LOW | at presentation | “a low testosterone level of 0.06 ng/ml (normal range 1.75-7.81 ng/ml)” [sec:10 ¶1] |
| ✓ | sodium → sodium | blood | remained normal |  |  | NORMAL | follow-up | “They were treated with hydrocortisone (∼10 mg/m2/day) and fludrocortisone (0.05-0.1 mg/day), and their blood pressure, s” [sec:11 ¶1] |
| ✓ | potassium → potassium | blood | remained normal |  |  | NORMAL | follow-up | “They were treated with hydrocortisone (∼10 mg/m2/day) and fludrocortisone (0.05-0.1 mg/day), and their blood pressure, s” [sec:11 ¶1] |
| ✓ | PRA | plasma | remained normal |  |  | NORMAL | follow-up | “They were treated with hydrocortisone (∼10 mg/m2/day) and fludrocortisone (0.05-0.1 mg/day), and their blood pressure, s” [sec:11 ¶1] |

## Phenotypes

- ✓ Cryptorchidism → Cryptorchidism HP:0000028 (grounded)  
  “He was referred to a urologist for examination at the age of three months due to undescended testes, scrotal hypoplasia, and hypospadias.” [sec:10 ¶1]
- ✓ Scrotal hypoplasia → Small scrotum HP:0000046 (grounded)  
  “He was referred to a urologist for examination at the age of three months due to undescended testes, scrotal hypoplasia, and hypospadias.” [sec:10 ¶1]
- ✓ Hypospadias → Hypospadias HP:0000047 (grounded)  
  “He was referred to a urologist for examination at the age of three months due to undescended testes, scrotal hypoplasia, and hypospadias.” [sec:10 ¶1]
- ✓ Hyponatremia → Hyponatremia HP:0002902 (grounded)  
  “At the age of 1.5 years, he was hospitalized due to an electrolyte imbalance (hyponatremia 125 mmol/l, hyperkalemia 6.1 mmol/l, hypoglycemia 2.7 mmol/l) during a febrile respiratory illness (Table 2).” [sec:10 ¶1]
- ✓ Hyperkalemia → Hyperkalemia HP:0002153 (grounded)  
  “At the age of 1.5 years, he was hospitalized due to an electrolyte imbalance (hyponatremia 125 mmol/l, hyperkalemia 6.1 mmol/l, hypoglycemia 2.7 mmol/l) during a febrile respiratory illness (Table 2).” [sec:10 ¶1]
- ✓ Hypoglycemia → Hypoglycemia HP:0001943 (grounded)  
  “At the age of 1.5 years, he was hospitalized due to an electrolyte imbalance (hyponatremia 125 mmol/l, hyperkalemia 6.1 mmol/l, hypoglycemia 2.7 mmol/l) during a febrile respiratory illness (Table 2).” [sec:10 ¶1]
- ✓ Fever → Fever HP:0001945 (grounded)  
  “At the age of 1.5 years, he was hospitalized due to an electrolyte imbalance (hyponatremia 125 mmol/l, hyperkalemia 6.1 mmol/l, hypoglycemia 2.7 mmol/l) during a febrile respiratory illness (Table 2).” [sec:10 ¶1]
- ✓ Decreased circulating cortisol level → Decreased circulating cortisol level HP:0008163 (grounded)  
  “Laboratory analyses showed a low cortisol level of 5.2 µg/dl (normal 2.97-23.4 µg/dl)” [sec:10 ¶1]
- ✓ Increased plasma renin activity → Hyperactive renin-angiotensin system HP:0000841 (grounded)  
  “a high PRA of 19 ng/ml/h (normal range 0.3-3.9)” [sec:10 ¶1]
- ✓ Decreased circulating androstenedione level → –  (candidate)  
  “a low androstenedione of 0.11 ng/ml (normal range 0.15-3.1 ng/ml)” [sec:10 ¶1]
- ✓ Decreased circulating testosterone level → –  (candidate)  
  “a low testosterone level of 0.06 ng/ml (normal range 1.75-7.81 ng/ml)” [sec:10 ¶1]
- ✓ Primary adrenal insufficiency → Primary adrenal insufficiency HP:0008207 (grounded)  
  “PAI was diagnosed, so hydrocortisone and fludrocortisone therapy was started.” [sec:10 ¶1]
- ✓ NOT Abnormal adrenal gland morphology on ultrasound → –  (candidate)  
  “Karyotype was normal male 46, XY, and adrenal ultrasound was described as normal.” [sec:10 ¶1]
- ✓ Migratory (retractile) testicle → –  (candidate)  
  “The boy underwent right orchiopexy at the age of four years, because he had migratory testicle.” [sec:11 ¶2]
- ✓ NOT Growth delay → Growth delay HP:0001510 (grounded)  
  “The patients attended regular endocrinology follow-up visits every 6 months. Their growth was appropriate for age.” [sec:11 ¶1]
- ✓ NOT Adrenal crisis → –  (candidate)  
  “During follow-up, patients did not develop adrenal crisis.” [sec:11 ¶3]

## Treatments

- ✓ drug: hydrocortisone · response stable  
  “PAI was diagnosed, so hydrocortisone and fludrocortisone therapy was started.” [sec:10 ¶1]
- ✓ drug: fludrocortisone · response stable  
  “They were treated with hydrocortisone (∼10 mg/m2/day) and fludrocortisone (0.05-0.1 mg/day), and their blood pressure, sodium, potassium, and PRA levels remained normal.” [sec:11 ¶1]
- ✓ other: orchiopexy · response improved  
  “The boy underwent right orchiopexy at the age of four years, because he had migratory testicle.” [sec:11 ¶2]

## Outcome

Alive at last follow-up at 5.5 years of age on hydrocortisone and fludrocortisone; height 114 cm (50-75th percentile), weight 17 kg (10th percentile); both testes in the scrotum (2 mL each) after right orchiopexy at four years; no adrenal crisis during follow-up.

## Model summary (not source text)

Patient 2 is the younger brother of Patient 1, born at 40 weeks with birth weight 3920 g, length 57 cm and Apgar score 9. At three months he was referred to a urologist for undescended testes (both in the inguinal canals on ultrasound), scrotal hypoplasia and hypospadias. At 1.5 years he was hospitalized during a febrile respiratory illness with hyponatremia (125 mmol/l), hyperkalemia (6.1 mmol/l) and hypoglycemia (2.7 mmol/l); cortisol was 5.2 µg/dl (reported as low), 17-hydroxyprogesterone normal (0.6 ng/ml), PRA high (19 ng/ml/h), aldosterone 22.4 ng/dl, androstenedione low (0.11 ng/ml) and testosterone low (0.06 ng/ml); karyotype was 46,XY and adrenal ultrasound normal. Primary adrenal insufficiency was diagnosed and hydrocortisone and fludrocortisone were started. Clinical exome sequencing showed the same compound heterozygous pathogenic STAR variants as his sister, c.749G>A (p.Trp250Ter, maternal) and c.562C>T (p.Arg188Cys, paternal), confirming lipoid congenital adrenal hyperplasia. He underwent right orchiopexy at four years for a migratory testicle; at 5.5 years growth was appropriate, both testes were scrotal (2 mL each), electrolytes and PRA were normal on treatment and no adrenal crisis had occurred.

## Extractor notes

- Ancestry 'Serbian' is stated explicitly for the sister (sec:9 ¶1); the paper describes the siblings as the first LCAH cases in Serbia (sec:1 ¶2, sec:15 ¶1).
- Cortisol 5.2 µg/dl is called 'low' by the authors although it lies within the stated reference range (2.97-23.4 µg/dl); interpretation recorded as LOW per the authors, which the range-based check will flag.
- Age at onset recorded as three months (first documented findings: undescended testes, scrotal hypoplasia, hypospadias; these genital anomalies are congenital). Adrenal insufficiency presented at 1.5 years.
- Values in Table 2 (rows r2-r10) are identical to the text of sec:10 ¶1; text quotes were used as evidence except for aldosterone, which appears only in Table 2 (r7).
- Specimen for the laboratory analyses is not stated; circulating analytes recorded as 'blood' (PRA as 'plasma').
- Karyotype 46,XY (sec:10 ¶1) is not representable as a gene variant and is recorded here only.
- The specific variants (c.749G>A p.Trp250Ter; c.562C>T p.Arg188Cys), their ACMG class (P) and parental origin are given for this patient in Table 3 r20, Figure 2 legend and sec:10 ¶2; sec:10 ¶1 states only 'the same result as in the sister'.
- Age at molecular diagnosis of LCAH is stated only as 'early childhood' (sec:15 ¶2); PAI was diagnosed at 1.5 years.
- PAI is recorded as REVISED_FROM because it was superseded by the etiological diagnosis of LCAH; it is also listed as a phenotype.
- The authors attribute the genital anomalies to impaired testicular androgen secretion in utero (sec:15 ¶4); no formal DSD diagnosis is named for this patient.
- Anthropometrics: birth length 57 cm; at diagnosis height 84 cm (75th percentile) and weight 10 kg (7th percentile); at 5.5 years height 114 cm (50-75th percentile), weight 17 kg (10th percentile), testicular volume 2 mL each.
- Table 3 row r20 corresponds to this patient ('Present case'). The paper assigns no family identifier.
- Hydrocortisone dose (∼10 mg/m2/day) and fludrocortisone dose (0.05-0.1 mg/day) are given for both siblings together in sec:11 ¶1.