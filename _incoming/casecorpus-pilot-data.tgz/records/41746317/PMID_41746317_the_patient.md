# PMID_41746317_the_patient
**Source:** PMID 41746317 · Pediatric nephrology (Berlin, Germany) 2026 · DOI 10.1007/s00467-026-07186-w · licence: None · tier: epmc
**Individual:** the patient · sex FEMALE · onset ? (3-month history before presentation at age 10 years) · presentation P10Y (10-year-old) · last follow-up ? (1 year post therapy (presented at 10 years)) · ALIVE
**Evidence verification:** 69/227 quotes found in their anchored unit, 227/227 anywhere in the document; narrative source: manifest

## Patient description (verbatim from the source, by anchor)

> **[abstract]** Background: Wilson's disease (WD) is a rare copper (Cu) metabolism disorder with toxic organ accumulation. Diagnosis challenges persist in children with atypical multisystem presentations, including uncommon kidney involvement, that may mimic autoimmune and systemic diseases.
Clinical Presentation: A 10-year-old girl presented with recurrent jaundice, abdominal pain, weight loss, poor school performance, and polyuria. She had cachexia, hepatosplenomegaly, kinetic hand tremors, non-immune hemolytic anemia, and mild glomerular and tubular dysfunction. Urosepsis triggered decompensation with worsening hepatic function, acute kidney injury (AKI) with Fanconi-like tubulopathy, coagulopathy, low complements, + ve autoantibodies, and elevated IgG. Despite autoimmune and malignancy mimics, Cu studies confirmed WD; D-penicillamine and zinc achieved rapid hepatorenal and hemolysis recovery. Fibrosis regressed at 1 year despite late ocular affection.
Conclusion: This case underscores diagnostic challenges of pediatric WD with multisystem involvement mimicking autoimmune and malignant disorders, emphasizing early Cu studies in multisystem jaundice. Timely chelation therapy achieved rapid improvement.
>
> **[sec:2 ¶1]** We report a 10-year-old girl, born to consanguineous parents presenting with a 3-month history of recurrent anicteric jaundice, abdominal pain, weight loss, poor academic performance, and polyuria with no changes in urine or stool color. Examination showed cachexia, normal blood pressure (50th percentile), mild hepatosplenomegaly, audible cardiac hemic murmur, kinetic hand tremors, with normal ocular examination.
>
> **[sec:2 ¶2]** Laboratory investigations (Table 1) initially showed impaired kidney function, hypokalemia, elevated transtubular potassium gradient (TTKG), albuminuria, and normal anion gap metabolic acidosis, mild aminotransaminase elevation, hyperbilirubinemia, thrombocytopenia, non-immune hemolysis, high IgG, + ve ASMA, low C3 and C4. Imaging showed mild hepatosplenomegaly and lymph node enlargement near the liver's portal vein (porta hepatis lymphadenopathy) with normal kidneys. At this stage, the patient was clinically stable. Table 1Laboratory data at initial presentation, diagnosis and follow upVariable dataInitial presentation(Weight = 26 kg, Height = 128 cm)At time of decompaction(Weight = 25 kg, Height = 128 cm)Follow-Up after 3 months of therapy(Weight = 30 kg, Height = 129 cm)Reference rangeLiver function tests ALT (U/L)489287–45 AST (U/L)112100338–40 Total bilirubin (mg/dL)6.430.50.2–1.2 Direct bilirubin (mg/dL)3.41.10.10–0.3 Albumin (g/dL)3.02.55.73.5–5.2 Total protein (g/dL)6.14.47.96–8 PT (sec)2920.61311–15 PTT (sec)54332425–35 INR2.21.591.00.8–1.2 Alkaline phosphatase (U/L)791317040–150 Gamma GT (U/L)961032010–50Serum electrolytes, kidney function tests Serum sodium (mmol/L)135136135135–145 Serum potassium (mmol/L)3.12.63.83.5–5.0 Serum magnesium (mg/dL)1.92.02.21.7–2.3 Serum phosphorus (mg/dL)2.62.05.32.5–4.5 Serum uric acid (mg/dL)1.51.042–6 Serum creatinine (mg/dL)1.712.670.540.5–1.0 eGFR by Schwarz formula312099 > 90 (mL/min/1.73 m2)Blood urea (mg/dL)3555810–40 Serum pH7.307.237.387.35–7.45 Serum HCO3 (mEq/L)18122421–29 24 h urinary protein (mg/day)20031835 < 150 Albumin creatinine ratio (mg/g)1502802030–300 24 urinary volumes (mL/day)250028001200800–2000 Urine output (mL/kg/hour)44.61.60.5–2 mL/kg/hr Urine specific gravity1015101010251.005–1.030 Urine PH5.96.55.04.5–8.0 Urine glucoseTrace + 1NilNil TTKG10–-6.56–10Viral markers CMV IgG (AU/mL)NegativeNegativeNegativeNegative EBV IgGNegativeNegativeNegativeNegativeHematological markers Total leukocyte count (× 103/µL)4.12.89.14–11 × 103 (/µL) Hemoglobin (g/dL)8.15.310.512.1–15.1 g/dL Mean corpuscular volume (fL)951208980–100 fL Reticulocyte count %2.61102.10.5–2.5% Platelet (× 103/µL)6040162150,000–450,000 TIBC (µg/dL)142120333250–450 Transferrin saturation (%)92952015–50Immunological markers ANANegativeNegativeNegativeNegative Anti DNA AbNegativeNegativeNegativeNegative C3 (mg/dL)7844.212090–180 C4 (mg/dL) < 8 < 83010–40 ASMAPositivePositiveNegativeNegative Serum IgG (mg/dL)35004100750700–1600 Serum IgM (mg/dL)1311507040–230 Coombs testNegativeNegativeNegativeNegativeOthers Random blood sugar (mg/dL)10080110Up to 180 CRP (mg/L) < 5320 < 5 < 5 LDH (U/L)300681130140–280Cu MetabolismAt the time of diagnosis and confirmation* across laboratoriesBiochemical response 3 weeks post chelationBiochemical response one year post chelationReference range Serum Ceruloplasmin (mg/dL)8.6–8.8*29.93120–40 24 h Urinary Cu (µg)1330–1337*15398 < 100
>
> **[sec:2 ¶3]** Two days later she developed fever, worsening pallor, jaundice, tachycardia, hypotension, polyuria, ascites, and loin tenderness. Repeat investigations showed declining eGFR, hypokalemia, hypophosphatemia, hypouricemia, normal anion gap metabolic acidosis, low urine specific gravity, albuminuria, and glucosuria with normoglycemia, hyperbilirubinemia, transaminase elevation, pancytopenia, non-immune hemolysis, and coagulopathy. Abdominal imaging revealed hepatosplenomegaly, ascites, thickened peritoneal reflections, mesenteric vascular congestion, persistent porta hepatis lymphadenopathy, bilateral hyperechogenic kidneys and grade 1 nephropathy, no nephrocalcinosis or nephrolithiasis. Fibroscan confirmed advanced hepatic fibrosis.
>
> **[sec:2 ¶4]** Acute liver failure (ALF) was considered, with differentials including malignancy, AIH, systemic lupus erythematosus (SLE), immune overlap hepatitis, and WD. She received vasopressors, blood transfusions, fluids, and empirical broad-spectrum antibiotics, followed by dramatic improvement within 4 days, though hemolysis persisted. In the context of ongoing hemolysis and multisystem involvement, she was empirically given a 3-day course of pulse steroid for suspected catastrophic SLE with overlapping lupus hepatitis, later stopped after urine culture confirmed Gram -ve urosepsis responsive to cephalosporins, implicating urosepsis as the cause.
>
> **[sec:2 ¶5]** Improvement in clinical and laboratory findings made malignancy, AIH, and SLE less likely despite + ve ASMA. Results of 24-h urinary Cu excretion and serum ceruloplasmin measurement confirmed WD, repeated in different laboratories for confirmation [5]. Screening of siblings biochemically was negative. Early chelation with D-penicillamine and zinc sulfate, oral potassium, and culture-guided antibiotics led to rapid recovery within 3 weeks, though ASMA + ve, reflecting reactive autoimmunity.
>
> **[sec:2 ¶6]** At 3-month follow-up, patient showed sustained improvement, with normalization of all her laboratory parameters and -ve ASMA. At that time, liver biopsy revealed chronic hepatitis with significant inflammation and fibrosis, but no Cu deposition, prompting D-penicillamine dose reduction.
>
> **[sec:2 ¶7]** At 1 year post therapy, new dysarthria and Kayser–Fleischer (K-F) rings appeared on examination, yet fibrosis regressed on Fibroscan, with no additional organ involvement, requiring no therapy changes.
>
> **[sec:4 ¶1]** This was a complex presentation, with a self-limited hepatitis-like illness, followed by ALF, precipitated by urosepsis, unmasking latent Cu toxicity and multiorgan dysfunction. Diagnosis was challenging due to overlap with AIH, SLE, and malignancy. Malignancy was considered due to organomegaly, porta hepatis lymphadenopathy, pancytopenia, persistent fever, and high IgG. AIH was suspected based on + ve ASMA, elevated transaminases, IgG; SLE owing to pancytopenia, low C3 and C4, high IgG, and multisystem involvement.
>
> **[sec:4 ¶2]** Malignancy was excluded by resolution of cytopenia after infection control. SLE was excluded using 2019 EULAR/ACR criteria [6], given -ve anti-dsDNA and ANA antibodies, absence of mucocutaneous features, transient low C3 and C4, and lack of persistent multisystem affection. AIH was unlikely due to normalized IgG, -ve viral serology, and clinical improvement, despite + ve ASMA.
>
> **[sec:4 ¶3]** Evaluation showed these findings were secondary. Transient hypocomplementemia reflected impaired hepatic synthesis during ALF, as complement is hepatic protein derived [7]. Fever, elevated IgG, porta hepatis lymphadenopathy, and pancytopenia were due to urosepsis rather than autoimmunity. Autoantibodies may occur in WD, chronic liver disease, or healthy children, explaining the + ve ASMA [2].
>
> **[sec:5 ¶1]** WD manifests differently by age; young children present often with hepatic and hematological features, whereas older children and adults show neuropsychiatric symptoms [1, 8]. Our patient exhibited severe hepatic WD profile with modest aminotransferase elevation, marked hyperbilirubinemia, and low alkaline phosphatase [1, 8].
>
> **[sec:5 ¶2]** Diagnosis was established by Leipzig score > 4, based on neuropsychiatric signs, non-immune hemolytic anemia, elevated 24-h urinary Cu, and low serum ceruloplasmin, necessitating prompt therapy initiation [5, 8].
>
> **[sec:5 ¶3]** Kidney involvement: is less common than hepatic or neurologic manifestations, yet Cu exerts direct toxic damage on renal tubules, renal tubular acidosis, ranging from mild electrolyte and acid–base disturbances to Fanconi syndrome. These defects predispose to nephrolithiasis, nephrocalcinosis, bone disease, and AKI, which increases mortality. AKI arises from hypoperfusion, hemolysis-related tubular casts, or D-penicillamine-induced glomerulopathy [4]. Our patient had combined glomerular and proximal tubular dysfunction with AKI, hypokalemia with high TTKG, glucosuria with normoglycemia, hypouricemia, non–anion gap acidosis, albuminuria, and polyuria. During urosepsis, findings progressed to Fanconi-like syndrome, worsening eGFR and hypokalemia, hypophosphatemia, profound hypouricemia, non-anion gap metabolic acidosis, high urine pH, polyuria, albuminuria and glucosuria despite normoglycemia. After 3 months, laboratory data normalized, demonstrating reversibility with timely treatment intervention. Due to limited resources, specific markers such as tubular phosphate reabsorption, fractional excretion of uric acid and urinary beta 2 microglobulin were not available.
>
> **[sec:5 ¶4]** Ocular findings: Cu deposits in Descemet’s membrane causing K-F rings are a hallmark of WD, occurring in 95% with neurological affections and 50% without. In children with hepatic disease, K-F rings are absent or difficult to detect [9]. This explains our observation initially, despite subtle neuropsychiatric features, while hepatic involvement predominated. Notably, K-F rings appeared 1 year post therapy, despite improved hepatic Cu and fibrosis. Therefore, absence of K–F rings does not exclude pediatric WD [5]. Ocular manifestations may emerge later in the disease course, and warrant ophthalmologic monitoring.
>
> **[sec:6 ¶1]** Treatment of WD in children targets Cu reduction and organ protection, requiring early pharmacologic therapy with chelators such as D-penicillamine and zinc to inhibit intestinal absorption [8]. In our patient, urosepsis was managed with cefotaxime (75 mg/kg/8 h) for 10 days, guided by culture sensitivity. Therapy included Cu restriction, D-penicillamine (20 mg/kg/day, reduced to 15 mg/kg/day after 3 months), zinc sulfate (1 mg/kg/day) [8], oral potassium (1 mmol/kg/day) for hypokalemia. This led to rapid clinical improvement. Monitoring comprised; quarterly: 24-h urinary Cu, serum ceruloplasmin, liver and kidney function, acid–base and electrolyte status, and hematological parameters; every 6 months: slit-lamp examination and Fibroscan; annually: liver biopsy to assess fibrosis.
>
> **[sec:6 ¶2]** New dysarthria and K-F rings appeared at 1 year. We recommend ongoing six-monthly biochemical and hematological assessment, slit-lamp examination, and Fibroscan, with annual liver biopsy. Genetic testing and counseling for relatives is needed.
>
> **[sec:6 ¶3]** Family screening biochemically by serum ceruloplasmin and urinary Cu excluded WD in siblings. Though sequencing of the ATP7B gene was recommended for the patient and her siblings; we could not perform it due to financial issues.
>
> **[tab:1 r1]** Variable data | Initial presentation(Weight = 26 kg, Height = 128 cm) | At time of decompaction(Weight = 25 kg, Height = 128 cm) | Follow-Up after 3 months of therapy(Weight = 30 kg, Height = 129 cm) | Reference range
>
> **[tab:1 r2]** Liver function tests |  |  |  | 
>
> **[tab:1 r3]** ALT (U/L) | 48 | 9 | 28 | 7–45
>
> **[tab:1 r4]** AST (U/L) | 112 | 100 | 33 | 8–40
>
> **[tab:1 r5]** Total bilirubin (mg/dL) | 6.4 | 3 | 0.5 | 0.2–1.2
>
> **[tab:1 r6]** Direct bilirubin (mg/dL) | 3.4 | 1.1 | 0.1 | 0–0.3
>
> **[tab:1 r7]** Albumin (g/dL) | 3.0 | 2.5 | 5.7 | 3.5–5.2
>
> **[tab:1 r8]** Total protein (g/dL) | 6.1 | 4.4 | 7.9 | 6–8
>
> **[tab:1 r9]** PT (sec) | 29 | 20.6 | 13 | 11–15
>
> **[tab:1 r10]** PTT (sec) | 54 | 33 | 24 | 25–35
>
> **[tab:1 r11]** INR | 2.2 | 1.59 | 1.0 | 0.8–1.2
>
> **[tab:1 r12]** Alkaline phosphatase (U/L) | 79 | 131 | 70 | 40–150
>
> **[tab:1 r13]** Gamma GT (U/L) | 96 | 103 | 20 | 10–50
>
> **[tab:1 r14]** Serum electrolytes, kidney function tests |  |  |  | 
>
> **[tab:1 r15]** Serum sodium (mmol/L) | 135 | 136 | 135 | 135–145
>
> **[tab:1 r16]** Serum potassium (mmol/L) | 3.1 | 2.6 | 3.8 | 3.5–5.0
>
> **[tab:1 r17]** Serum magnesium (mg/dL) | 1.9 | 2.0 | 2.2 | 1.7–2.3
>
> **[tab:1 r18]** Serum phosphorus (mg/dL) | 2.6 | 2.0 | 5.3 | 2.5–4.5
>
> **[tab:1 r19]** Serum uric acid (mg/dL) | 1.5 | 1.0 | 4 | 2–6
>
> **[tab:1 r20]** Serum creatinine (mg/dL) | 1.71 | 2.67 | 0.54 | 0.5–1.0
>
> **[tab:1 r21]** eGFR by Schwarz formula | 31 | 20 | 99 | > 90 (mL/min/1.73 m2)
>
> **[tab:1 r22]** Blood urea (mg/dL) | 35 | 55 | 8 | 10–40
>
> **[tab:1 r23]** Serum pH | 7.30 | 7.23 | 7.38 | 7.35–7.45
>
> **[tab:1 r24]** Serum HCO3 (mEq/L) | 18 | 12 | 24 | 21–29
>
> **[tab:1 r25]** 24 h urinary protein (mg/day) | 200 | 318 | 35 | < 150
>
> **[tab:1 r26]** Albumin creatinine ratio (mg/g) | 150 | 280 | 20 | 30–300
>
> **[tab:1 r27]** 24 urinary volumes (mL/day) | 2500 | 2800 | 1200 | 800–2000
>
> **[tab:1 r28]** Urine output (mL/kg/hour) | 4 | 4.6 | 1.6 | 0.5–2 mL/kg/hr
>
> **[tab:1 r29]** Urine specific gravity | 1015 | 1010 | 1025 | 1.005–1.030
>
> **[tab:1 r30]** Urine PH | 5.9 | 6.5 | 5.0 | 4.5–8.0
>
> **[tab:1 r31]** Urine glucose | Trace | + 1 | Nil | Nil
>
> **[tab:1 r32]** TTKG | 10 | –- | 6.5 | 6–10
>
> **[tab:1 r33]** Viral markers |  |  |  | 
>
> **[tab:1 r34]** CMV IgG (AU/mL) | Negative | Negative | Negative | Negative
>
> **[tab:1 r35]** EBV IgG | Negative | Negative | Negative | Negative
>
> **[tab:1 r36]** Hematological markers |  |  |  | 
>
> **[tab:1 r37]** Total leukocyte count (× 103/µL) | 4.1 | 2.8 | 9.1 | 4–11 × 103 (/µL)
>
> **[tab:1 r38]** Hemoglobin (g/dL) | 8.1 | 5.3 | 10.5 | 12.1–15.1 g/dL
>
> **[tab:1 r39]** Mean corpuscular volume (fL) | 95 | 120 | 89 | 80–100 fL
>
> **[tab:1 r40]** Reticulocyte count % | 2.61 | 10 | 2.1 | 0.5–2.5%
>
> **[tab:1 r41]** Platelet (× 103/µL) | 60 | 40 | 162 | 150,000–450,000
>
> **[tab:1 r42]** TIBC (µg/dL) | 142 | 120 | 333 | 250–450
>
> **[tab:1 r43]** Transferrin saturation (%) | 92 | 95 | 20 | 15–50
>
> **[tab:1 r44]** Immunological markers |  |  |  | 
>
> **[tab:1 r45]** ANA | Negative | Negative | Negative | Negative
>
> **[tab:1 r46]** Anti DNA Ab | Negative | Negative | Negative | Negative
>
> **[tab:1 r47]** C3 (mg/dL) | 78 | 44.2 | 120 | 90–180
>
> **[tab:1 r48]** C4 (mg/dL) | < 8 | < 8 | 30 | 10–40
>
> **[tab:1 r49]** ASMA | Positive | Positive | Negative | Negative
>
> **[tab:1 r50]** Serum IgG (mg/dL) | 3500 | 4100 | 750 | 700–1600
>
> **[tab:1 r51]** Serum IgM (mg/dL) | 131 | 150 | 70 | 40–230
>
> **[tab:1 r52]** Coombs test | Negative | Negative | Negative | Negative
>
> **[tab:1 r53]** Others |  |  |  | 
>
> **[tab:1 r54]** Random blood sugar (mg/dL) | 100 | 80 | 110 | Up to 180
>
> **[tab:1 r55]** CRP (mg/L) | < 5 | 320 | < 5 | < 5
>
> **[tab:1 r56]** LDH (U/L) | 300 | 681 | 130 | 140–280
>
> **[tab:1 r57]** Cu Metabolism | At the time of diagnosis and confirmation* across laboratories | Biochemical response 3 weeks post chelation | Biochemical response one year post chelation | Reference range
>
> **[tab:1 r58]** Serum Ceruloplasmin (mg/dL) | 8.6–8.8* | 29.9 | 31 | 20–40
>
> **[tab:1 r59]** 24 h Urinary Cu (µg) | 1330–1337* | 153 | 98 | < 100
>

## Diagnoses

- ✓ **FINAL** Wilson's disease → Wilson disease MONDO:0010200 OMIM:277900 · tier BIOCHEMICAL · route symptomatic  
  “Results of 24-h urinary Cu excretion and serum ceruloplasmin measurement confirmed WD, repeated in different laboratories for confirmation [5].” [sec:2 ¶5]
- ✓ **EXCLUDED** systemic lupus erythematosus (SLE) → systemic lupus erythematosus   · tier CLINICAL · route –  
  “SLE was excluded using 2019 EULAR/ACR criteria [6], given -ve anti-dsDNA and ANA antibodies, absence of mucocutaneous features, transient low C3 and C4, and lack of persistent multisystem affection.” [sec:4 ¶2]
- ✓ **REVISED_FROM** catastrophic SLE with overlapping lupus hepatitis → systemic lupus erythematosus with lupus hepatitis   · tier PROVISIONAL · route –  
  “she was empirically given a 3-day course of pulse steroid for suspected catastrophic SLE with overlapping lupus hepatitis, later stopped after urine culture confirmed Gram -ve urosepsis responsive to cephalosporins” [sec:2 ¶4]
- ✓ **EXCLUDED** malignancy → cancer MONDO:0004992  · tier CLINICAL · route –  
  “Malignancy was excluded by resolution of cytopenia after infection control.” [sec:4 ¶2]
- ✓ **DIFFERENTIAL** autoimmune hepatitis (AIH) → autoimmune hepatitis   · tier CLINICAL · route –  
  “AIH was unlikely due to normalized IgG, -ve viral serology, and clinical improvement, despite + ve ASMA.” [sec:4 ¶2]
- ✓ **DIFFERENTIAL** immune overlap hepatitis → immune overlap hepatitis   · tier CLINICAL · route –  
  “Acute liver failure (ALF) was considered, with differentials including malignancy, AIH, systemic lupus erythematosus (SLE), immune overlap hepatitis, and WD.” [sec:2 ¶4]

## Genetic findings


## Measurements

| ✓ | analyte | specimen | value | unit | ref | interp | timing | quote [anchor] |
|---|---|---|---|---|---|---|---|---|
| ~ | Weight → body weight | other | 26 | kg |  | UNKNOWN | initial presentation | “/ r1 / Variable data / Initial presentation(Weight = 26 kg, Height = 128 cm) / At time of decompaction(Weight = 25 kg, H” [tab:1 r1c2] |
| ~ | Height → body height | other | 128 | cm |  | UNKNOWN | initial presentation | “/ r1 / Variable data / Initial presentation(Weight = 26 kg, Height = 128 cm) / At time of decompaction(Weight = 25 kg, H” [tab:1 r1c2] |
| ~ | Weight → body weight | other | 25 | kg |  | UNKNOWN | at time of decompensation (2 days after presentation, during urosepsis) | “/ r1 / Variable data / Initial presentation(Weight = 26 kg, Height = 128 cm) / At time of decompaction(Weight = 25 kg, H” [tab:1 r1c3] |
| ~ | Height → body height | other | 128 | cm |  | UNKNOWN | at time of decompensation (2 days after presentation, during urosepsis) | “/ r1 / Variable data / Initial presentation(Weight = 26 kg, Height = 128 cm) / At time of decompaction(Weight = 25 kg, H” [tab:1 r1c3] |
| ~ | Weight → body weight | other | 30 | kg |  | UNKNOWN | follow-up after 3 months of therapy | “/ r1 / Variable data / Initial presentation(Weight = 26 kg, Height = 128 cm) / At time of decompaction(Weight = 25 kg, H” [tab:1 r1c4] |
| ~ | Height → body height | other | 129 | cm |  | UNKNOWN | follow-up after 3 months of therapy | “/ r1 / Variable data / Initial presentation(Weight = 26 kg, Height = 128 cm) / At time of decompaction(Weight = 25 kg, H” [tab:1 r1c4] |
| ~ | ALT (U/L) → alanine aminotransferase | serum | 48 | U/L | 7–45 | HIGH | initial presentation | “/ r3 / ALT (U/L) / 48 / 9 / 28 / 7–45 /” [tab:1 r3c2] |
| ~ | ALT (U/L) → alanine aminotransferase | serum | 9 | U/L | 7–45 | NORMAL | at time of decompensation (2 days after presentation, during urosepsis) | “/ r3 / ALT (U/L) / 48 / 9 / 28 / 7–45 /” [tab:1 r3c3] |
| ~ | ALT (U/L) → alanine aminotransferase | serum | 28 | U/L | 7–45 | NORMAL | follow-up after 3 months of therapy | “/ r3 / ALT (U/L) / 48 / 9 / 28 / 7–45 /” [tab:1 r3c4] |
| ~ | AST (U/L) → aspartate aminotransferase | serum | 112 | U/L | 8–40 | HIGH | initial presentation | “/ r4 / AST (U/L) / 112 / 100 / 33 / 8–40 /” [tab:1 r4c2] |
| ~ | AST (U/L) → aspartate aminotransferase | serum | 100 | U/L | 8–40 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r4 / AST (U/L) / 112 / 100 / 33 / 8–40 /” [tab:1 r4c3] |
| ~ | AST (U/L) → aspartate aminotransferase | serum | 33 | U/L | 8–40 | NORMAL | follow-up after 3 months of therapy | “/ r4 / AST (U/L) / 112 / 100 / 33 / 8–40 /” [tab:1 r4c4] |
| ~ | Total bilirubin (mg/dL) → bilirubin | serum | 6.4 | mg/dL | 0.2–1.2 | HIGH | initial presentation | “/ r5 / Total bilirubin (mg/dL) / 6.4 / 3 / 0.5 / 0.2–1.2 /” [tab:1 r5c2] |
| ~ | Total bilirubin (mg/dL) → bilirubin | serum | 3 | mg/dL | 0.2–1.2 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r5 / Total bilirubin (mg/dL) / 6.4 / 3 / 0.5 / 0.2–1.2 /” [tab:1 r5c3] |
| ~ | Total bilirubin (mg/dL) → bilirubin | serum | 0.5 | mg/dL | 0.2–1.2 | NORMAL | follow-up after 3 months of therapy | “/ r5 / Total bilirubin (mg/dL) / 6.4 / 3 / 0.5 / 0.2–1.2 /” [tab:1 r5c4] |
| ~ | Direct bilirubin (mg/dL) → conjugated bilirubin | serum | 3.4 | mg/dL | 0–0.3 | HIGH | initial presentation | “/ r6 / Direct bilirubin (mg/dL) / 3.4 / 1.1 / 0.1 / 0–0.3 /” [tab:1 r6c2] |
| ~ | Direct bilirubin (mg/dL) → conjugated bilirubin | serum | 1.1 | mg/dL | 0–0.3 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r6 / Direct bilirubin (mg/dL) / 3.4 / 1.1 / 0.1 / 0–0.3 /” [tab:1 r6c3] |
| ~ | Direct bilirubin (mg/dL) → conjugated bilirubin | serum | 0.1 | mg/dL | 0–0.3 | NORMAL | follow-up after 3 months of therapy | “/ r6 / Direct bilirubin (mg/dL) / 3.4 / 1.1 / 0.1 / 0–0.3 /” [tab:1 r6c4] |
| ~ | Albumin (g/dL) → albumin | serum | 3.0 | g/dL | 3.5–5.2 | LOW | initial presentation | “/ r7 / Albumin (g/dL) / 3.0 / 2.5 / 5.7 / 3.5–5.2 /” [tab:1 r7c2] |
| ~ | Albumin (g/dL) → albumin | serum | 2.5 | g/dL | 3.5–5.2 | LOW | at time of decompensation (2 days after presentation, during urosepsis) | “/ r7 / Albumin (g/dL) / 3.0 / 2.5 / 5.7 / 3.5–5.2 /” [tab:1 r7c3] |
| ~ | Albumin (g/dL) → albumin | serum | 5.7 | g/dL | 3.5–5.2 | HIGH | follow-up after 3 months of therapy | “/ r7 / Albumin (g/dL) / 3.0 / 2.5 / 5.7 / 3.5–5.2 /” [tab:1 r7c4] |
| ~ | Total protein (g/dL) → total protein | serum | 6.1 | g/dL | 6–8 | NORMAL | initial presentation | “/ r8 / Total protein (g/dL) / 6.1 / 4.4 / 7.9 / 6–8 /” [tab:1 r8c2] |
| ~ | Total protein (g/dL) → total protein | serum | 4.4 | g/dL | 6–8 | LOW | at time of decompensation (2 days after presentation, during urosepsis) | “/ r8 / Total protein (g/dL) / 6.1 / 4.4 / 7.9 / 6–8 /” [tab:1 r8c3] |
| ~ | Total protein (g/dL) → total protein | serum | 7.9 | g/dL | 6–8 | NORMAL | follow-up after 3 months of therapy | “/ r8 / Total protein (g/dL) / 6.1 / 4.4 / 7.9 / 6–8 /” [tab:1 r8c4] |
| ~ | PT (sec) → prothrombin time | blood | 29 | sec | 11–15 | HIGH | initial presentation | “/ r9 / PT (sec) / 29 / 20.6 / 13 / 11–15 /” [tab:1 r9c2] |
| ~ | PT (sec) → prothrombin time | blood | 20.6 | sec | 11–15 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r9 / PT (sec) / 29 / 20.6 / 13 / 11–15 /” [tab:1 r9c3] |
| ~ | PT (sec) → prothrombin time | blood | 13 | sec | 11–15 | NORMAL | follow-up after 3 months of therapy | “/ r9 / PT (sec) / 29 / 20.6 / 13 / 11–15 /” [tab:1 r9c4] |
| ~ | PTT (sec) → partial thromboplastin time | blood | 54 | sec | 25–35 | HIGH | initial presentation | “/ r10 / PTT (sec) / 54 / 33 / 24 / 25–35 /” [tab:1 r10c2] |
| ~ | PTT (sec) → partial thromboplastin time | blood | 33 | sec | 25–35 | NORMAL | at time of decompensation (2 days after presentation, during urosepsis) | “/ r10 / PTT (sec) / 54 / 33 / 24 / 25–35 /” [tab:1 r10c3] |
| ~ | PTT (sec) → partial thromboplastin time | blood | 24 | sec | 25–35 | LOW | follow-up after 3 months of therapy | “/ r10 / PTT (sec) / 54 / 33 / 24 / 25–35 /” [tab:1 r10c4] |
| ~ | INR → international normalized ratio | blood | 2.2 | ratio | 0.8–1.2 | HIGH | initial presentation | “/ r11 / INR / 2.2 / 1.59 / 1.0 / 0.8–1.2 /” [tab:1 r11c2] |
| ~ | INR → international normalized ratio | blood | 1.59 | ratio | 0.8–1.2 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r11 / INR / 2.2 / 1.59 / 1.0 / 0.8–1.2 /” [tab:1 r11c3] |
| ~ | INR → international normalized ratio | blood | 1.0 | ratio | 0.8–1.2 | NORMAL | follow-up after 3 months of therapy | “/ r11 / INR / 2.2 / 1.59 / 1.0 / 0.8–1.2 /” [tab:1 r11c4] |
| ~ | Alkaline phosphatase (U/L) → alkaline phosphatase | serum | 79 | U/L | 40–150 | NORMAL | initial presentation | “/ r12 / Alkaline phosphatase (U/L) / 79 / 131 / 70 / 40–150 /” [tab:1 r12c2] |
| ~ | Alkaline phosphatase (U/L) → alkaline phosphatase | serum | 131 | U/L | 40–150 | NORMAL | at time of decompensation (2 days after presentation, during urosepsis) | “/ r12 / Alkaline phosphatase (U/L) / 79 / 131 / 70 / 40–150 /” [tab:1 r12c3] |
| ~ | Alkaline phosphatase (U/L) → alkaline phosphatase | serum | 70 | U/L | 40–150 | NORMAL | follow-up after 3 months of therapy | “/ r12 / Alkaline phosphatase (U/L) / 79 / 131 / 70 / 40–150 /” [tab:1 r12c4] |
| ~ | Gamma GT (U/L) → gamma-glutamyl transferase | serum | 96 | U/L | 10–50 | HIGH | initial presentation | “/ r13 / Gamma GT (U/L) / 96 / 103 / 20 / 10–50 /” [tab:1 r13c2] |
| ~ | Gamma GT (U/L) → gamma-glutamyl transferase | serum | 103 | U/L | 10–50 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r13 / Gamma GT (U/L) / 96 / 103 / 20 / 10–50 /” [tab:1 r13c3] |
| ~ | Gamma GT (U/L) → gamma-glutamyl transferase | serum | 20 | U/L | 10–50 | NORMAL | follow-up after 3 months of therapy | “/ r13 / Gamma GT (U/L) / 96 / 103 / 20 / 10–50 /” [tab:1 r13c4] |
| ~ | Serum sodium (mmol/L) → sodium | serum | 135 | mmol/L | 135–145 | NORMAL | initial presentation | “/ r15 / Serum sodium (mmol/L) / 135 / 136 / 135 / 135–145 /” [tab:1 r15c2] |
| ~ | Serum sodium (mmol/L) → sodium | serum | 136 | mmol/L | 135–145 | NORMAL | at time of decompensation (2 days after presentation, during urosepsis) | “/ r15 / Serum sodium (mmol/L) / 135 / 136 / 135 / 135–145 /” [tab:1 r15c3] |
| ~ | Serum sodium (mmol/L) → sodium | serum | 135 | mmol/L | 135–145 | NORMAL | follow-up after 3 months of therapy | “/ r15 / Serum sodium (mmol/L) / 135 / 136 / 135 / 135–145 /” [tab:1 r15c4] |
| ~ | Serum potassium (mmol/L) → potassium | serum | 3.1 | mmol/L | 3.5–5.0 | LOW | initial presentation | “/ r16 / Serum potassium (mmol/L) / 3.1 / 2.6 / 3.8 / 3.5–5.0 /” [tab:1 r16c2] |
| ~ | Serum potassium (mmol/L) → potassium | serum | 2.6 | mmol/L | 3.5–5.0 | LOW | at time of decompensation (2 days after presentation, during urosepsis) | “/ r16 / Serum potassium (mmol/L) / 3.1 / 2.6 / 3.8 / 3.5–5.0 /” [tab:1 r16c3] |
| ~ | Serum potassium (mmol/L) → potassium | serum | 3.8 | mmol/L | 3.5–5.0 | NORMAL | follow-up after 3 months of therapy | “/ r16 / Serum potassium (mmol/L) / 3.1 / 2.6 / 3.8 / 3.5–5.0 /” [tab:1 r16c4] |
| ~ | Serum magnesium (mg/dL) → magnesium | serum | 1.9 | mg/dL | 1.7–2.3 | NORMAL | initial presentation | “/ r17 / Serum magnesium (mg/dL) / 1.9 / 2.0 / 2.2 / 1.7–2.3 /” [tab:1 r17c2] |
| ~ | Serum magnesium (mg/dL) → magnesium | serum | 2.0 | mg/dL | 1.7–2.3 | NORMAL | at time of decompensation (2 days after presentation, during urosepsis) | “/ r17 / Serum magnesium (mg/dL) / 1.9 / 2.0 / 2.2 / 1.7–2.3 /” [tab:1 r17c3] |
| ~ | Serum magnesium (mg/dL) → magnesium | serum | 2.2 | mg/dL | 1.7–2.3 | NORMAL | follow-up after 3 months of therapy | “/ r17 / Serum magnesium (mg/dL) / 1.9 / 2.0 / 2.2 / 1.7–2.3 /” [tab:1 r17c4] |
| ~ | Serum phosphorus (mg/dL) → phosphate | serum | 2.6 | mg/dL | 2.5–4.5 | NORMAL | initial presentation | “/ r18 / Serum phosphorus (mg/dL) / 2.6 / 2.0 / 5.3 / 2.5–4.5 /” [tab:1 r18c2] |
| ~ | Serum phosphorus (mg/dL) → phosphate | serum | 2.0 | mg/dL | 2.5–4.5 | LOW | at time of decompensation (2 days after presentation, during urosepsis) | “/ r18 / Serum phosphorus (mg/dL) / 2.6 / 2.0 / 5.3 / 2.5–4.5 /” [tab:1 r18c3] |
| ~ | Serum phosphorus (mg/dL) → phosphate | serum | 5.3 | mg/dL | 2.5–4.5 | HIGH | follow-up after 3 months of therapy | “/ r18 / Serum phosphorus (mg/dL) / 2.6 / 2.0 / 5.3 / 2.5–4.5 /” [tab:1 r18c4] |
| ~ | Serum uric acid (mg/dL) → uric acid | serum | 1.5 | mg/dL | 2–6 | LOW | initial presentation | “/ r19 / Serum uric acid (mg/dL) / 1.5 / 1.0 / 4 / 2–6 /” [tab:1 r19c2] |
| ~ | Serum uric acid (mg/dL) → uric acid | serum | 1.0 | mg/dL | 2–6 | LOW | at time of decompensation (2 days after presentation, during urosepsis) | “/ r19 / Serum uric acid (mg/dL) / 1.5 / 1.0 / 4 / 2–6 /” [tab:1 r19c3] |
| ~ | Serum uric acid (mg/dL) → uric acid | serum | 4 | mg/dL | 2–6 | NORMAL | follow-up after 3 months of therapy | “/ r19 / Serum uric acid (mg/dL) / 1.5 / 1.0 / 4 / 2–6 /” [tab:1 r19c4] |
| ~ | Serum creatinine (mg/dL) → creatinine | serum | 1.71 | mg/dL | 0.5–1.0 | HIGH | initial presentation | “/ r20 / Serum creatinine (mg/dL) / 1.71 / 2.67 / 0.54 / 0.5–1.0 /” [tab:1 r20c2] |
| ~ | Serum creatinine (mg/dL) → creatinine | serum | 2.67 | mg/dL | 0.5–1.0 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r20 / Serum creatinine (mg/dL) / 1.71 / 2.67 / 0.54 / 0.5–1.0 /” [tab:1 r20c3] |
| ~ | Serum creatinine (mg/dL) → creatinine | serum | 0.54 | mg/dL | 0.5–1.0 | NORMAL | follow-up after 3 months of therapy | “/ r20 / Serum creatinine (mg/dL) / 1.71 / 2.67 / 0.54 / 0.5–1.0 /” [tab:1 r20c4] |
| ~ | eGFR by Schwarz formula → estimated glomerular filtration rate | other | 31 | mL/min/1.73 m2 | > 90 (mL/min/1.73 m2) | LOW | initial presentation | “/ r21 / eGFR by Schwarz formula / 31 / 20 / 99 / > 90 (mL/min/1.73 m2) /” [tab:1 r21c2] |
| ~ | eGFR by Schwarz formula → estimated glomerular filtration rate | other | 20 | mL/min/1.73 m2 | > 90 (mL/min/1.73 m2) | LOW | at time of decompensation (2 days after presentation, during urosepsis) | “/ r21 / eGFR by Schwarz formula / 31 / 20 / 99 / > 90 (mL/min/1.73 m2) /” [tab:1 r21c3] |
| ~ | eGFR by Schwarz formula → estimated glomerular filtration rate | other | 99 | mL/min/1.73 m2 | > 90 (mL/min/1.73 m2) | NORMAL | follow-up after 3 months of therapy | “/ r21 / eGFR by Schwarz formula / 31 / 20 / 99 / > 90 (mL/min/1.73 m2) /” [tab:1 r21c4] |
| ~ | Blood urea (mg/dL) → urea | blood | 35 | mg/dL | 10–40 | NORMAL | initial presentation | “/ r22 / Blood urea (mg/dL) / 35 / 55 / 8 / 10–40 /” [tab:1 r22c2] |
| ~ | Blood urea (mg/dL) → urea | blood | 55 | mg/dL | 10–40 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r22 / Blood urea (mg/dL) / 35 / 55 / 8 / 10–40 /” [tab:1 r22c3] |
| ~ | Blood urea (mg/dL) → urea | blood | 8 | mg/dL | 10–40 | LOW | follow-up after 3 months of therapy | “/ r22 / Blood urea (mg/dL) / 35 / 55 / 8 / 10–40 /” [tab:1 r22c4] |
| ~ | Serum pH → pH | serum | 7.3 | pH units | 7.35–7.45 | LOW | initial presentation | “/ r23 / Serum pH / 7.30 / 7.23 / 7.38 / 7.35–7.45 /” [tab:1 r23c2] |
| ~ | Serum pH → pH | serum | 7.23 | pH units | 7.35–7.45 | LOW | at time of decompensation (2 days after presentation, during urosepsis) | “/ r23 / Serum pH / 7.30 / 7.23 / 7.38 / 7.35–7.45 /” [tab:1 r23c3] |
| ~ | Serum pH → pH | serum | 7.38 | pH units | 7.35–7.45 | NORMAL | follow-up after 3 months of therapy | “/ r23 / Serum pH / 7.30 / 7.23 / 7.38 / 7.35–7.45 /” [tab:1 r23c4] |
| ~ | Serum HCO3 (mEq/L) → bicarbonate | serum | 18 | mEq/L | 21–29 | LOW | initial presentation | “/ r24 / Serum HCO3 (mEq/L) / 18 / 12 / 24 / 21–29 /” [tab:1 r24c2] |
| ~ | Serum HCO3 (mEq/L) → bicarbonate | serum | 12 | mEq/L | 21–29 | LOW | at time of decompensation (2 days after presentation, during urosepsis) | “/ r24 / Serum HCO3 (mEq/L) / 18 / 12 / 24 / 21–29 /” [tab:1 r24c3] |
| ~ | Serum HCO3 (mEq/L) → bicarbonate | serum | 24 | mEq/L | 21–29 | NORMAL | follow-up after 3 months of therapy | “/ r24 / Serum HCO3 (mEq/L) / 18 / 12 / 24 / 21–29 /” [tab:1 r24c4] |
| ~ | 24 h urinary protein (mg/day) → 24-h urinary protein | urine | 200 | mg/day | < 150 | HIGH | initial presentation | “/ r25 / 24 h urinary protein (mg/day) / 200 / 318 / 35 / < 150 /” [tab:1 r25c2] |
| ~ | 24 h urinary protein (mg/day) → 24-h urinary protein | urine | 318 | mg/day | < 150 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r25 / 24 h urinary protein (mg/day) / 200 / 318 / 35 / < 150 /” [tab:1 r25c3] |
| ~ | 24 h urinary protein (mg/day) → 24-h urinary protein | urine | 35 | mg/day | < 150 | NORMAL | follow-up after 3 months of therapy | “/ r25 / 24 h urinary protein (mg/day) / 200 / 318 / 35 / < 150 /” [tab:1 r25c4] |
| ~ | Albumin creatinine ratio (mg/g) → urine albumin/creatinine ratio | urine | 150 | mg/g | 30–300 | HIGH | initial presentation | “/ r26 / Albumin creatinine ratio (mg/g) / 150 / 280 / 20 / 30–300 /” [tab:1 r26c2] |
| ~ | Albumin creatinine ratio (mg/g) → urine albumin/creatinine ratio | urine | 280 | mg/g | 30–300 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r26 / Albumin creatinine ratio (mg/g) / 150 / 280 / 20 / 30–300 /” [tab:1 r26c3] |
| ~ | Albumin creatinine ratio (mg/g) → urine albumin/creatinine ratio | urine | 20 | mg/g | 30–300 | NORMAL | follow-up after 3 months of therapy | “/ r26 / Albumin creatinine ratio (mg/g) / 150 / 280 / 20 / 30–300 /” [tab:1 r26c4] |
| ~ | 24 urinary volumes (mL/day) → 24-h urine volume | urine | 2500 | mL/day | 800–2000 | HIGH | initial presentation | “/ r27 / 24 urinary volumes (mL/day) / 2500 / 2800 / 1200 / 800–2000 /” [tab:1 r27c2] |
| ~ | 24 urinary volumes (mL/day) → 24-h urine volume | urine | 2800 | mL/day | 800–2000 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r27 / 24 urinary volumes (mL/day) / 2500 / 2800 / 1200 / 800–2000 /” [tab:1 r27c3] |
| ~ | 24 urinary volumes (mL/day) → 24-h urine volume | urine | 1200 | mL/day | 800–2000 | NORMAL | follow-up after 3 months of therapy | “/ r27 / 24 urinary volumes (mL/day) / 2500 / 2800 / 1200 / 800–2000 /” [tab:1 r27c4] |
| ~ | Urine output (mL/kg/hour) → urine output | urine | 4 | mL/kg/hour | 0.5–2 mL/kg/hr | HIGH | initial presentation | “/ r28 / Urine output (mL/kg/hour) / 4 / 4.6 / 1.6 / 0.5–2 mL/kg/hr /” [tab:1 r28c2] |
| ~ | Urine output (mL/kg/hour) → urine output | urine | 4.6 | mL/kg/hour | 0.5–2 mL/kg/hr | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r28 / Urine output (mL/kg/hour) / 4 / 4.6 / 1.6 / 0.5–2 mL/kg/hr /” [tab:1 r28c3] |
| ~ | Urine output (mL/kg/hour) → urine output | urine | 1.6 | mL/kg/hour | 0.5–2 mL/kg/hr | NORMAL | follow-up after 3 months of therapy | “/ r28 / Urine output (mL/kg/hour) / 4 / 4.6 / 1.6 / 0.5–2 mL/kg/hr /” [tab:1 r28c4] |
| ~ | Urine specific gravity → urine specific gravity | urine | 1.015 | dimensionless | 1.005–1.030 | NORMAL | initial presentation | “/ r29 / Urine specific gravity / 1015 / 1010 / 1025 / 1.005–1.030 /” [tab:1 r29c2] |
| ~ | Urine specific gravity → urine specific gravity | urine | 1.01 | dimensionless | 1.005–1.030 | LOW | at time of decompensation (2 days after presentation, during urosepsis) | “/ r29 / Urine specific gravity / 1015 / 1010 / 1025 / 1.005–1.030 /” [tab:1 r29c3] |
| ~ | Urine specific gravity → urine specific gravity | urine | 1.025 | dimensionless | 1.005–1.030 | NORMAL | follow-up after 3 months of therapy | “/ r29 / Urine specific gravity / 1015 / 1010 / 1025 / 1.005–1.030 /” [tab:1 r29c4] |
| ~ | Urine PH → pH | urine | 5.9 | pH units | 4.5–8.0 | NORMAL | initial presentation | “/ r30 / Urine PH / 5.9 / 6.5 / 5.0 / 4.5–8.0 /” [tab:1 r30c2] |
| ~ | Urine PH → pH | urine | 6.5 | pH units | 4.5–8.0 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r30 / Urine PH / 5.9 / 6.5 / 5.0 / 4.5–8.0 /” [tab:1 r30c3] |
| ~ | Urine PH → pH | urine | 5.0 | pH units | 4.5–8.0 | NORMAL | follow-up after 3 months of therapy | “/ r30 / Urine PH / 5.9 / 6.5 / 5.0 / 4.5–8.0 /” [tab:1 r30c4] |
| ~ | Urine glucose → glucose | urine | Trace |  | Nil | ABNORMAL | initial presentation | “/ r31 / Urine glucose / Trace / + 1 / Nil / Nil /” [tab:1 r31c2] |
| ~ | Urine glucose → glucose | urine | + 1 |  | Nil | ABNORMAL | at time of decompensation (2 days after presentation, during urosepsis) | “/ r31 / Urine glucose / Trace / + 1 / Nil / Nil /” [tab:1 r31c3] |
| ~ | Urine glucose → glucose | urine | Nil |  | Nil | NORMAL | follow-up after 3 months of therapy | “/ r31 / Urine glucose / Trace / + 1 / Nil / Nil /” [tab:1 r31c4] |
| ~ | TTKG → transtubular potassium gradient | other | 10 | ratio | 6–10 | HIGH | initial presentation | “/ r32 / TTKG / 10 / –- / 6.5 / 6–10 /” [tab:1 r32c2] |
| ~ | TTKG → transtubular potassium gradient | other | 6.5 | ratio | 6–10 | NORMAL | follow-up after 3 months of therapy | “/ r32 / TTKG / 10 / –- / 6.5 / 6–10 /” [tab:1 r32c4] |
| ~ | CMV IgG (AU/mL) → CMV IgG | serum | Negative | AU/mL | Negative | NORMAL | initial presentation | “/ r34 / CMV IgG (AU/mL) / Negative / Negative / Negative / Negative /” [tab:1 r34c2] |
| ~ | CMV IgG (AU/mL) → CMV IgG | serum | Negative | AU/mL | Negative | NORMAL | at time of decompensation (2 days after presentation, during urosepsis) | “/ r34 / CMV IgG (AU/mL) / Negative / Negative / Negative / Negative /” [tab:1 r34c3] |
| ~ | CMV IgG (AU/mL) → CMV IgG | serum | Negative | AU/mL | Negative | NORMAL | follow-up after 3 months of therapy | “/ r34 / CMV IgG (AU/mL) / Negative / Negative / Negative / Negative /” [tab:1 r34c4] |
| ~ | EBV IgG → EBV IgG | serum | Negative |  | Negative | NORMAL | initial presentation | “/ r35 / EBV IgG / Negative / Negative / Negative / Negative /” [tab:1 r35c2] |
| ~ | EBV IgG → EBV IgG | serum | Negative |  | Negative | NORMAL | at time of decompensation (2 days after presentation, during urosepsis) | “/ r35 / EBV IgG / Negative / Negative / Negative / Negative /” [tab:1 r35c3] |
| ~ | EBV IgG → EBV IgG | serum | Negative |  | Negative | NORMAL | follow-up after 3 months of therapy | “/ r35 / EBV IgG / Negative / Negative / Negative / Negative /” [tab:1 r35c4] |
| ~ | Total leukocyte count (× 103/µL) → total leukocyte count | blood | 4.1 | × 103/µL | 4–11 × 103 (/µL) | NORMAL | initial presentation | “/ r37 / Total leukocyte count (× 103/µL) / 4.1 / 2.8 / 9.1 / 4–11 × 103 (/µL) /” [tab:1 r37c2] |
| ~ | Total leukocyte count (× 103/µL) → total leukocyte count | blood | 2.8 | × 103/µL | 4–11 × 103 (/µL) | LOW | at time of decompensation (2 days after presentation, during urosepsis) | “/ r37 / Total leukocyte count (× 103/µL) / 4.1 / 2.8 / 9.1 / 4–11 × 103 (/µL) /” [tab:1 r37c3] |
| ~ | Total leukocyte count (× 103/µL) → total leukocyte count | blood | 9.1 | × 103/µL | 4–11 × 103 (/µL) | NORMAL | follow-up after 3 months of therapy | “/ r37 / Total leukocyte count (× 103/µL) / 4.1 / 2.8 / 9.1 / 4–11 × 103 (/µL) /” [tab:1 r37c4] |
| ~ | Hemoglobin (g/dL) → haemoglobin | blood | 8.1 | g/dL | 12.1–15.1 g/dL | LOW | initial presentation | “/ r38 / Hemoglobin (g/dL) / 8.1 / 5.3 / 10.5 / 12.1–15.1 g/dL /” [tab:1 r38c2] |
| ~ | Hemoglobin (g/dL) → haemoglobin | blood | 5.3 | g/dL | 12.1–15.1 g/dL | LOW | at time of decompensation (2 days after presentation, during urosepsis) | “/ r38 / Hemoglobin (g/dL) / 8.1 / 5.3 / 10.5 / 12.1–15.1 g/dL /” [tab:1 r38c3] |
| ~ | Hemoglobin (g/dL) → haemoglobin | blood | 10.5 | g/dL | 12.1–15.1 g/dL | LOW | follow-up after 3 months of therapy | “/ r38 / Hemoglobin (g/dL) / 8.1 / 5.3 / 10.5 / 12.1–15.1 g/dL /” [tab:1 r38c4] |
| ~ | Mean corpuscular volume (fL) → mean corpuscular volume | blood | 95 | fL | 80–100 fL | NORMAL | initial presentation | “/ r39 / Mean corpuscular volume (fL) / 95 / 120 / 89 / 80–100 fL /” [tab:1 r39c2] |
| ~ | Mean corpuscular volume (fL) → mean corpuscular volume | blood | 120 | fL | 80–100 fL | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r39 / Mean corpuscular volume (fL) / 95 / 120 / 89 / 80–100 fL /” [tab:1 r39c3] |
| ~ | Mean corpuscular volume (fL) → mean corpuscular volume | blood | 89 | fL | 80–100 fL | NORMAL | follow-up after 3 months of therapy | “/ r39 / Mean corpuscular volume (fL) / 95 / 120 / 89 / 80–100 fL /” [tab:1 r39c4] |
| ~ | Reticulocyte count % → reticulocyte count | blood | 2.61 | % | 0.5–2.5% | HIGH | initial presentation | “/ r40 / Reticulocyte count % / 2.61 / 10 / 2.1 / 0.5–2.5% /” [tab:1 r40c2] |
| ~ | Reticulocyte count % → reticulocyte count | blood | 10 | % | 0.5–2.5% | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r40 / Reticulocyte count % / 2.61 / 10 / 2.1 / 0.5–2.5% /” [tab:1 r40c3] |
| ~ | Reticulocyte count % → reticulocyte count | blood | 2.1 | % | 0.5–2.5% | NORMAL | follow-up after 3 months of therapy | “/ r40 / Reticulocyte count % / 2.61 / 10 / 2.1 / 0.5–2.5% /” [tab:1 r40c4] |
| ~ | Platelet (× 103/µL) → platelet count | blood | 60 | × 103/µL | 150,000–450,000 | LOW | initial presentation | “/ r41 / Platelet (× 103/µL) / 60 / 40 / 162 / 150,000–450,000 /” [tab:1 r41c2] |
| ~ | Platelet (× 103/µL) → platelet count | blood | 40 | × 103/µL | 150,000–450,000 | LOW | at time of decompensation (2 days after presentation, during urosepsis) | “/ r41 / Platelet (× 103/µL) / 60 / 40 / 162 / 150,000–450,000 /” [tab:1 r41c3] |
| ~ | Platelet (× 103/µL) → platelet count | blood | 162 | × 103/µL | 150,000–450,000 | NORMAL | follow-up after 3 months of therapy | “/ r41 / Platelet (× 103/µL) / 60 / 40 / 162 / 150,000–450,000 /” [tab:1 r41c4] |
| ~ | TIBC (µg/dL) → total iron-binding capacity | serum | 142 | µg/dL | 250–450 | LOW | initial presentation | “/ r42 / TIBC (µg/dL) / 142 / 120 / 333 / 250–450 /” [tab:1 r42c2] |
| ~ | TIBC (µg/dL) → total iron-binding capacity | serum | 120 | µg/dL | 250–450 | LOW | at time of decompensation (2 days after presentation, during urosepsis) | “/ r42 / TIBC (µg/dL) / 142 / 120 / 333 / 250–450 /” [tab:1 r42c3] |
| ~ | TIBC (µg/dL) → total iron-binding capacity | serum | 333 | µg/dL | 250–450 | NORMAL | follow-up after 3 months of therapy | “/ r42 / TIBC (µg/dL) / 142 / 120 / 333 / 250–450 /” [tab:1 r42c4] |
| ~ | Transferrin saturation (%) → transferrin saturation | serum | 92 | % | 15–50 | HIGH | initial presentation | “/ r43 / Transferrin saturation (%) / 92 / 95 / 20 / 15–50 /” [tab:1 r43c2] |
| ~ | Transferrin saturation (%) → transferrin saturation | serum | 95 | % | 15–50 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r43 / Transferrin saturation (%) / 92 / 95 / 20 / 15–50 /” [tab:1 r43c3] |
| ~ | Transferrin saturation (%) → transferrin saturation | serum | 20 | % | 15–50 | NORMAL | follow-up after 3 months of therapy | “/ r43 / Transferrin saturation (%) / 92 / 95 / 20 / 15–50 /” [tab:1 r43c4] |
| ~ | ANA → antinuclear antibody | serum | Negative |  | Negative | NORMAL | initial presentation | “/ r45 / ANA / Negative / Negative / Negative / Negative /” [tab:1 r45c2] |
| ~ | ANA → antinuclear antibody | serum | Negative |  | Negative | NORMAL | at time of decompensation (2 days after presentation, during urosepsis) | “/ r45 / ANA / Negative / Negative / Negative / Negative /” [tab:1 r45c3] |
| ~ | ANA → antinuclear antibody | serum | Negative |  | Negative | NORMAL | follow-up after 3 months of therapy | “/ r45 / ANA / Negative / Negative / Negative / Negative /” [tab:1 r45c4] |
| ~ | Anti DNA Ab → anti-dsDNA antibody | serum | Negative |  | Negative | NORMAL | initial presentation | “/ r46 / Anti DNA Ab / Negative / Negative / Negative / Negative /” [tab:1 r46c2] |
| ~ | Anti DNA Ab → anti-dsDNA antibody | serum | Negative |  | Negative | NORMAL | at time of decompensation (2 days after presentation, during urosepsis) | “/ r46 / Anti DNA Ab / Negative / Negative / Negative / Negative /” [tab:1 r46c3] |
| ~ | Anti DNA Ab → anti-dsDNA antibody | serum | Negative |  | Negative | NORMAL | follow-up after 3 months of therapy | “/ r46 / Anti DNA Ab / Negative / Negative / Negative / Negative /” [tab:1 r46c4] |
| ~ | C3 (mg/dL) → propionylcarnitine | serum | 78 | mg/dL | 90–180 | LOW | initial presentation | “/ r47 / C3 (mg/dL) / 78 / 44.2 / 120 / 90–180 /” [tab:1 r47c2] |
| ~ | C3 (mg/dL) → propionylcarnitine | serum | 44.2 | mg/dL | 90–180 | LOW | at time of decompensation (2 days after presentation, during urosepsis) | “/ r47 / C3 (mg/dL) / 78 / 44.2 / 120 / 90–180 /” [tab:1 r47c3] |
| ~ | C3 (mg/dL) → propionylcarnitine | serum | 120 | mg/dL | 90–180 | NORMAL | follow-up after 3 months of therapy | “/ r47 / C3 (mg/dL) / 78 / 44.2 / 120 / 90–180 /” [tab:1 r47c4] |
| ~ | C4 (mg/dL) → butyrylcarnitine | serum | < 8 | mg/dL | 10–40 | LOW | initial presentation | “/ r48 / C4 (mg/dL) / < 8 / < 8 / 30 / 10–40 /” [tab:1 r48c2] |
| ~ | C4 (mg/dL) → butyrylcarnitine | serum | < 8 | mg/dL | 10–40 | LOW | at time of decompensation (2 days after presentation, during urosepsis) | “/ r48 / C4 (mg/dL) / < 8 / < 8 / 30 / 10–40 /” [tab:1 r48c3] |
| ~ | C4 (mg/dL) → butyrylcarnitine | serum | 30 | mg/dL | 10–40 | NORMAL | follow-up after 3 months of therapy | “/ r48 / C4 (mg/dL) / < 8 / < 8 / 30 / 10–40 /” [tab:1 r48c4] |
| ~ | ASMA → anti-smooth muscle antibody | serum | Positive |  | Negative | ABNORMAL | initial presentation | “/ r49 / ASMA / Positive / Positive / Negative / Negative /” [tab:1 r49c2] |
| ~ | ASMA → anti-smooth muscle antibody | serum | Positive |  | Negative | ABNORMAL | at time of decompensation (2 days after presentation, during urosepsis) | “/ r49 / ASMA / Positive / Positive / Negative / Negative /” [tab:1 r49c3] |
| ~ | ASMA → anti-smooth muscle antibody | serum | Negative |  | Negative | NORMAL | follow-up after 3 months of therapy | “/ r49 / ASMA / Positive / Positive / Negative / Negative /” [tab:1 r49c4] |
| ~ | Serum IgG (mg/dL) → IgG | serum | 3500 | mg/dL | 700–1600 | HIGH | initial presentation | “/ r50 / Serum IgG (mg/dL) / 3500 / 4100 / 750 / 700–1600 /” [tab:1 r50c2] |
| ~ | Serum IgG (mg/dL) → IgG | serum | 4100 | mg/dL | 700–1600 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r50 / Serum IgG (mg/dL) / 3500 / 4100 / 750 / 700–1600 /” [tab:1 r50c3] |
| ~ | Serum IgG (mg/dL) → IgG | serum | 750 | mg/dL | 700–1600 | NORMAL | follow-up after 3 months of therapy | “/ r50 / Serum IgG (mg/dL) / 3500 / 4100 / 750 / 700–1600 /” [tab:1 r50c4] |
| ~ | Serum IgM (mg/dL) → IgM | serum | 131 | mg/dL | 40–230 | NORMAL | initial presentation | “/ r51 / Serum IgM (mg/dL) / 131 / 150 / 70 / 40–230 /” [tab:1 r51c2] |
| ~ | Serum IgM (mg/dL) → IgM | serum | 150 | mg/dL | 40–230 | NORMAL | at time of decompensation (2 days after presentation, during urosepsis) | “/ r51 / Serum IgM (mg/dL) / 131 / 150 / 70 / 40–230 /” [tab:1 r51c3] |
| ~ | Serum IgM (mg/dL) → IgM | serum | 70 | mg/dL | 40–230 | NORMAL | follow-up after 3 months of therapy | “/ r51 / Serum IgM (mg/dL) / 131 / 150 / 70 / 40–230 /” [tab:1 r51c4] |
| ~ | Coombs test → direct antiglobulin (Coombs) test | blood | Negative |  | Negative | NORMAL | initial presentation | “/ r52 / Coombs test / Negative / Negative / Negative / Negative /” [tab:1 r52c2] |
| ~ | Coombs test → direct antiglobulin (Coombs) test | blood | Negative |  | Negative | NORMAL | at time of decompensation (2 days after presentation, during urosepsis) | “/ r52 / Coombs test / Negative / Negative / Negative / Negative /” [tab:1 r52c3] |
| ~ | Coombs test → direct antiglobulin (Coombs) test | blood | Negative |  | Negative | NORMAL | follow-up after 3 months of therapy | “/ r52 / Coombs test / Negative / Negative / Negative / Negative /” [tab:1 r52c4] |
| ~ | Random blood sugar (mg/dL) → random blood glucose | blood | 100 | mg/dL | Up to 180 | NORMAL | initial presentation | “/ r54 / Random blood sugar (mg/dL) / 100 / 80 / 110 / Up to 180 /” [tab:1 r54c2] |
| ~ | Random blood sugar (mg/dL) → random blood glucose | blood | 80 | mg/dL | Up to 180 | NORMAL | at time of decompensation (2 days after presentation, during urosepsis) | “/ r54 / Random blood sugar (mg/dL) / 100 / 80 / 110 / Up to 180 /” [tab:1 r54c3] |
| ~ | Random blood sugar (mg/dL) → random blood glucose | blood | 110 | mg/dL | Up to 180 | NORMAL | follow-up after 3 months of therapy | “/ r54 / Random blood sugar (mg/dL) / 100 / 80 / 110 / Up to 180 /” [tab:1 r54c4] |
| ~ | CRP (mg/L) → C-reactive protein | serum | < 5 | mg/L | < 5 | NORMAL | initial presentation | “/ r55 / CRP (mg/L) / < 5 / 320 / < 5 / < 5 /” [tab:1 r55c2] |
| ~ | CRP (mg/L) → C-reactive protein | serum | 320 | mg/L | < 5 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r55 / CRP (mg/L) / < 5 / 320 / < 5 / < 5 /” [tab:1 r55c3] |
| ~ | CRP (mg/L) → C-reactive protein | serum | < 5 | mg/L | < 5 | NORMAL | follow-up after 3 months of therapy | “/ r55 / CRP (mg/L) / < 5 / 320 / < 5 / < 5 /” [tab:1 r55c4] |
| ~ | LDH (U/L) → lactate dehydrogenase | serum | 300 | U/L | 140–280 | HIGH | initial presentation | “/ r56 / LDH (U/L) / 300 / 681 / 130 / 140–280 /” [tab:1 r56c2] |
| ~ | LDH (U/L) → lactate dehydrogenase | serum | 681 | U/L | 140–280 | HIGH | at time of decompensation (2 days after presentation, during urosepsis) | “/ r56 / LDH (U/L) / 300 / 681 / 130 / 140–280 /” [tab:1 r56c3] |
| ~ | LDH (U/L) → lactate dehydrogenase | serum | 130 | U/L | 140–280 | LOW | follow-up after 3 months of therapy | “/ r56 / LDH (U/L) / 300 / 681 / 130 / 140–280 /” [tab:1 r56c4] |
| ~ | Serum Ceruloplasmin (mg/dL) → ceruloplasmin | serum | 8.6–8.8* | mg/dL | 20–40 | LOW | at the time of diagnosis and confirmation across laboratories | “/ r58 / Serum Ceruloplasmin (mg/dL) / 8.6–8.8* / 29.9 / 31 / 20–40 /” [tab:1 r58c2] |
| ~ | Serum Ceruloplasmin (mg/dL) → ceruloplasmin | serum | 29.9 | mg/dL | 20–40 | NORMAL | biochemical response 3 weeks post chelation | “/ r58 / Serum Ceruloplasmin (mg/dL) / 8.6–8.8* / 29.9 / 31 / 20–40 /” [tab:1 r58c3] |
| ~ | Serum Ceruloplasmin (mg/dL) → ceruloplasmin | serum | 31 | mg/dL | 20–40 | NORMAL | biochemical response one year post chelation | “/ r58 / Serum Ceruloplasmin (mg/dL) / 8.6–8.8* / 29.9 / 31 / 20–40 /” [tab:1 r58c4] |
| ~ | 24 h Urinary Cu (µg) → copper (24-h urinary excretion) | urine | 1330–1337* | µg | < 100 | HIGH | at the time of diagnosis and confirmation across laboratories | “/ r59 / 24 h Urinary Cu (µg) / 1330–1337* / 153 / 98 / < 100 /” [tab:1 r59c2] |
| ~ | 24 h Urinary Cu (µg) → copper (24-h urinary excretion) | urine | 153 | µg | < 100 | HIGH | biochemical response 3 weeks post chelation | “/ r59 / 24 h Urinary Cu (µg) / 1330–1337* / 153 / 98 / < 100 /” [tab:1 r59c3] |
| ~ | 24 h Urinary Cu (µg) → copper (24-h urinary excretion) | urine | 98 | µg | < 100 | NORMAL | biochemical response one year post chelation | “/ r59 / 24 h Urinary Cu (µg) / 1330–1337* / 153 / 98 / < 100 /” [tab:1 r59c4] |

## Phenotypes

- ✓ Jaundice → Jaundice HP:0000952 (grounded)  
  “presenting with a 3-month history of recurrent anicteric jaundice, abdominal pain, weight loss, poor academic performance, and polyuria with no changes in urine or stool color” [sec:2 ¶1]
- ✓ Abdominal pain → Abdominal pain HP:0002027 (grounded)  
  “presenting with a 3-month history of recurrent anicteric jaundice, abdominal pain, weight loss, poor academic performance, and polyuria with no changes in urine or stool color” [sec:2 ¶1]
- ✓ Weight loss → Weight loss HP:0001824 (grounded)  
  “presenting with a 3-month history of recurrent anicteric jaundice, abdominal pain, weight loss, poor academic performance, and polyuria with no changes in urine or stool color” [sec:2 ¶1]
- ✓ Poor school performance → Intellectual disability HP:0001249 (grounded)  
  “presenting with a 3-month history of recurrent anicteric jaundice, abdominal pain, weight loss, poor academic performance, and polyuria with no changes in urine or stool color” [sec:2 ¶1]
- ✓ Polyuria → Polyuria HP:0000103 (grounded)  
  “presenting with a 3-month history of recurrent anicteric jaundice, abdominal pain, weight loss, poor academic performance, and polyuria with no changes in urine or stool color” [sec:2 ¶1]
- ✓ Cachexia → Cachexia HP:0004326 (grounded)  
  “Examination showed cachexia, normal blood pressure (50th percentile), mild hepatosplenomegaly, audible cardiac hemic murmur, kinetic hand tremors, with normal ocular examination.” [sec:2 ¶1]
- ✓ NOT Hypertension → Hypertension HP:0000822 (grounded)  
  “Examination showed cachexia, normal blood pressure (50th percentile), mild hepatosplenomegaly, audible cardiac hemic murmur, kinetic hand tremors, with normal ocular examination.” [sec:2 ¶1]
- ✓ Hepatosplenomegaly → Hepatosplenomegaly HP:0001433 (grounded)  
  “Examination showed cachexia, normal blood pressure (50th percentile), mild hepatosplenomegaly, audible cardiac hemic murmur, kinetic hand tremors, with normal ocular examination.” [sec:2 ¶1]
- ✓ Heart murmur → Heart murmur HP:0030148 (grounded)  
  “Examination showed cachexia, normal blood pressure (50th percentile), mild hepatosplenomegaly, audible cardiac hemic murmur, kinetic hand tremors, with normal ocular examination.” [sec:2 ¶1]
- ✓ Kinetic hand tremor → –  (candidate)  
  “Examination showed cachexia, normal blood pressure (50th percentile), mild hepatosplenomegaly, audible cardiac hemic murmur, kinetic hand tremors, with normal ocular examination.” [sec:2 ¶1]
- ✓ NOT Kayser-Fleischer ring → Kayser-Fleischer ring HP:0200032 (grounded)  
  “Examination showed cachexia, normal blood pressure (50th percentile), mild hepatosplenomegaly, audible cardiac hemic murmur, kinetic hand tremors, with normal ocular examination.” [sec:2 ¶1]
- ✓ Renal insufficiency → Renal insufficiency HP:0000083 (grounded)  
  “Laboratory investigations (Table 1) initially showed impaired kidney function, hypokalemia, elevated transtubular potassium gradient (TTKG), albuminuria, and normal anion gap metabolic acidosis” [sec:2 ¶2]
- ✓ Hypokalemia → Hypokalemia HP:0002900 (grounded)  
  “Laboratory investigations (Table 1) initially showed impaired kidney function, hypokalemia, elevated transtubular potassium gradient (TTKG), albuminuria, and normal anion gap metabolic acidosis” [sec:2 ¶2]
- ✓ Albuminuria → Albuminuria HP:0012592 (grounded)  
  “Laboratory investigations (Table 1) initially showed impaired kidney function, hypokalemia, elevated transtubular potassium gradient (TTKG), albuminuria, and normal anion gap metabolic acidosis” [sec:2 ¶2]
- ✓ Metabolic acidosis → Metabolic acidosis HP:0001942 (grounded)  
  “Laboratory investigations (Table 1) initially showed impaired kidney function, hypokalemia, elevated transtubular potassium gradient (TTKG), albuminuria, and normal anion gap metabolic acidosis” [sec:2 ¶2]
- ✓ Elevated hepatic transaminase → Elevated circulating hepatic transaminase concentration HP:0002910 (grounded)  
  “mild aminotransaminase elevation, hyperbilirubinemia, thrombocytopenia, non-immune hemolysis, high IgG, + ve ASMA, low C3 and C4.” [sec:2 ¶2]
- ✓ Hyperbilirubinemia → Hyperbilirubinemia HP:0002904 (grounded)  
  “mild aminotransaminase elevation, hyperbilirubinemia, thrombocytopenia, non-immune hemolysis, high IgG, + ve ASMA, low C3 and C4.” [sec:2 ¶2]
- ✓ Thrombocytopenia → Thrombocytopenia HP:0001873 (grounded)  
  “mild aminotransaminase elevation, hyperbilirubinemia, thrombocytopenia, non-immune hemolysis, high IgG, + ve ASMA, low C3 and C4.” [sec:2 ¶2]
- ✓ Hemolytic anemia → Hemolytic anemia HP:0001878 (grounded)  
  “She had cachexia, hepatosplenomegaly, kinetic hand tremors, non-immune hemolytic anemia, and mild glomerular and tubular dysfunction.” [abstract]
- ✓ Increased circulating IgG level → Increased circulating IgG concentration HP:0003237 (grounded)  
  “mild aminotransaminase elevation, hyperbilirubinemia, thrombocytopenia, non-immune hemolysis, high IgG, + ve ASMA, low C3 and C4.” [sec:2 ¶2]
- ✓ Anti-smooth muscle antibody positivity → Anti-smooth muscle antibody positivity HP:0003262 (grounded)  
  “mild aminotransaminase elevation, hyperbilirubinemia, thrombocytopenia, non-immune hemolysis, high IgG, + ve ASMA, low C3 and C4.” [sec:2 ¶2]
- ✓ NOT Anti-smooth muscle antibody positivity → Anti-smooth muscle antibody positivity HP:0003262 (grounded)  
  “At 3-month follow-up, patient showed sustained improvement, with normalization of all her laboratory parameters and -ve ASMA.” [sec:2 ¶6]
- ✓ Decreased serum complement C3 → Decreased circulating complement C3 concentration HP:0005421 (grounded)  
  “mild aminotransaminase elevation, hyperbilirubinemia, thrombocytopenia, non-immune hemolysis, high IgG, + ve ASMA, low C3 and C4.” [sec:2 ¶2]
- ✓ Decreased serum complement C4 → Decreased circulating complement C4 concentration HP:0045042 (grounded)  
  “mild aminotransaminase elevation, hyperbilirubinemia, thrombocytopenia, non-immune hemolysis, high IgG, + ve ASMA, low C3 and C4.” [sec:2 ¶2]
- ✓ Hypocomplementemia → –  (candidate)  
  “Transient hypocomplementemia reflected impaired hepatic synthesis during ALF, as complement is hepatic protein derived [7].” [sec:4 ¶3]
- ✓ Lymphadenopathy → Lymphadenopathy HP:0002716 (grounded)  
  “Imaging showed mild hepatosplenomegaly and lymph node enlargement near the liver's portal vein (porta hepatis lymphadenopathy) with normal kidneys.” [sec:2 ¶2]
- ✓ NOT Abnormality of the kidney → Abnormality of the kidney HP:0000077 (grounded)  
  “Imaging showed mild hepatosplenomegaly and lymph node enlargement near the liver's portal vein (porta hepatis lymphadenopathy) with normal kidneys.” [sec:2 ¶2]
- ✓ Fever → Fever HP:0001945 (grounded)  
  “Two days later she developed fever, worsening pallor, jaundice, tachycardia, hypotension, polyuria, ascites, and loin tenderness.” [sec:2 ¶3]
- ✓ Pallor → Pallor HP:0000980 (grounded)  
  “Two days later she developed fever, worsening pallor, jaundice, tachycardia, hypotension, polyuria, ascites, and loin tenderness.” [sec:2 ¶3]
- ✓ Tachycardia → Tachycardia HP:0001649 (grounded)  
  “Two days later she developed fever, worsening pallor, jaundice, tachycardia, hypotension, polyuria, ascites, and loin tenderness.” [sec:2 ¶3]
- ✓ Hypotension → Hypotension HP:0002615 (grounded)  
  “Two days later she developed fever, worsening pallor, jaundice, tachycardia, hypotension, polyuria, ascites, and loin tenderness.” [sec:2 ¶3]
- ✓ Ascites → Ascites HP:0001541 (grounded)  
  “Two days later she developed fever, worsening pallor, jaundice, tachycardia, hypotension, polyuria, ascites, and loin tenderness.” [sec:2 ¶3]
- ✓ Loin tenderness → –  (candidate)  
  “Two days later she developed fever, worsening pallor, jaundice, tachycardia, hypotension, polyuria, ascites, and loin tenderness.” [sec:2 ¶3]
- ✓ Hypophosphatemia → Hypophosphatemia HP:0002148 (grounded)  
  “Repeat investigations showed declining eGFR, hypokalemia, hypophosphatemia, hypouricemia, normal anion gap metabolic acidosis, low urine specific gravity, albuminuria, and glucosuria with normoglycemia” [sec:2 ¶3]
- ✓ Hypouricemia → Hypouricemia HP:0003537 (grounded)  
  “Repeat investigations showed declining eGFR, hypokalemia, hypophosphatemia, hypouricemia, normal anion gap metabolic acidosis, low urine specific gravity, albuminuria, and glucosuria with normoglycemia” [sec:2 ¶3]
- ✓ Glycosuria → Glycosuria HP:0003076 (grounded)  
  “Repeat investigations showed declining eGFR, hypokalemia, hypophosphatemia, hypouricemia, normal anion gap metabolic acidosis, low urine specific gravity, albuminuria, and glucosuria with normoglycemia” [sec:2 ¶3]
- ✓ Pancytopenia → Pancytopenia HP:0001876 (grounded)  
  “hyperbilirubinemia, transaminase elevation, pancytopenia, non-immune hemolysis, and coagulopathy.” [sec:2 ¶3]
- ✓ Coagulopathy → Abnormality of the coagulation cascade HP:0003256 (grounded)  
  “hyperbilirubinemia, transaminase elevation, pancytopenia, non-immune hemolysis, and coagulopathy.” [sec:2 ¶3]
- ✓ Hyperechogenic kidneys → Hyperechogenic kidneys HP:0004719 (grounded)  
  “Abdominal imaging revealed hepatosplenomegaly, ascites, thickened peritoneal reflections, mesenteric vascular congestion, persistent porta hepatis lymphadenopathy, bilateral hyperechogenic kidneys and grade 1 nephropathy, no nephrocalcinosis or nephrolithiasis.” [sec:2 ¶3]
- ✓ Thickened peritoneal reflections → –  (candidate)  
  “Abdominal imaging revealed hepatosplenomegaly, ascites, thickened peritoneal reflections, mesenteric vascular congestion, persistent porta hepatis lymphadenopathy, bilateral hyperechogenic kidneys and grade 1 nephropathy, no nephrocalcinosis or nephrolithiasis.” [sec:2 ¶3]
- ✓ Mesenteric vascular congestion → –  (candidate)  
  “Abdominal imaging revealed hepatosplenomegaly, ascites, thickened peritoneal reflections, mesenteric vascular congestion, persistent porta hepatis lymphadenopathy, bilateral hyperechogenic kidneys and grade 1 nephropathy, no nephrocalcinosis or nephrolithiasis.” [sec:2 ¶3]
- ✓ NOT Nephrocalcinosis → Nephrocalcinosis HP:0000121 (grounded)  
  “Abdominal imaging revealed hepatosplenomegaly, ascites, thickened peritoneal reflections, mesenteric vascular congestion, persistent porta hepatis lymphadenopathy, bilateral hyperechogenic kidneys and grade 1 nephropathy, no nephrocalcinosis or nephrolithiasis.” [sec:2 ¶3]
- ✓ NOT Nephrolithiasis → Kidney stone HP:0000787 (grounded)  
  “Abdominal imaging revealed hepatosplenomegaly, ascites, thickened peritoneal reflections, mesenteric vascular congestion, persistent porta hepatis lymphadenopathy, bilateral hyperechogenic kidneys and grade 1 nephropathy, no nephrocalcinosis or nephrolithiasis.” [sec:2 ¶3]
- ✓ Hepatic fibrosis → Hepatic fibrosis HP:0001395 (grounded)  
  “Fibroscan confirmed advanced hepatic fibrosis.” [sec:2 ¶3]
- ✓ Acute liver failure → Acute hepatic failure HP:0006554 (grounded)  
  “This was a complex presentation, with a self-limited hepatitis-like illness, followed by ALF, precipitated by urosepsis, unmasking latent Cu toxicity and multiorgan dysfunction.” [sec:4 ¶1]
- ✓ Urosepsis → –  (candidate)  
  “later stopped after urine culture confirmed Gram -ve urosepsis responsive to cephalosporins, implicating urosepsis as the cause.” [sec:2 ¶4]
- ✓ Acute kidney injury → Acute kidney injury HP:0001919 (grounded)  
  “Urosepsis triggered decompensation with worsening hepatic function, acute kidney injury (AKI) with Fanconi-like tubulopathy, coagulopathy, low complements, + ve autoantibodies, and elevated IgG.” [abstract]
- ✓ Fanconi-like tubulopathy → –  (candidate)  
  “During urosepsis, findings progressed to Fanconi-like syndrome, worsening eGFR and hypokalemia, hypophosphatemia, profound hypouricemia, non-anion gap metabolic acidosis, high urine pH, polyuria, albuminuria and glucosuria despite normoglycemia.” [sec:5 ¶3]
- ✓ Proximal tubulopathy → Proximal tubulopathy HP:0000114 (grounded)  
  “Our patient had combined glomerular and proximal tubular dysfunction with AKI, hypokalemia with high TTKG, glucosuria with normoglycemia, hypouricemia, non–anion gap acidosis, albuminuria, and polyuria.” [sec:5 ¶3]
- ✓ Glomerular dysfunction → –  (candidate)  
  “She had cachexia, hepatosplenomegaly, kinetic hand tremors, non-immune hemolytic anemia, and mild glomerular and tubular dysfunction.” [abstract]
- ✓ Low alkaline phosphatase → Decreased circulating alkaline phosphatase activity HP:0003282 (grounded)  
  “Our patient exhibited severe hepatic WD profile with modest aminotransferase elevation, marked hyperbilirubinemia, and low alkaline phosphatase [1, 8].” [sec:5 ¶1]
- ✓ Chronic hepatitis → Chronic hepatitis HP:0200123 (grounded)  
  “At that time, liver biopsy revealed chronic hepatitis with significant inflammation and fibrosis, but no Cu deposition, prompting D-penicillamine dose reduction.” [sec:2 ¶6]
- ✓ NOT Hepatic copper deposition → –  (candidate)  
  “At that time, liver biopsy revealed chronic hepatitis with significant inflammation and fibrosis, but no Cu deposition, prompting D-penicillamine dose reduction.” [sec:2 ¶6]
- ✓ Dysarthria → Dysarthria HP:0001260 (grounded)  
  “At 1 year post therapy, new dysarthria and Kayser–Fleischer (K-F) rings appeared on examination, yet fibrosis regressed on Fibroscan, with no additional organ involvement, requiring no therapy changes.” [sec:2 ¶7]
- ✓ Kayser-Fleischer ring → Kayser-Fleischer ring HP:0200032 (grounded)  
  “At 1 year post therapy, new dysarthria and Kayser–Fleischer (K-F) rings appeared on examination, yet fibrosis regressed on Fibroscan, with no additional organ involvement, requiring no therapy changes.” [sec:2 ¶7]

## Treatments

- ✓ drug: D-penicillamine · response improved  
  “Therapy included Cu restriction, D-penicillamine (20 mg/kg/day, reduced to 15 mg/kg/day after 3 months), zinc sulfate (1 mg/kg/day) [8], oral potassium (1 mmol/kg/day) for hypokalemia. This led to rapid clinical improvement.” [sec:6 ¶1]
- ✓ drug: zinc sulfate · response improved  
  “Therapy included Cu restriction, D-penicillamine (20 mg/kg/day, reduced to 15 mg/kg/day after 3 months), zinc sulfate (1 mg/kg/day) [8], oral potassium (1 mmol/kg/day) for hypokalemia. This led to rapid clinical improvement.” [sec:6 ¶1]
- ✓ diet: Cu restriction · response improved  
  “Therapy included Cu restriction, D-penicillamine (20 mg/kg/day, reduced to 15 mg/kg/day after 3 months), zinc sulfate (1 mg/kg/day) [8], oral potassium (1 mmol/kg/day) for hypokalemia. This led to rapid clinical improvement.” [sec:6 ¶1]
- ✓ drug: oral potassium · response improved  
  “Therapy included Cu restriction, D-penicillamine (20 mg/kg/day, reduced to 15 mg/kg/day after 3 months), zinc sulfate (1 mg/kg/day) [8], oral potassium (1 mmol/kg/day) for hypokalemia. This led to rapid clinical improvement.” [sec:6 ¶1]
- ✓ drug: cefotaxime · response improved  
  “In our patient, urosepsis was managed with cefotaxime (75 mg/kg/8 h) for 10 days, guided by culture sensitivity.” [sec:6 ¶1]
- ✓ supportive: vasopressors, blood transfusion, fluids, empirical antibiotics · response improved  
  “She received vasopressors, blood transfusions, fluids, and empirical broad-spectrum antibiotics, followed by dramatic improvement within 4 days, though hemolysis persisted.” [sec:2 ¶4]
- ✓ drug: pulse steroid · response not_stated  
  “she was empirically given a 3-day course of pulse steroid for suspected catastrophic SLE with overlapping lupus hepatitis, later stopped after urine culture confirmed Gram -ve urosepsis responsive to cephalosporins” [sec:2 ¶4]
- ✓ drug: D-penicillamine + zinc sulfate · response improved  
  “Early chelation with D-penicillamine and zinc sulfate, oral potassium, and culture-guided antibiotics led to rapid recovery within 3 weeks, though ASMA + ve, reflecting reactive autoimmunity.” [sec:2 ¶5]

## Outcome

Rapid hepatorenal and hematological recovery within 3 weeks of chelation; normalization of all laboratory parameters at 3 months (serum ceruloplasmin 31 mg/dL and 24-h urinary Cu 98 µg at 1 year). Liver biopsy at 3 months showed chronic hepatitis with inflammation and fibrosis but no Cu deposition. At 1 year post therapy, new dysarthria and Kayser-Fleischer rings appeared, while fibrosis regressed on Fibroscan with no additional organ involvement and no therapy changes. Alive at last follow-up.

## Model summary (not source text)

A 10-year-old girl born to consanguineous parents presented with a 3-month history of recurrent jaundice, abdominal pain, weight loss, poor school performance and polyuria, with cachexia, mild hepatosplenomegaly, a hemic murmur and kinetic hand tremors on examination. Initial investigations showed impaired kidney function (creatinine 1.71 mg/dL, eGFR 31 mL/min/1.73 m2), hypokalemia, normal anion gap metabolic acidosis, albuminuria, mild transaminase elevation, hyperbilirubinemia (total bilirubin 6.4 mg/dL), thrombocytopenia, Coombs-negative hemolytic anemia, high IgG, positive ASMA and low C3/C4. Two days later, Gram-negative urosepsis precipitated acute liver failure with acute kidney injury and a Fanconi-like tubulopathy (hypophosphatemia, hypouricemia, glucosuria with normoglycemia), pancytopenia and coagulopathy; imaging showed hepatosplenomegaly, ascites, porta hepatis lymphadenopathy and hyperechogenic kidneys, and Fibroscan showed advanced hepatic fibrosis. Malignancy, SLE and autoimmune hepatitis were considered; Wilson's disease was confirmed biochemically by low serum ceruloplasmin (8.6-8.8 mg/dL) and markedly elevated 24-h urinary copper (1330-1337 µg), repeated across laboratories, with a Leipzig score > 4; ATP7B sequencing was not performed. Treatment with D-penicillamine, zinc sulfate, copper restriction, oral potassium and cefotaxime led to recovery within 3 weeks and normalization of laboratory parameters at 3 months, with urinary copper 153 µg at 3 weeks and 98 µg at 1 year. At 1 year, fibrosis had regressed but new dysarthria and Kayser-Fleischer rings appeared; sibling screening by ceruloplasmin and urinary copper was negative.

## Extractor notes

- Table 1 columns: c1 analyte, c2 initial presentation (weight 26 kg, height 128 cm), c3 'At time of decompaction' (sic; decompensation, 2 days after presentation, during urosepsis; weight 25 kg), c4 follow-up after 3 months of therapy (weight 30 kg, height 129 cm), c5 reference range. For the Cu metabolism rows r58-r59 the header row r57 redefines the columns as: c2 at diagnosis/confirmation across laboratories, c3 3 weeks post chelation, c4 one year post chelation.
- Serum ceruloplasmin '8.6–8.8*' and 24 h urinary Cu '1330–1337*' at diagnosis are ranges across laboratories (asterisk = confirmation across laboratories); recorded with value=null and value_text.
- Interpretation conflicts between the authors' text and the tabulated reference ranges (authors' interpretation kept, validator may warn): TTKG 10 (ref 6–10) called 'elevated'/'high TTKG'; albumin creatinine ratio 150 and 280 mg/g (ref '30–300', which is the microalbuminuria band) called 'albuminuria'; urine specific gravity 1010 (ref 1.005–1.030) called 'low'; urine pH 6.5 (ref 4.5–8.0) called 'high' during urosepsis.
- Authors state 'low alkaline phosphatase' (sec:5 ¶1) but tabulated values 79/131/70 U/L are within the stated 40–150 reference range; measurements recorded as NORMAL by range and the authors' statement recorded as a phenotype.
- Authors state 'normalization of all her laboratory parameters' at 3 months, but by the tabulated reference ranges the 3-month albumin (5.7, ref 3.5–5.2), serum phosphorus (5.3, ref 2.5–4.5) are high and blood urea (8, ref 10–40), PTT (24, ref 25–35) and LDH (130, ref 140–280) are low; interpretations follow the reference range.
- Urine specific gravity values are printed without a decimal point (1015, 1010, 1025); value normalised to 1.015/1.010/1.025 with the reference range 1.005–1.030, value_text kept as written.
- Platelet count values are in × 10^3/µL while the reference range is written as '150,000–450,000'; numeric bounds normalised to 150–450 in the value unit, text kept as written.
- TTKG at decompensation is printed as '–-' (not reported) and was not extracted.
- Units 'ratio', 'pH units' and 'dimensionless' for INR, TTKG, pH and urine specific gravity are curator conventions for unitless quantities; the source gives no unit for these rows.
- Serum pH and HCO3 are labelled 'Serum' in the table and recorded as specimen serum; eGFR (Schwarz formula) and TTKG are calculated indices recorded as specimen 'other'.
- The presenting complaint is written as 'recurrent anicteric jaundice' (sec:2 ¶1), an apparent contradiction; the abstract says 'recurrent jaundice'. Recorded as Jaundice.
- Kayser-Fleischer rings: 'normal ocular examination' at presentation recorded as excluded at presentation; new K-F rings and dysarthria appeared at 1 year post therapy.
- Age at diagnosis P10Y is taken from the presentation age (diagnosis made during the same admission); age at last follow-up is given only as '1 year post therapy'.
- No genetic testing was performed (ATP7B sequencing recommended but not done for financial reasons); diagnosis tier BIOCHEMICAL. Supporting statement (sec:5 ¶2): 'Diagnosis was established by Leipzig score > 4, based on neuropsychiatric signs, non-immune hemolytic anemia, elevated 24-h urinary Cu, and low serum ceruloplasmin'. The Leipzig score itself is not recorded as a measurement.
- Albumin creatinine ratio at 3 months (20 mg/g) is below the tabulated '30–300' band and recorded as NORMAL (authors: normalization of all laboratory parameters); the validator flags it as LOW against the parsed bounds.
- Family screening: siblings biochemically negative (serum ceruloplasmin and urinary Cu); no individual values given.
- Country of care and ancestry are not stated.