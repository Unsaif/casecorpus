# PMID_42319439_the_patient
**Source:** PMID 42319439 · Acta diabetologica 2026 · DOI 10.1007/s00592-026-02685-6 · licence: None · tier: epmc
**Individual:** the patient · sex MALE · onset – · presentation P27Y (27-year-old) · last follow-up – · ALIVE
**Evidence verification:** 48/48 quotes found in their anchored unit, 48/48 anywhere in the document; narrative source: manifest

## Patient description (verbatim from the source, by anchor)

> **[abstract]** Aims: Phenylketonuria and type 1 diabetes are lifelong metabolic disorders requiring complex and potentially conflicting nutritional strategies. Their coexistence is rare, yet management may become particularly challenging during transition from pediatric to adult care. We describe the case of a young adult with phenylketonuria who developed type 1 diabetes.
Methods: A 27-year-old man with longstanding phenylketonuria was referred to an adult metabolic-diabetes center after the diagnosis of type 1 diabetes. Clinical, biochemical, nutritional, and continuous glucose monitoring data were reviewed. The intervention included structured therapeutic education, transition from fixed insulin doses to a dynamic regimen based on carbohydrate counting, and revision of medical nutrition therapy using phenylketonuria-adapted low-protein foods and sugar-free phenylalanine-free amino acid supplements.
Results: At diagnosis, HbA1c was 11.5%, with markedly reduced C-peptide levels and high titer anti-GAD antibodies. Initial diabetes management was associated with poor adherence to the phenylketonuria diet, increased intake of conventional protein sources, and elevated phenylalanine levels. After individualized insulin titration and nutritional intervention, HbA1c improved from 11.5% to 7.8%, phenylalanine levels decreased from 842 to 705 μmol/L, insulin requirement declined from 0.55 to 0.3 IU/kg/day, and continuous glucose monitoring showed improved glycemic control without increased hypoglycemia. The Glycemia Risk Index improved from high-risk Zone E to low-intermediate-risk Zone B.
Conclusions: This case highlights the need for personalized multidisciplinary care integrating continuous glucose monitoring, carbohydrate counting, and phenylketonuria specific nutrition to optimize both metabolic conditions.
>
> **[sec:2 ¶1]** Herein, we describe the case of a 27-year-old adult with PKU, who had been followed at a pediatric care center and recently developed T1D.
>
> **[sec:2 ¶2]** In November 2022, the patient presented to the Emergency Room with occasional hyperglycemia and weight loss. Diabetic ketoacidosis (DKA) was biochemically excluded at onset (based on pH, anion gap, and ketone levels), and no acute precipitating factors, such as infections, were identified. T1D was suspected, and insulin therapy with multiple daily injections was initiated. In December 2022, the patient was admitted to our adult center.
>
> **[sec:2 ¶3]** On examination, the patient had a BMI of 19.7 kg/m², normal blood pressure, and a normal ECG. Laboratory results showed glycated hemoglobin (HbA1c) of 11.5%, C-peptide of 0.4 nmol/L, and positive anti-GAD autoantibodies (6.6 UA/mL; normal < 5 UA/mL, Insulin, IA2, and ZnT8 autoantibodies negative), confirming the diagnosis of T1D. Monogenic diabetes was also excluded through genetic testing of HNF4A, GCK, HNF1A, PDX1 AND HNF1B, which revealed no associated mutations. Autoimmunity screening was also performed for the main conditions typically associated with type 1 diabetes, such as thyroiditis and celiac disease, with negative results.
>
> **[sec:2 ¶4]** The patient’s PKU management was suboptimal, with serial phenylalanine (Phe) levels (normal range 120–600 µmol/L) and Phe/Tyr ratios consistently above recommended targets. Initially, the patient was advised to follow the PKU diet and was prescribed a continuous glucose monitoring (CGM) system.
>
> **[sec:2 ¶5]** At the first follow up visit, CGM data showed poor glycemic control (Fig. 1a), and analysis of the food diary revealed inadequate adherence to the PKU diet, due to the T1D diagnosis, as the patient preferred conventional whole grain products and animal protein sources to manage post-prandial hyperglycemia; this resulted in an increased dietary phenylalanine intake and consequently elevated phenylalanine levels (Phe 842 µmol/L); moreover, a brain MRI indicated signs of metabolic accumulation distress, characterized by white matter hyperintensities typically associated with chronic elevation of brain phenylalanine levels.
>
> **[sec:2 ¶6]** Fig. 1(a) Initial Continuous Glucose Monitoring (CGM) ambulatory glucse profile (AGP) showing poor glycemic control. The report from March-April 2023 indicates a Time in Range (70–180 mg/dL) of only 16%, with 31% of TAR level 1 and 52% of TAR level 2 and a mean glucose of 257 mg/dL (b) Follow-up, Visit 4 CGM AGP. The report from July-August 2023 shows significant improvements, with Time in Range increasing to 63%, mean glucose reduced to 164 mg/dL, and stable glucose variability (33.5%). (c) Glycemia Risk Index (GRI) progression over four follow-up visits. The patient’s profile moved from Zone E (visit 1, high hyperglycemia risk) to Zone B (visit 4, lower risk), indicating a marked improvement in glycemic control
>
> **[sec:2 ¶7]** To address these challenges, the patient was transitioned from fixed insulin doses to a dynamic regimen. He was educated on “Carbohydrate Counting” specifically adjusted for PKU-specific medical products. A new PKU-adapted diet was prescribed, featuring special low-protein foods (SLPF) low in refined sugars and maltodextrins and with phe-free aminoacid supplements without added sugars. The medical nutrition therapy (MNT) was normocaloric, targeting 500 mg/day of Phe and a protein intake of 1 g/kg/day. The diet is essentially plant-based (excluding all animal protein sources) and includes low-protein foods (low-protein/protein-free pasta and bread). Therefore, to achieve a normal protein intake of 1 g/kg/day, phe-free amino acid supplements are necessary. The MNT has been set up with 80% of total protein from supplements, “special” foods and foods naturally characterized by a low protein content (fruit and vegetables with Phe ≤ 75 mg/100 g) and the remaining 20% of total protein was provided in the form of large neutral amino acid (LNAA) that reduces Phe accumulation in the brain by limiting its passage through the blood-brain barrier, competing for the same transporter.
>
> **[sec:2 ¶8]** Before reintroducing PKU medical nutrition therapy, to further stabilize post-prandial glucose,the patient was instructed to maintain a specific pre-bolus interval of 10 min when using ultra-rapid insulin and to include fiber-rich vegetables at each main meal to lower the overall glycemic index. The shift from fixed dosing to a personalized insulin-to-carbohydrate ratio (ICR), determined through a two-week glycemic-dietary diary, allowed for a more precise management of the glycemic load. This multidisciplinary approach resulted in a significant improvement in HbA1c (7.8% vs. 11.5% at baseline), Phe levels (705 µmol/L vs. Phe 842 µmol/L at baseline), and overall glycemic control over the first four months. At visit 4, CGM AGP confirmed this positive trend (Fig. 1b), with an improved Time in Range, reduced Time Above Range, and a lower mean glucose, without increasing hypoglycemia. At the same time, insulin requirement decreased from 0.55 IU/kg per day to 0.3 IU/kg per day.
>
> **[sec:2 ¶9]** In addition, the Glycemia Risk Index (GRI) improved from Zone E (high risk) to Zone B (low-intermediate risk), as shown in Fig. 1c. Of note, the improvement in GRI was concomitant with stably reduced Phe levels.
>
> **[sec:3 ¶1]** The coexistence of PKU and T1D represents clinical and nutritional challenges. This case report illustrates the inherent conflict between the dietary management of a disorder requiring protein restriction (PKU) and another disorder in which management of carbohydrate intake is key (T1D). Our experience aligns with the limited existing literature, which describes similar difficulties in maintaining metabolic control for both conditions simultaneously. A key apparent challenge was the patient’s behavioral response to the new T1D diagnosis, where the acute need to manage hyperglycemia led to a de-prioritization of the chronic, less symptomatic PKU dietary restrictions. A cornerstone of our intervention involved personalized therapeutic education, which focused on teaching the patient to incorporate carbohydrate counting into his PKU diet, and the introduction of modern medical foods, such as low-sugar SLPF and sugar-free formulas.
>
> **[sec:3 ¶2]** Living with chronic conditions has a significant emotional impact. It is well-known that individuals affected by chronic diseases like PKU and T1D are more susceptible to developing eating disorders, likely due to the lifelong adherence required for stringent dietary recommendations. Achieving therapeutic goals is indeed contingent on the patient’s adherence to the multiple and restrictive nutritional therapeutic recommendations that characterize both conditions (e.g., taking a protein substitute at least three times a day and insulin with every meal; sourcing special nutritional products and therapeutic aids; periodic clinical-laboratory monitoring). Therefore, it is fundamental to ensure these patients constant psychological support that should be offered through all phases of their lives, and particularly during the delicate phase of transition from pediatric care centers to adult care centers.
>
> **[sec:3 ¶3]** Recognizing the significant psychological impact of managing these two conditions, the patient was advised to pursue specialized psychological counseling. This recommendation was complemented by the multidisciplinary team’s strategy of providing intensive follow-up and constant clinical support, as an essential path for building a strong therapeutic alliance and empowering the patient in his daily self-care.
>
> **[sec:3 ¶5]** The coexistence of PKU and T1D in a young adult is a complex clinical challenge, requiring an integrated and personalized therapeutic approach (Fig. 2). This case highlights the importance of multidisciplinary management and CGM-driven insulin therapy and education to optimize metabolic control of both conditions and improve the patient’s quality of life.
>

## Diagnoses

- ✓ **FINAL** phenylketonuria (PKU) → phenylketonuria MONDO:0009861 OMIM:261600 · tier BIOCHEMICAL · route unknown  
  “A 27-year-old man with longstanding phenylketonuria was referred to an adult metabolic-diabetes center after the diagnosis of type 1 diabetes.” [abstract]
- ✓ **FINAL** type 1 diabetes (T1D) → type 1 diabetes mellitus MONDO:0005147 OMIM:222100 · tier BIOCHEMICAL · route symptomatic  
  “Laboratory results showed glycated hemoglobin (HbA1c) of 11.5%, C-peptide of 0.4 nmol/L, and positive anti-GAD autoantibodies (6.6 UA/mL; normal < 5 UA/mL, Insulin, IA2, and ZnT8 autoantibodies negative), confirming the diagnosis of T1D.” [sec:2 ¶3]
- ✓ **EXCLUDED** Diabetic ketoacidosis (DKA) → diabetic ketoacidosis   · tier BIOCHEMICAL · route –  
  “Diabetic ketoacidosis (DKA) was biochemically excluded at onset (based on pH, anion gap, and ketone levels), and no acute precipitating factors, such as infections, were identified.” [sec:2 ¶2]
- ✓ **EXCLUDED** Monogenic diabetes → monogenic diabetes MONDO:0015967  · tier MOLECULAR · route –  
  “Monogenic diabetes was also excluded through genetic testing of HNF4A, GCK, HNF1A, PDX1 AND HNF1B, which revealed no associated mutations.” [sec:2 ¶3]
- ✓ **EXCLUDED** thyroiditis → thyroiditis MONDO:0004126  · tier UNKNOWN · route –  
  “Autoimmunity screening was also performed for the main conditions typically associated with type 1 diabetes, such as thyroiditis and celiac disease, with negative results.” [sec:2 ¶3]
- ✓ **EXCLUDED** celiac disease → celiac disease MONDO:0005130  · tier UNKNOWN · route –  
  “Autoimmunity screening was also performed for the main conditions typically associated with type 1 diabetes, such as thyroiditis and celiac disease, with negative results.” [sec:2 ¶3]

## Genetic findings


## Measurements

| ✓ | analyte | specimen | value | unit | ref | interp | timing | quote [anchor] |
|---|---|---|---|---|---|---|---|---|
| ✓ | BMI → body mass index | other | 19.7 | kg/m² |  | UNKNOWN | at admission to adult center (December 2022) | “On examination, the patient had a BMI of 19.7 kg/m², normal blood pressure, and a normal ECG.” [sec:2 ¶3] |
| ✓ | glycated hemoglobin (HbA1c) → hemoglobin A1c | blood | 11.5 | % |  | HIGH | at diagnosis of T1D / baseline (admission December 2022) | “Laboratory results showed glycated hemoglobin (HbA1c) of 11.5%, C-peptide of 0.4 nmol/L, and positive anti-GAD autoantib” [sec:2 ¶3] |
| ✓ | C-peptide → C-peptide | unknown | 0.4 | nmol/L |  | LOW | at diagnosis of T1D / baseline (admission December 2022) | “Laboratory results showed glycated hemoglobin (HbA1c) of 11.5%, C-peptide of 0.4 nmol/L, and positive anti-GAD autoantib” [sec:2 ¶3] |
| ✓ | anti-GAD autoantibodies → anti-glutamic acid decarboxylase autoantibodies | unknown | 6.6 | UA/mL | normal < 5 UA/mL | HIGH | at diagnosis of T1D / baseline (admission December 2022) | “Laboratory results showed glycated hemoglobin (HbA1c) of 11.5%, C-peptide of 0.4 nmol/L, and positive anti-GAD autoantib” [sec:2 ¶3] |
| ✓ | Insulin autoantibodies → insulin autoantibodies | unknown | negative |  |  | NORMAL | at diagnosis of T1D / baseline (admission December 2022) | “Laboratory results showed glycated hemoglobin (HbA1c) of 11.5%, C-peptide of 0.4 nmol/L, and positive anti-GAD autoantib” [sec:2 ¶3] |
| ✓ | IA2 autoantibodies → islet antigen-2 (IA-2) autoantibodies | unknown | negative |  |  | NORMAL | at diagnosis of T1D / baseline (admission December 2022) | “Laboratory results showed glycated hemoglobin (HbA1c) of 11.5%, C-peptide of 0.4 nmol/L, and positive anti-GAD autoantib” [sec:2 ¶3] |
| ✓ | ZnT8 autoantibodies → zinc transporter 8 (ZnT8) autoantibodies | unknown | negative |  |  | NORMAL | at diagnosis of T1D / baseline (admission December 2022) | “Laboratory results showed glycated hemoglobin (HbA1c) of 11.5%, C-peptide of 0.4 nmol/L, and positive anti-GAD autoantib” [sec:2 ¶3] |
| ✓ | serial phenylalanine (Phe) levels → L-phenylalanine | unknown | consistently above recommended targets | µmol/L | normal range 120–600 µmol/L | HIGH | serial levels before/at transfer to adult center | “The patient’s PKU management was suboptimal, with serial phenylalanine (Phe) levels (normal range 120–600 µmol/L) and Ph” [sec:2 ¶4] |
| ✓ | Phe/Tyr ratios → phenylalanine/tyrosine ratio | unknown | consistently above recommended targets |  |  | HIGH | serial levels before/at transfer to adult center | “The patient’s PKU management was suboptimal, with serial phenylalanine (Phe) levels (normal range 120–600 µmol/L) and Ph” [sec:2 ¶4] |
| ✓ | Phe → L-phenylalanine | unknown | 842 | µmol/L | normal range 120–600 µmol/L | HIGH | first follow-up visit (baseline for intervention) | “this resulted in an increased dietary phenylalanine intake and consequently elevated phenylalanine levels (Phe 842 µmol/” [sec:2 ¶5] |
| ✓ | Time in Range (70–180 mg/dL) → CGM time in range 70–180 mg/dL | other | 16 | % |  | LOW | initial CGM report, March-April 2023 (visit 1) | “The report from March-April 2023 indicates a Time in Range (70–180 mg/dL) of only 16%, with 31% of TAR level 1 and 52% o” [sec:2 ¶6] |
| ✓ | TAR level 1 → CGM time above range level 1 | other | 31 | % |  | HIGH | initial CGM report, March-April 2023 (visit 1) | “The report from March-April 2023 indicates a Time in Range (70–180 mg/dL) of only 16%, with 31% of TAR level 1 and 52% o” [sec:2 ¶6] |
| ✓ | TAR level 2 → CGM time above range level 2 | other | 52 | % |  | HIGH | initial CGM report, March-April 2023 (visit 1) | “The report from March-April 2023 indicates a Time in Range (70–180 mg/dL) of only 16%, with 31% of TAR level 1 and 52% o” [sec:2 ¶6] |
| ✓ | mean glucose → glucose (CGM mean) | other | 257 | mg/dL |  | HIGH | initial CGM report, March-April 2023 (visit 1) | “The report from March-April 2023 indicates a Time in Range (70–180 mg/dL) of only 16%, with 31% of TAR level 1 and 52% o” [sec:2 ¶6] |
| ✓ | Glycemia Risk Index (GRI) → Glycemia Risk Index | other | Zone E (high hyperglycemia risk) |  |  | HIGH | visit 1 | “The patient’s profile moved from Zone E (visit 1, high hyperglycemia risk) to Zone B (visit 4, lower risk), indicating a” [sec:2 ¶6] |
| ✓ | HbA1c → hemoglobin A1c | blood | 7.8 | % |  | HIGH | after the first four months of the multidisciplinary intervention (visit 4) | “This multidisciplinary approach resulted in a significant improvement in HbA1c (7.8% vs. 11.5% at baseline), Phe levels ” [sec:2 ¶8] |
| ✓ | Phe levels → L-phenylalanine | unknown | 705 | µmol/L | normal range 120–600 µmol/L | HIGH | after the first four months of the multidisciplinary intervention (visit 4) | “This multidisciplinary approach resulted in a significant improvement in HbA1c (7.8% vs. 11.5% at baseline), Phe levels ” [sec:2 ¶8] |
| ✓ | Time in Range → CGM time in range 70–180 mg/dL | other | 63 | % |  | LOW | follow-up CGM report, July-August 2023 (visit 4) | “The report from July-August 2023 shows significant improvements, with Time in Range increasing to 63%, mean glucose redu” [sec:2 ¶6] |
| ✓ | mean glucose → glucose (CGM mean) | other | 164 | mg/dL |  | HIGH | follow-up CGM report, July-August 2023 (visit 4) | “The report from July-August 2023 shows significant improvements, with Time in Range increasing to 63%, mean glucose redu” [sec:2 ¶6] |
| ✓ | glucose variability → CGM glucose variability (coefficient of variation) | other | 33.5 | % |  | UNKNOWN | follow-up CGM report, July-August 2023 (visit 4) | “The report from July-August 2023 shows significant improvements, with Time in Range increasing to 63%, mean glucose redu” [sec:2 ¶6] |
| ✓ | Glycemia Risk Index (GRI) → Glycemia Risk Index | other | Zone B (low-intermediate risk) |  |  | UNKNOWN | visit 4 | “In addition, the Glycemia Risk Index (GRI) improved from Zone E (high risk) to Zone B (low-intermediate risk), as shown ” [sec:2 ¶9] |

## Phenotypes

- ✓ Hyperglycemia → Hyperglycemia HP:0003074 (grounded)  
  “In November 2022, the patient presented to the Emergency Room with occasional hyperglycemia and weight loss.” [sec:2 ¶2]
- ✓ Weight loss → Weight loss HP:0001824 (grounded)  
  “In November 2022, the patient presented to the Emergency Room with occasional hyperglycemia and weight loss.” [sec:2 ¶2]
- ✓ NOT Diabetic ketoacidosis → Diabetic ketoacidosis HP:0001953 (grounded)  
  “Diabetic ketoacidosis (DKA) was biochemically excluded at onset (based on pH, anion gap, and ketone levels), and no acute precipitating factors, such as infections, were identified.” [sec:2 ¶2]
- ✓ Type I diabetes mellitus → Type I diabetes mellitus HP:0100651 (grounded)  
  “Laboratory results showed glycated hemoglobin (HbA1c) of 11.5%, C-peptide of 0.4 nmol/L, and positive anti-GAD autoantibodies (6.6 UA/mL; normal < 5 UA/mL, Insulin, IA2, and ZnT8 autoantibodies negative), confirming the diagnosis of T1D.” [sec:2 ¶3]
- ✓ NOT Abnormal blood pressure → –  (candidate)  
  “On examination, the patient had a BMI of 19.7 kg/m², normal blood pressure, and a normal ECG.” [sec:2 ¶3]
- ✓ NOT Abnormal EKG → Abnormal EKG HP:0003115 (grounded)  
  “On examination, the patient had a BMI of 19.7 kg/m², normal blood pressure, and a normal ECG.” [sec:2 ¶3]
- ✓ Elevated hemoglobin A1c → Elevated hemoglobin A1c HP:0040217 (grounded)  
  “Laboratory results showed glycated hemoglobin (HbA1c) of 11.5%, C-peptide of 0.4 nmol/L, and positive anti-GAD autoantibodies (6.6 UA/mL; normal < 5 UA/mL, Insulin, IA2, and ZnT8 autoantibodies negative), confirming the diagnosis of T1D.” [sec:2 ¶3]
- ✓ Decreased circulating C-peptide level → –  (candidate)  
  “At diagnosis, HbA1c was 11.5%, with markedly reduced C-peptide levels and high titer anti-GAD antibodies.” [abstract]
- ✓ Anti-glutamic acid decarboxylase antibody positivity → Anti-glutamic acid decarboxylase antibody positivity HP:0025329 (grounded)  
  “At diagnosis, HbA1c was 11.5%, with markedly reduced C-peptide levels and high titer anti-GAD antibodies.” [abstract]
- ✓ NOT Autoimmune thyroiditis → –  (candidate)  
  “Autoimmunity screening was also performed for the main conditions typically associated with type 1 diabetes, such as thyroiditis and celiac disease, with negative results.” [sec:2 ¶3]
- ✓ NOT Celiac disease → Celiac disease HP:0002608 (grounded)  
  “Autoimmunity screening was also performed for the main conditions typically associated with type 1 diabetes, such as thyroiditis and celiac disease, with negative results.” [sec:2 ¶3]
- ✓ Hyperphenylalaninemia → Hyperphenylalaninemia HP:0004923 (grounded)  
  “The patient’s PKU management was suboptimal, with serial phenylalanine (Phe) levels (normal range 120–600 µmol/L) and Phe/Tyr ratios consistently above recommended targets.” [sec:2 ¶4]
- ✓ Hyperintensity of cerebral white matter on MRI → Hyperintensity of cerebral white matter on MRI HP:0030890 (grounded)  
  “a brain MRI indicated signs of metabolic accumulation distress, characterized by white matter hyperintensities typically associated with chronic elevation of brain phenylalanine levels” [sec:2 ¶5]

## Treatments

- ✓ drug: insulin (multiple daily injections, fixed doses) · response no_response  
  “T1D was suspected, and insulin therapy with multiple daily injections was initiated.” [sec:2 ¶2]
- ✓ diet: low-phenylalanine PKU diet · response no_response  
  “Initially, the patient was advised to follow the PKU diet and was prescribed a continuous glucose monitoring (CGM) system.” [sec:2 ¶4]
- ✓ supportive: continuous glucose monitoring · response not_stated  
  “Initially, the patient was advised to follow the PKU diet and was prescribed a continuous glucose monitoring (CGM) system.” [sec:2 ¶4]
- ✓ drug: insulin (dynamic regimen, insulin-to-carbohydrate ratio, carbohydrate counting) · response improved  
  “To address these challenges, the patient was transitioned from fixed insulin doses to a dynamic regimen. He was educated on “Carbohydrate Counting” specifically adjusted for PKU-specific medical products.” [sec:2 ¶7]
- ✓ drug: ultra-rapid insulin (10-min pre-bolus) plus fiber-rich vegetables · response improved  
  “the patient was instructed to maintain a specific pre-bolus interval of 10 min when using ultra-rapid insulin and to include fiber-rich vegetables at each main meal to lower the overall glycemic index.” [sec:2 ¶8]
- ✓ diet: PKU-adapted low-phenylalanine diet with special low-protein foods and phenylalanine-free amino acid supplements · response improved  
  “A new PKU-adapted diet was prescribed, featuring special low-protein foods (SLPF) low in refined sugars and maltodextrins and with phe-free aminoacid supplements without added sugars.” [sec:2 ¶7]
- ✓ diet: large neutral amino acids (LNAA) · response not_stated  
  “the remaining 20% of total protein was provided in the form of large neutral amino acid (LNAA) that reduces Phe accumulation in the brain by limiting its passage through the blood-brain barrier, competing for the same transporter.” [sec:2 ¶7]
- ✓ supportive: psychological counseling · response not_stated  
  “Recognizing the significant psychological impact of managing these two conditions, the patient was advised to pursue specialized psychological counseling.” [sec:3 ¶3]

## Outcome

Over the first four months of multidisciplinary management, HbA1c improved from 11.5% to 7.8%, Phe levels decreased from 842 to 705 µmol/L (still above the 120–600 µmol/L range), insulin requirement declined from 0.55 to 0.3 IU/kg/day, CGM Time in Range rose from 16% to 63% with mean glucose falling from 257 to 164 mg/dL without increased hypoglycemia, and the Glycemia Risk Index moved from Zone E (high risk) to Zone B (low-intermediate risk). The patient was alive and in follow-up at the adult center.

## Model summary (not source text)

A 27-year-old man with longstanding phenylketonuria, previously followed at a pediatric center, presented in November 2022 with occasional hyperglycemia and weight loss; diabetic ketoacidosis was biochemically excluded and insulin therapy with multiple daily injections was started. At admission to the adult metabolic-diabetes center (December 2022) he had a BMI of 19.7 kg/m², normal blood pressure and ECG, HbA1c 11.5%, C-peptide 0.4 nmol/L and positive anti-GAD autoantibodies (6.6 UA/mL; normal < 5) with negative insulin, IA2 and ZnT8 autoantibodies, confirming type 1 diabetes; genetic testing of HNF4A, GCK, HNF1A, PDX1 and HNF1B was negative and autoimmunity screening for thyroiditis and celiac disease was negative. PKU control was suboptimal with serial phenylalanine levels (normal range 120–600 µmol/L) and Phe/Tyr ratios above target; at the first follow-up, CGM showed poor glycemic control (Time in Range 16%, mean glucose 257 mg/dL), diet adherence was inadequate with Phe 842 µmol/L, and brain MRI showed white matter hyperintensities attributed to chronic phenylalanine elevation. Management was changed to a dynamic insulin regimen with carbohydrate counting and a PKU-adapted medical nutrition therapy (500 mg/day Phe, protein 1 g/kg/day, low-sugar special low-protein foods, sugar-free Phe-free amino acid supplements and LNAA). Over four months HbA1c fell to 7.8%, Phe to 705 µmol/L, insulin requirement from 0.55 to 0.3 IU/kg/day, Time in Range rose to 63% with mean glucose 164 mg/dL, and the Glycemia Risk Index improved from Zone E to Zone B.

## Extractor notes

- Specimen for phenylalanine, Phe/Tyr ratio, C-peptide and autoantibody measurements is not stated (recorded as 'unknown'); HbA1c recorded as 'blood'. CGM metrics (Time in Range, TAR, mean glucose, glucose variability, GRI) are interstitial-glucose-derived and recorded with specimen 'other'.
- The phenylalanine 'normal range 120–600 µmol/L' given in [sec:2 ¶4] is applied as the reference range to all Phe values; the abstract writes the same values as '842 to 705 μmol/L' (Greek mu) while the body uses the micro sign.
- Follow-up values (HbA1c 7.8%, Time in Range 63%, mean glucose 164 mg/dL) are reported by the authors only as 'improved'; interpretation HIGH/LOW was assigned because they remain outside usual targets (Phe 705 µmol/L is above the stated range). Glucose variability 33.5% ('stable') and GRI Zone B are left UNKNOWN. BMI 19.7 kg/m² is not interpreted by the authors.
- Insulin requirement 0.55 -> 0.3 IU/kg/day is a treatment dose, captured in the insulin treatment response_text rather than as a measurement.
- DKA was 'biochemically excluded' on pH, anion gap and ketone levels but no values are reported, so these were not entered as measurements.
- Negative genetic testing of HNF4A, GCK, HNF1A, PDX1 and HNF1B (monogenic diabetes panel) is recorded as an EXCLUDED diagnosis with MOLECULAR tier rather than as genetic_findings rows, to avoid representing absent variants as variants; this triggers the validator's 'MOLECULAR tier without genetic findings' warning by design. No PAH genotype, enzyme assay or PKU diagnostic history is given; PKU tier set to BIOCHEMICAL on the basis of the reported hyperphenylalaninemia, diagnostic route unknown.
- Age at T1D diagnosis P27Y is taken from the abstract/case presentation describing a 27-year-old who 'recently developed T1D' (diagnosis November 2022, admission December 2022); age at PKU onset/diagnosis and age at last follow-up are not stated. Country of care not stated in the text.
- Type 1 diabetes is outside the run's disease scope (inborn errors of metabolism) but is the co-occurring FINAL diagnosis driving the report; T1D-related phenotypes and labs are extracted because they belong to this individual.