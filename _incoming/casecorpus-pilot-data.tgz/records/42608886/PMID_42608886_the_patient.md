# PMID_42608886_the_patient
**Source:** PMID 42608886 · The American journal of case reports 2026 · DOI 10.12659/ajcr.952758 · licence: None · tier: epmc
**Individual:** the patient · sex FEMALE · onset – · presentation P71Y (71-year-old (described as 'a woman in her 70s' in the case report)) · last follow-up P71Y (71-year-old, after 9-year follow-up) · ALIVE
**Evidence verification:** 68/130 quotes found in their anchored unit, 130/130 anywhere in the document; narrative source: manifest

## Patient description (verbatim from the source, by anchor)

> **[abstract]** Background: Fabry disease (FD) is a rare X-linked lysosomal disorder in which long-term cardiac outcomes, particularly in heterozygous females, remain incompletely defined. The N224S α-galactosidase A gene (GLA) variant is recognized as pathogenic, yet its cardiac phenotype and response to prolonged migalastat therapy are not well characterized. Although clinical trials and observational studies have reported variable cardiac responses to migalastat, real-world longitudinal data beyond 5 years remain limited. Understanding long-term structural and functional changes is especially important in patients with pre-existing cardiac involvement, where distinguishing favorable remodeling from fibrosis-related progression can be challenging.
Case Report: We describe a 9-year follow-up of a 71-year-old heterozygous woman with FD due to the N224S mutation treated with migalastat. Serial transthoracic echocardiography demonstrated a sustained reduction in left ventricular mass index (LVMI) over long-term therapy. Left ventricular systolic function remained preserved throughout follow-up, and there was no evidence of progressive structural deterioration. Available Doppler-derived diastolic indices, including a gradual decline in early diastolic mitral inflow velocity to early diastolic mitral annular velocity (E/e’), suggested improving left ventricular filling pressures over time. Although LVMI showed minor year-to-year variability, these changes were consistent with expected technical or physiological variation and did not alter the clear long-term downward trend.
Conclusions: This case provides real-world evidence of favorable long-term cardiac remodeling during migalastat therapy in a heterozygous woman with the N224S variant. The sustained reduction in LVMI, preserved systolic function, and improving diastolic indices together indicate a durable cardiac response and extend the limited longitudinal data available for variant-specific outcomes in FD.
>
> **[sec:2 ¶1]** A woman in her 70s with FD—reflecting a heterozygous phenotype influenced by X-chromosome inactivation—was diagnosed in 1995 by genetic testing, identifying a heterozygous N224S missense mutation (c.671A>G), following evaluation of her son with classic FD on enzyme replacement therapy (ERT). She had recurrent emergency presentations with central chest pain at rest, occasionally with dyspnea and diaphoresis. Exercise tolerance was 400 to 500 m on flat ground. She remained independent in activities of daily living, with mild orthopnea and no paroxysmal nocturnal dyspnea.
>
> **[sec:2 ¶2]** Comorbidities included atrial fibrillation, hypertension, hyperlipidaemia, and type 2 diabetes mellitus. An implantable cardioverter-defibrillator (ICD) (Boston Scientific D177) was inserted for non-sustained ventricular tachycardia in the setting of LVH. Medications included candesartan 16 mg once a day, atenolol 50 mg twice a day, rivaroxaban 20 mg once a day, metformin 1 g twice a day, frusemide 40 mg once a day, ezetimibe 10 mg once a day, perindopril 5 mg once a day, and migalastat 123 mg a day, commenced in 2016. She remained on long-term diuretics and a 1.5-L fluid restriction for prior pericardial effusion. There was no family history of premature coronary disease or LVH phenocopies.
>
> **[sec:2 ¶3]** A recent examination revealed the following: BP 122/92 mm Hg, HR 74 bpm, SpO2 97%, RR 18/min, and temperature 36.7°C. Her chest was clear, with dual heart sounds and no murmurs or heart failure signs. ECG showed AF with LVH (Figure 1). Laboratory test results showed high-sensitivity troponin I 1857 ng/L, B-type natriuretic peptide 202 ng/L, creatinine 89 μmol/L, and estimated glomerular filtration rate 57 mL/min/1.73 m2. A chest X-ray (Figure 2) was unremarkable. ICD interrogation was normal with no recent therapies.
>
> **[sec:2 ¶4]** High-sensitivity troponins remained moderately elevated with stable serial trends over 12 months. Heterophile antibody screen was negative, and renal function remained stable. The last cardiac magnetic resonance (CMR) imaging in 2013 showed asymmetric septal hypertrophy with increased left ventricle mass (83 g/m2), and subtle plexiform enhancement in the basal septum and basal inferolateral segments.
>
> **[sec:2 ¶5]** The most recent TTE showed a small LV with EF 60% and concentric wall thickening from base to apex, without systolic anterior motion of mitral valve (SAM), mid-cavity, or left ventricle outflow tract (LVOT) obstruction. Right ventricle (RV) size was normal, with RV systolic pressure 21 mm Hg. A small circumferential pericardial effusion was present without tamponade. No significant valvular disease was seen. Overall, serial left ventricular mass index (LVMI) over 9 years (Table 1) demonstrated an overall decline, accompanied by a reduction in available ratio of early diastolic mitral inflow velocity to early diastolic mitral annular velocity (E/e’) measurements in later years. A line plot of LVMI over time shows an overall downward trend, with the regression line demonstrating a significant negative decline (slope −6.52 g/m2 per year, 95% CI −11.3 to −1.7, P = 0.015) (Figure 3). Given the single-patient design, this analysis is descriptive and intended mainly to illustrate longitudinal trajectory. Representative TTE images are shown in Figure 4, with 2021 omitted due to COVID-19–related risk. Routine coronary angiography showed normal coronaries, unchanged from 9 years prior.
>
> **[sec:2 ¶6]** During an episode of chest pain, she was treated as acute coronary syndrome with dual antiplatelet therapy for elevated high-sensitivity troponin I; the chronic elevation was later attributed to stable FD-related microvascular ischemia. LVH was initially attributed to hypertension but was excluded given good adherence and sustained systolic BP ~ 125 mm Hg on clinic and home monitoring. Aortic stenosis was excluded, with serial TTEs showing stable mild aortic sclerosis. Alternative LVH phenocopies were considered. Cardiac amyloidosis was unlikely due to absence of typical echocardiographic features (elevated RV pressure, apical sparing, biventricular hypertrophy, valve thickening; sensitivity 93%, specificity 82%) [4]. Hypertrophic cardiomyopathy was excluded due to lack of asymmetric hypertrophy, SAM, syncope, or family history. Prior CMR showed no features of either condition. The concentric LVH was therefore attributed to FD.
>
> **[sec:3 ¶2]** Evidence from randomized trials and observational cohorts, including FACETS, ATTRACT, FAMOUS, and MAIORA, demonstrates that migalastat can reduce or stabilize LVH in amenable FD, but these studies are limited to 12 to 24 months of follow-up [7–10]. This case report extends the existing literature by providing a 9-year longitudinal trajectory in a heterozygous woman with the amenable N224S mutation, a variant with limited phenotype and treatment response data. Longer term imaging studies, such as the CMR based cohort by Gatterer et al, report follow up of approximately 3 to 5 years and predominantly describe stabilization rather than regression of cardiac parameters [11]. In contrast, our patient demonstrated sustained LVMI reduction with preserved systolic function and a gradual improvement in diastolic indices. An exploratory linear regression supported the overall downward trajectory in LVMI over time, although the mechanism underlying this change cannot be definitively established. The combination of prolonged follow up, variant specific detail, and dense serial echocardiographic measurements offers novel real world insight into long term cardiac response to migalastat.
>
> **[sec:3 ¶3]** Over 9 years, the patient demonstrated a significant reduction in LVMI despite relative plateauing between 2018 and 2024, followed by a further decline to 97.30 g/m2 in 2025. This pattern may reflect variability inherent to two-dimensional TTE but may also represent underlying pathophysiological processes. Notably, increased LVMI and myocardial fibrosis despite migalastat therapy have been reported in a small cohort by Gatterer et al, possibly related to persistent glycosphingolipid-driven inflammation [11]. Similar findings have been described in a subset of male patients receiving ERT by Cabrera et al, highlighting the heterogeneity of disease progression in FD [12].
>
> **[sec:3 ¶4]** A key consideration in interpreting the observed reduction in wall thickness is whether it reflects true regression of hypertrophy or a decrease in myocardial matrix—specifically, replacement of hypertrophied myocytes by fibrotic extracellular matrix. In FD, progressive matrix expansion and interstitial fibrosis can coexist with or replace hypertrophy and, in advanced stages, can result in apparent wall thinning despite ongoing pathological remodeling [13]. CMR, particularly with late gadolinium enhancement and T1 mapping, can help to distinguish these processes, but such data were not available in this case. However, the pattern observed—a sustained reduction in LVMI, stable LV cavity size without progressive dilatation, a gradual decline in E/e’, and preserved systolic function—is not typical of matrix-driven wall thinning or advanced fibrotic remodeling, which generally increase diastolic stiffness. While the underlying mechanism cannot be definitively established, these findings are more consistent with favorable remodeling and possible regression of hypertrophy during long-term migalastat therapy.
>
> **[sec:4 ¶1]** This case illustrates sustained cardiac benefit during long-term migalastat therapy in a woman heterozygote with an amenable FD mutation. Over 9 years, LVMI declined, systolic function remained preserved, and comorbidities were well controlled. Minor fluctuations in LVMI likely reflected technical or physiological variation and did not alter the overall downward trajectory. Improvements in available diastolic indices further suggest favorable changes in left ventricular filling pressures over time. Collectively, these findings indicate a durable long-term cardiac response to migalastat and contribute real-world evidence to the limited longitudinal data available in FD.
>
> **[tab:1 r1]** Year | Ejection fraction | Left ventricular mass index (LVMI) (g/m2) | Body surface srea (m2) | Left ventricular end-diastolic diameter (LVEDD) (mm) | Interventricular septal end-diastole (IVSd) thickness (mm) | Posterior wall thickness at end-diastole (PWd) thickness (mm) | Ratio of early mitral inflow velocity to early diastolic tissue velocity (E/e’)*
>
> **[tab:1 r2]** 2016 | 71% | 176.20 | 1.90 | 36.3 | 19.9 | 20.4 | 24.5
>
> **[tab:1 r3]** 2017 | 73% | 136.88 | 1.95 | 33.1 | 19.4 | 17.7 | 25.4
>
> **[tab:1 r4]** 2018 | 67% | 145.98 | 1.99 | 36.9 | 18.8 | 17.9 | –
>
> **[tab:1 r5]** 2019 | 71% | 155.10 | 1.99 | 33.7 | 21.4 | 19.1 | –
>
> **[tab:1 r6]** 2020 | 65% | 163.35 | 2.00 | 38.2 | 19.6 | 18.7 | 28.2
>
> **[tab:1 r7]** 2022 | 66% | 145.45 | 1.90 | 40.0 | 18.1 | 15.3 | –
>
> **[tab:1 r8]** 2023 | 65% | 131.30 | 1.90 | 38.6 | 17.3 | 15.0 | 17.5
>
> **[tab:1 r9]** 2024 | 55% | 146.65 | 1.76 | 43.0 | 15.0 | 15.0 | 15.4
>
> **[tab:1 r10]** 2025 | 60% | 97.30 | 1.84 | 38.7 | 14.8 | 10.8 | –
>

## Diagnoses

- ✓ **FINAL** Fabry disease (heterozygous female, GLA N224S) → Fabry disease MONDO:0010526 OMIM:301500 · tier MOLECULAR · route family_screening  
  “A woman in her 70s with FD—reflecting a heterozygous phenotype influenced by X-chromosome inactivation—was diagnosed in 1995 by genetic testing, identifying a heterozygous N224S missense mutation (c.671A>G), following evaluation of her son with classic FD on enzyme replacement therapy (ERT).” [sec:2 ¶1]
- ✓ **REVISED_FROM** Acute coronary syndrome → acute coronary syndrome MONDO:0005542  · tier CLINICAL · route –  
  “During an episode of chest pain, she was treated as acute coronary syndrome with dual antiplatelet therapy for elevated high-sensitivity troponin I; the chronic elevation was later attributed to stable FD-related microvascular ischemia.” [sec:2 ¶6]
- ✓ **REVISED_FROM** Hypertensive left ventricular hypertrophy → Hypertensive left ventricular hypertrophy   · tier CLINICAL · route –  
  “LVH was initially attributed to hypertension but was excluded given good adherence and sustained systolic BP ~ 125 mm Hg on clinic and home monitoring.” [sec:2 ¶6]
- ✓ **EXCLUDED** Aortic stenosis → aortic valve stenosis MONDO:0042981  · tier CLINICAL · route –  
  “Aortic stenosis was excluded, with serial TTEs showing stable mild aortic sclerosis.” [sec:2 ¶6]
- ✓ **DIFFERENTIAL** Cardiac amyloidosis → Cardiac amyloidosis   · tier CLINICAL · route –  
  “Cardiac amyloidosis was unlikely due to absence of typical echocardiographic features (elevated RV pressure, apical sparing, biventricular hypertrophy, valve thickening; sensitivity 93%, specificity 82%) [4].” [sec:2 ¶6]
- ✓ **EXCLUDED** Hypertrophic cardiomyopathy → hypertrophic cardiomyopathy MONDO:0005045  · tier CLINICAL · route –  
  “Hypertrophic cardiomyopathy was excluded due to lack of asymmetric hypertrophy, SAM, syncope, or family history.” [sec:2 ¶6]

## Genetic findings

- ✓ **GLA** c.671A>G p.Asn224Ser · HETEROZYGOUS · pathogenic · genetic testing (method not specified)  
  “A woman in her 70s with FD—reflecting a heterozygous phenotype influenced by X-chromosome inactivation—was diagnosed in 1995 by genetic testing, identifying a heterozygous N224S missense mutation (c.671A>G), following evaluation of her son with classic FD on enzyme replacement therapy (ERT).” [sec:2 ¶1]

## Measurements

| ✓ | analyte | specimen | value | unit | ref | interp | timing | quote [anchor] |
|---|---|---|---|---|---|---|---|---|
| ✓ | high-sensitivity troponin I | blood | 1857 | ng/L |  | HIGH | recent examination | “Laboratory test results showed high-sensitivity troponin I 1857 ng/L, B-type natriuretic peptide 202 ng/L, creatinine 89” [sec:2 ¶3] |
| ✓ | high-sensitivity troponin I (serial) | blood | moderately elevated with stable serial trends over 12 months |  |  | HIGH | serial over 12 months | “High-sensitivity troponins remained moderately elevated with stable serial trends over 12 months.” [sec:2 ¶4] |
| ✓ | B-type natriuretic peptide | blood | 202 | ng/L |  | UNKNOWN | recent examination | “Laboratory test results showed high-sensitivity troponin I 1857 ng/L, B-type natriuretic peptide 202 ng/L, creatinine 89” [sec:2 ¶3] |
| ✓ | creatinine → creatinine | blood | 89 | μmol/L |  | UNKNOWN | recent examination | “Laboratory test results showed high-sensitivity troponin I 1857 ng/L, B-type natriuretic peptide 202 ng/L, creatinine 89” [sec:2 ¶3] |
| ✓ | estimated glomerular filtration rate | blood | 57 | mL/min/1.73 m2 |  | UNKNOWN | recent examination | “Laboratory test results showed high-sensitivity troponin I 1857 ng/L, B-type natriuretic peptide 202 ng/L, creatinine 89” [sec:2 ¶3] |
| ✓ | Heterophile antibody screen | blood | negative |  |  | NORMAL |  | “Heterophile antibody screen was negative, and renal function remained stable.” [sec:2 ¶4] |
| ✓ | Blood pressure | other | 122/92 | mm Hg |  | UNKNOWN | recent examination | “A recent examination revealed the following: BP 122/92 mm Hg, HR 74 bpm, SpO2 97%, RR 18/min, and temperature 36.7°C.” [sec:2 ¶3] |
| ✓ | Heart rate | other | 74 | bpm |  | UNKNOWN | recent examination | “A recent examination revealed the following: BP 122/92 mm Hg, HR 74 bpm, SpO2 97%, RR 18/min, and temperature 36.7°C.” [sec:2 ¶3] |
| ✓ | SpO2 | other | 97 | % |  | UNKNOWN | recent examination | “A recent examination revealed the following: BP 122/92 mm Hg, HR 74 bpm, SpO2 97%, RR 18/min, and temperature 36.7°C.” [sec:2 ¶3] |
| ✓ | Respiratory rate | other | 18 | /min |  | UNKNOWN | recent examination | “A recent examination revealed the following: BP 122/92 mm Hg, HR 74 bpm, SpO2 97%, RR 18/min, and temperature 36.7°C.” [sec:2 ¶3] |
| ✓ | Temperature | other | 36.7 | °C |  | UNKNOWN | recent examination | “A recent examination revealed the following: BP 122/92 mm Hg, HR 74 bpm, SpO2 97%, RR 18/min, and temperature 36.7°C.” [sec:2 ¶3] |
| ✓ | Systolic blood pressure (clinic and home monitoring) | other | 125 | mm Hg |  | NORMAL | sustained, on antihypertensive treatment | “LVH was initially attributed to hypertension but was excluded given good adherence and sustained systolic BP ~ 125 mm Hg” [sec:2 ¶6] |
| ✓ | Left ventricle mass (cardiac MRI) | other | 83 | g/m2 |  | HIGH | 2013 | “The last cardiac magnetic resonance (CMR) imaging in 2013 showed asymmetric septal hypertrophy with increased left ventr” [sec:2 ¶4] |
| ✓ | Left ventricular ejection fraction (TTE) | other | 60 | % |  | NORMAL | most recent TTE | “The most recent TTE showed a small LV with EF 60% and concentric wall thickening from base to apex, without systolic ant” [sec:2 ¶5] |
| ✓ | Right ventricular systolic pressure (TTE) | other | 21 | mm Hg |  | NORMAL | most recent TTE | “Right ventricle (RV) size was normal, with RV systolic pressure 21 mm Hg.” [sec:2 ¶5] |
| ~ | Ejection fraction (TTE) | other | 71.0 | % |  | NORMAL | annual TTE, 2016 | “/ r2 / 2016 / 71% / 176.20 / 1.90 / 36.3 / 19.9 / 20.4 / 24.5 /” [tab:1 r2c2] |
| ~ | Left ventricular mass index (LVMI) (TTE) | other | 176.2 | g/m2 |  | HIGH | annual TTE, 2016 | “/ r2 / 2016 / 71% / 176.20 / 1.90 / 36.3 / 19.9 / 20.4 / 24.5 /” [tab:1 r2c3] |
| ~ | Body surface area | other | 1.9 | m2 |  | UNKNOWN | annual TTE, 2016 | “/ r2 / 2016 / 71% / 176.20 / 1.90 / 36.3 / 19.9 / 20.4 / 24.5 /” [tab:1 r2c4] |
| ~ | Left ventricular end-diastolic diameter (LVEDD) (TTE) | other | 36.3 | mm |  | UNKNOWN | annual TTE, 2016 | “/ r2 / 2016 / 71% / 176.20 / 1.90 / 36.3 / 19.9 / 20.4 / 24.5 /” [tab:1 r2c5] |
| ~ | Interventricular septal end-diastole (IVSd) thickness (TTE) | other | 19.9 | mm |  | HIGH | annual TTE, 2016 | “/ r2 / 2016 / 71% / 176.20 / 1.90 / 36.3 / 19.9 / 20.4 / 24.5 /” [tab:1 r2c6] |
| ~ | Posterior wall thickness at end-diastole (PWd) (TTE) | other | 20.4 | mm |  | HIGH | annual TTE, 2016 | “/ r2 / 2016 / 71% / 176.20 / 1.90 / 36.3 / 19.9 / 20.4 / 24.5 /” [tab:1 r2c7] |
| ~ | Ratio of early mitral inflow velocity to early diastolic tissue velocity (E/e’) (TTE) | other | 24.5 |  |  | UNKNOWN | annual TTE, 2016 | “/ r2 / 2016 / 71% / 176.20 / 1.90 / 36.3 / 19.9 / 20.4 / 24.5 /” [tab:1 r2c8] |
| ~ | Ejection fraction (TTE) | other | 73.0 | % |  | NORMAL | annual TTE, 2017 | “/ r3 / 2017 / 73% / 136.88 / 1.95 / 33.1 / 19.4 / 17.7 / 25.4 /” [tab:1 r3c2] |
| ~ | Left ventricular mass index (LVMI) (TTE) | other | 136.88 | g/m2 |  | HIGH | annual TTE, 2017 | “/ r3 / 2017 / 73% / 136.88 / 1.95 / 33.1 / 19.4 / 17.7 / 25.4 /” [tab:1 r3c3] |
| ~ | Body surface area | other | 1.95 | m2 |  | UNKNOWN | annual TTE, 2017 | “/ r3 / 2017 / 73% / 136.88 / 1.95 / 33.1 / 19.4 / 17.7 / 25.4 /” [tab:1 r3c4] |
| ~ | Left ventricular end-diastolic diameter (LVEDD) (TTE) | other | 33.1 | mm |  | UNKNOWN | annual TTE, 2017 | “/ r3 / 2017 / 73% / 136.88 / 1.95 / 33.1 / 19.4 / 17.7 / 25.4 /” [tab:1 r3c5] |
| ~ | Interventricular septal end-diastole (IVSd) thickness (TTE) | other | 19.4 | mm |  | HIGH | annual TTE, 2017 | “/ r3 / 2017 / 73% / 136.88 / 1.95 / 33.1 / 19.4 / 17.7 / 25.4 /” [tab:1 r3c6] |
| ~ | Posterior wall thickness at end-diastole (PWd) (TTE) | other | 17.7 | mm |  | HIGH | annual TTE, 2017 | “/ r3 / 2017 / 73% / 136.88 / 1.95 / 33.1 / 19.4 / 17.7 / 25.4 /” [tab:1 r3c7] |
| ~ | Ratio of early mitral inflow velocity to early diastolic tissue velocity (E/e’) (TTE) | other | 25.4 |  |  | UNKNOWN | annual TTE, 2017 | “/ r3 / 2017 / 73% / 136.88 / 1.95 / 33.1 / 19.4 / 17.7 / 25.4 /” [tab:1 r3c8] |
| ~ | Ejection fraction (TTE) | other | 67.0 | % |  | NORMAL | annual TTE, 2018 | “/ r4 / 2018 / 67% / 145.98 / 1.99 / 36.9 / 18.8 / 17.9 / – /” [tab:1 r4c2] |
| ~ | Left ventricular mass index (LVMI) (TTE) | other | 145.98 | g/m2 |  | HIGH | annual TTE, 2018 | “/ r4 / 2018 / 67% / 145.98 / 1.99 / 36.9 / 18.8 / 17.9 / – /” [tab:1 r4c3] |
| ~ | Body surface area | other | 1.99 | m2 |  | UNKNOWN | annual TTE, 2018 | “/ r4 / 2018 / 67% / 145.98 / 1.99 / 36.9 / 18.8 / 17.9 / – /” [tab:1 r4c4] |
| ~ | Left ventricular end-diastolic diameter (LVEDD) (TTE) | other | 36.9 | mm |  | UNKNOWN | annual TTE, 2018 | “/ r4 / 2018 / 67% / 145.98 / 1.99 / 36.9 / 18.8 / 17.9 / – /” [tab:1 r4c5] |
| ~ | Interventricular septal end-diastole (IVSd) thickness (TTE) | other | 18.8 | mm |  | HIGH | annual TTE, 2018 | “/ r4 / 2018 / 67% / 145.98 / 1.99 / 36.9 / 18.8 / 17.9 / – /” [tab:1 r4c6] |
| ~ | Posterior wall thickness at end-diastole (PWd) (TTE) | other | 17.9 | mm |  | HIGH | annual TTE, 2018 | “/ r4 / 2018 / 67% / 145.98 / 1.99 / 36.9 / 18.8 / 17.9 / – /” [tab:1 r4c7] |
| ~ | Ejection fraction (TTE) | other | 71.0 | % |  | NORMAL | annual TTE, 2019 | “/ r5 / 2019 / 71% / 155.10 / 1.99 / 33.7 / 21.4 / 19.1 / – /” [tab:1 r5c2] |
| ~ | Left ventricular mass index (LVMI) (TTE) | other | 155.1 | g/m2 |  | HIGH | annual TTE, 2019 | “/ r5 / 2019 / 71% / 155.10 / 1.99 / 33.7 / 21.4 / 19.1 / – /” [tab:1 r5c3] |
| ~ | Body surface area | other | 1.99 | m2 |  | UNKNOWN | annual TTE, 2019 | “/ r5 / 2019 / 71% / 155.10 / 1.99 / 33.7 / 21.4 / 19.1 / – /” [tab:1 r5c4] |
| ~ | Left ventricular end-diastolic diameter (LVEDD) (TTE) | other | 33.7 | mm |  | UNKNOWN | annual TTE, 2019 | “/ r5 / 2019 / 71% / 155.10 / 1.99 / 33.7 / 21.4 / 19.1 / – /” [tab:1 r5c5] |
| ~ | Interventricular septal end-diastole (IVSd) thickness (TTE) | other | 21.4 | mm |  | HIGH | annual TTE, 2019 | “/ r5 / 2019 / 71% / 155.10 / 1.99 / 33.7 / 21.4 / 19.1 / – /” [tab:1 r5c6] |
| ~ | Posterior wall thickness at end-diastole (PWd) (TTE) | other | 19.1 | mm |  | HIGH | annual TTE, 2019 | “/ r5 / 2019 / 71% / 155.10 / 1.99 / 33.7 / 21.4 / 19.1 / – /” [tab:1 r5c7] |
| ~ | Ejection fraction (TTE) | other | 65.0 | % |  | NORMAL | annual TTE, 2020 | “/ r6 / 2020 / 65% / 163.35 / 2.00 / 38.2 / 19.6 / 18.7 / 28.2 /” [tab:1 r6c2] |
| ~ | Left ventricular mass index (LVMI) (TTE) | other | 163.35 | g/m2 |  | HIGH | annual TTE, 2020 | “/ r6 / 2020 / 65% / 163.35 / 2.00 / 38.2 / 19.6 / 18.7 / 28.2 /” [tab:1 r6c3] |
| ~ | Body surface area | other | 2.0 | m2 |  | UNKNOWN | annual TTE, 2020 | “/ r6 / 2020 / 65% / 163.35 / 2.00 / 38.2 / 19.6 / 18.7 / 28.2 /” [tab:1 r6c4] |
| ~ | Left ventricular end-diastolic diameter (LVEDD) (TTE) | other | 38.2 | mm |  | UNKNOWN | annual TTE, 2020 | “/ r6 / 2020 / 65% / 163.35 / 2.00 / 38.2 / 19.6 / 18.7 / 28.2 /” [tab:1 r6c5] |
| ~ | Interventricular septal end-diastole (IVSd) thickness (TTE) | other | 19.6 | mm |  | HIGH | annual TTE, 2020 | “/ r6 / 2020 / 65% / 163.35 / 2.00 / 38.2 / 19.6 / 18.7 / 28.2 /” [tab:1 r6c6] |
| ~ | Posterior wall thickness at end-diastole (PWd) (TTE) | other | 18.7 | mm |  | HIGH | annual TTE, 2020 | “/ r6 / 2020 / 65% / 163.35 / 2.00 / 38.2 / 19.6 / 18.7 / 28.2 /” [tab:1 r6c7] |
| ~ | Ratio of early mitral inflow velocity to early diastolic tissue velocity (E/e’) (TTE) | other | 28.2 |  |  | UNKNOWN | annual TTE, 2020 | “/ r6 / 2020 / 65% / 163.35 / 2.00 / 38.2 / 19.6 / 18.7 / 28.2 /” [tab:1 r6c8] |
| ~ | Ejection fraction (TTE) | other | 66.0 | % |  | NORMAL | annual TTE, 2022 | “/ r7 / 2022 / 66% / 145.45 / 1.90 / 40.0 / 18.1 / 15.3 / – /” [tab:1 r7c2] |
| ~ | Left ventricular mass index (LVMI) (TTE) | other | 145.45 | g/m2 |  | HIGH | annual TTE, 2022 | “/ r7 / 2022 / 66% / 145.45 / 1.90 / 40.0 / 18.1 / 15.3 / – /” [tab:1 r7c3] |
| ~ | Body surface area | other | 1.9 | m2 |  | UNKNOWN | annual TTE, 2022 | “/ r7 / 2022 / 66% / 145.45 / 1.90 / 40.0 / 18.1 / 15.3 / – /” [tab:1 r7c4] |
| ~ | Left ventricular end-diastolic diameter (LVEDD) (TTE) | other | 40.0 | mm |  | UNKNOWN | annual TTE, 2022 | “/ r7 / 2022 / 66% / 145.45 / 1.90 / 40.0 / 18.1 / 15.3 / – /” [tab:1 r7c5] |
| ~ | Interventricular septal end-diastole (IVSd) thickness (TTE) | other | 18.1 | mm |  | HIGH | annual TTE, 2022 | “/ r7 / 2022 / 66% / 145.45 / 1.90 / 40.0 / 18.1 / 15.3 / – /” [tab:1 r7c6] |
| ~ | Posterior wall thickness at end-diastole (PWd) (TTE) | other | 15.3 | mm |  | HIGH | annual TTE, 2022 | “/ r7 / 2022 / 66% / 145.45 / 1.90 / 40.0 / 18.1 / 15.3 / – /” [tab:1 r7c7] |
| ~ | Ejection fraction (TTE) | other | 65.0 | % |  | NORMAL | annual TTE, 2023 | “/ r8 / 2023 / 65% / 131.30 / 1.90 / 38.6 / 17.3 / 15.0 / 17.5 /” [tab:1 r8c2] |
| ~ | Left ventricular mass index (LVMI) (TTE) | other | 131.3 | g/m2 |  | HIGH | annual TTE, 2023 | “/ r8 / 2023 / 65% / 131.30 / 1.90 / 38.6 / 17.3 / 15.0 / 17.5 /” [tab:1 r8c3] |
| ~ | Body surface area | other | 1.9 | m2 |  | UNKNOWN | annual TTE, 2023 | “/ r8 / 2023 / 65% / 131.30 / 1.90 / 38.6 / 17.3 / 15.0 / 17.5 /” [tab:1 r8c4] |
| ~ | Left ventricular end-diastolic diameter (LVEDD) (TTE) | other | 38.6 | mm |  | UNKNOWN | annual TTE, 2023 | “/ r8 / 2023 / 65% / 131.30 / 1.90 / 38.6 / 17.3 / 15.0 / 17.5 /” [tab:1 r8c5] |
| ~ | Interventricular septal end-diastole (IVSd) thickness (TTE) | other | 17.3 | mm |  | HIGH | annual TTE, 2023 | “/ r8 / 2023 / 65% / 131.30 / 1.90 / 38.6 / 17.3 / 15.0 / 17.5 /” [tab:1 r8c6] |
| ~ | Posterior wall thickness at end-diastole (PWd) (TTE) | other | 15.0 | mm |  | HIGH | annual TTE, 2023 | “/ r8 / 2023 / 65% / 131.30 / 1.90 / 38.6 / 17.3 / 15.0 / 17.5 /” [tab:1 r8c7] |
| ~ | Ratio of early mitral inflow velocity to early diastolic tissue velocity (E/e’) (TTE) | other | 17.5 |  |  | UNKNOWN | annual TTE, 2023 | “/ r8 / 2023 / 65% / 131.30 / 1.90 / 38.6 / 17.3 / 15.0 / 17.5 /” [tab:1 r8c8] |
| ~ | Ejection fraction (TTE) | other | 55.0 | % |  | NORMAL | annual TTE, 2024 | “/ r9 / 2024 / 55% / 146.65 / 1.76 / 43.0 / 15.0 / 15.0 / 15.4 /” [tab:1 r9c2] |
| ~ | Left ventricular mass index (LVMI) (TTE) | other | 146.65 | g/m2 |  | HIGH | annual TTE, 2024 | “/ r9 / 2024 / 55% / 146.65 / 1.76 / 43.0 / 15.0 / 15.0 / 15.4 /” [tab:1 r9c3] |
| ~ | Body surface area | other | 1.76 | m2 |  | UNKNOWN | annual TTE, 2024 | “/ r9 / 2024 / 55% / 146.65 / 1.76 / 43.0 / 15.0 / 15.0 / 15.4 /” [tab:1 r9c4] |
| ~ | Left ventricular end-diastolic diameter (LVEDD) (TTE) | other | 43.0 | mm |  | UNKNOWN | annual TTE, 2024 | “/ r9 / 2024 / 55% / 146.65 / 1.76 / 43.0 / 15.0 / 15.0 / 15.4 /” [tab:1 r9c5] |
| ~ | Interventricular septal end-diastole (IVSd) thickness (TTE) | other | 15.0 | mm |  | HIGH | annual TTE, 2024 | “/ r9 / 2024 / 55% / 146.65 / 1.76 / 43.0 / 15.0 / 15.0 / 15.4 /” [tab:1 r9c6] |
| ~ | Posterior wall thickness at end-diastole (PWd) (TTE) | other | 15.0 | mm |  | HIGH | annual TTE, 2024 | “/ r9 / 2024 / 55% / 146.65 / 1.76 / 43.0 / 15.0 / 15.0 / 15.4 /” [tab:1 r9c7] |
| ~ | Ratio of early mitral inflow velocity to early diastolic tissue velocity (E/e’) (TTE) | other | 15.4 |  |  | UNKNOWN | annual TTE, 2024 | “/ r9 / 2024 / 55% / 146.65 / 1.76 / 43.0 / 15.0 / 15.0 / 15.4 /” [tab:1 r9c8] |
| ~ | Ejection fraction (TTE) | other | 60.0 | % |  | NORMAL | annual TTE, 2025 | “/ r10 / 2025 / 60% / 97.30 / 1.84 / 38.7 / 14.8 / 10.8 / – /” [tab:1 r10c2] |
| ~ | Left ventricular mass index (LVMI) (TTE) | other | 97.3 | g/m2 |  | HIGH | annual TTE, 2025 | “/ r10 / 2025 / 60% / 97.30 / 1.84 / 38.7 / 14.8 / 10.8 / – /” [tab:1 r10c3] |
| ~ | Body surface area | other | 1.84 | m2 |  | UNKNOWN | annual TTE, 2025 | “/ r10 / 2025 / 60% / 97.30 / 1.84 / 38.7 / 14.8 / 10.8 / – /” [tab:1 r10c4] |
| ~ | Left ventricular end-diastolic diameter (LVEDD) (TTE) | other | 38.7 | mm |  | UNKNOWN | annual TTE, 2025 | “/ r10 / 2025 / 60% / 97.30 / 1.84 / 38.7 / 14.8 / 10.8 / – /” [tab:1 r10c5] |
| ~ | Interventricular septal end-diastole (IVSd) thickness (TTE) | other | 14.8 | mm |  | HIGH | annual TTE, 2025 | “/ r10 / 2025 / 60% / 97.30 / 1.84 / 38.7 / 14.8 / 10.8 / – /” [tab:1 r10c6] |
| ~ | Posterior wall thickness at end-diastole (PWd) (TTE) | other | 10.8 | mm |  | HIGH | annual TTE, 2025 | “/ r10 / 2025 / 60% / 97.30 / 1.84 / 38.7 / 14.8 / 10.8 / – /” [tab:1 r10c7] |

## Phenotypes

- ✓ Left ventricular hypertrophy → Left ventricular hypertrophy HP:0001712 (grounded)  
  “Prior CMR showed no features of either condition. The concentric LVH was therefore attributed to FD.” [sec:2 ¶6]
- ~ Left ventricular hypertrophy on ECG (voltage criteria) → Left ventricular hypertrophy HP:0001712 (grounded)  
  “Figure Figure 1: ECG – atrial fibrillation with left ventricular hypertrophy (voltage criteria).” [fig:1]
- ✓ Concentric left ventricular wall thickening from base to apex → –  (candidate)  
  “The most recent TTE showed a small LV with EF 60% and concentric wall thickening from base to apex, without systolic anterior motion of mitral valve (SAM), mid-cavity, or left ventricle outflow tract (LVOT) obstruction.” [sec:2 ¶5]
- ✓ Asymmetric septal hypertrophy → Asymmetric septal hypertrophy HP:0001670 (grounded)  
  “The last cardiac magnetic resonance (CMR) imaging in 2013 showed asymmetric septal hypertrophy with increased left ventricle mass (83 g/m2), and subtle plexiform enhancement in the basal septum and basal inferolateral segments.” [sec:2 ¶4]
- ✓ Myocardial late enhancement on cardiac MRI (subtle plexiform, basal septum and basal inferolateral segments) → –  (candidate)  
  “The last cardiac magnetic resonance (CMR) imaging in 2013 showed asymmetric septal hypertrophy with increased left ventricle mass (83 g/m2), and subtle plexiform enhancement in the basal septum and basal inferolateral segments.” [sec:2 ¶4]
- ✓ Atrial fibrillation → Atrial fibrillation HP:0005110 (grounded)  
  “Comorbidities included atrial fibrillation, hypertension, hyperlipidaemia, and type 2 diabetes mellitus.” [sec:2 ¶2]
- ✓ Hypertension → Hypertension HP:0000822 (grounded)  
  “Comorbidities included atrial fibrillation, hypertension, hyperlipidaemia, and type 2 diabetes mellitus.” [sec:2 ¶2]
- ✓ Hyperlipidemia → Hyperlipidemia HP:0003077 (grounded)  
  “Comorbidities included atrial fibrillation, hypertension, hyperlipidaemia, and type 2 diabetes mellitus.” [sec:2 ¶2]
- ✓ Type 2 diabetes mellitus → Type II diabetes mellitus HP:0005978 (grounded)  
  “Comorbidities included atrial fibrillation, hypertension, hyperlipidaemia, and type 2 diabetes mellitus.” [sec:2 ¶2]
- ✓ Ventricular tachycardia → Ventricular tachycardia HP:0004756 (grounded)  
  “An implantable cardioverter-defibrillator (ICD) (Boston Scientific D177) was inserted for non-sustained ventricular tachycardia in the setting of LVH.” [sec:2 ¶2]
- ✓ Chest pain → Chest pain HP:0100749 (grounded)  
  “She had recurrent emergency presentations with central chest pain at rest, occasionally with dyspnea and diaphoresis.” [sec:2 ¶1]
- ✓ Dyspnea → Dyspnea HP:0002094 (grounded)  
  “She had recurrent emergency presentations with central chest pain at rest, occasionally with dyspnea and diaphoresis.” [sec:2 ¶1]
- ✓ Diaphoresis → Hyperhidrosis HP:0000975 (grounded)  
  “She had recurrent emergency presentations with central chest pain at rest, occasionally with dyspnea and diaphoresis.” [sec:2 ¶1]
- ✓ Reduced exercise tolerance (400 to 500 m on flat ground) → –  (candidate)  
  “Exercise tolerance was 400 to 500 m on flat ground.” [sec:2 ¶1]
- ✓ Orthopnea → Orthopnea HP:0012764 (grounded)  
  “She remained independent in activities of daily living, with mild orthopnea and no paroxysmal nocturnal dyspnea.” [sec:2 ¶1]
- ✓ NOT Paroxysmal nocturnal dyspnea → Paroxysmal nocturnal dyspnea HP:0034807 (grounded)  
  “She remained independent in activities of daily living, with mild orthopnea and no paroxysmal nocturnal dyspnea.” [sec:2 ¶1]
- ✓ NOT Heart murmur → Heart murmur HP:0030148 (grounded)  
  “Her chest was clear, with dual heart sounds and no murmurs or heart failure signs.” [sec:2 ¶3]
- ✓ NOT Signs of heart failure → Congestive heart failure HP:0001635 (candidate)  
  “Her chest was clear, with dual heart sounds and no murmurs or heart failure signs.” [sec:2 ¶3]
- ✓ Pericardial effusion → Pericardial effusion HP:0001698 (grounded)  
  “A small circumferential pericardial effusion was present without tamponade. No significant valvular disease was seen.” [sec:2 ¶5]
- ✓ NOT Cardiac tamponade → Cardiac tamponade HP:0033415 (grounded)  
  “A small circumferential pericardial effusion was present without tamponade. No significant valvular disease was seen.” [sec:2 ¶5]
- ✓ NOT Significant valvular disease → –  (candidate)  
  “A small circumferential pericardial effusion was present without tamponade. No significant valvular disease was seen.” [sec:2 ¶5]
- ✓ Small left ventricle → –  (candidate)  
  “The most recent TTE showed a small LV with EF 60% and concentric wall thickening from base to apex, without systolic anterior motion of mitral valve (SAM), mid-cavity, or left ventricle outflow tract (LVOT) obstruction.” [sec:2 ¶5]
- ✓ NOT Systolic anterior motion of the mitral valve → Systolic anterior motion of the mitral valve HP:0031656 (grounded)  
  “The most recent TTE showed a small LV with EF 60% and concentric wall thickening from base to apex, without systolic anterior motion of mitral valve (SAM), mid-cavity, or left ventricle outflow tract (LVOT) obstruction.” [sec:2 ¶5]
- ✓ NOT Left ventricular mid-cavity obstruction → –  (candidate)  
  “The most recent TTE showed a small LV with EF 60% and concentric wall thickening from base to apex, without systolic anterior motion of mitral valve (SAM), mid-cavity, or left ventricle outflow tract (LVOT) obstruction.” [sec:2 ¶5]
- ✓ NOT Left ventricular outflow tract obstruction → Left ventricular outflow tract obstruction HP:0032092 (grounded)  
  “The most recent TTE showed a small LV with EF 60% and concentric wall thickening from base to apex, without systolic anterior motion of mitral valve (SAM), mid-cavity, or left ventricle outflow tract (LVOT) obstruction.” [sec:2 ¶5]
- ✓ NOT Reduced left ventricular ejection fraction → Reduced left ventricular ejection fraction HP:0012664 (grounded)  
  “Left ventricular systolic function remained preserved throughout follow-up, and there was no evidence of progressive structural deterioration.” [abstract]
- ✓ NOT Right ventricular dilatation → Right ventricular dilatation HP:0005133 (grounded)  
  “Right ventricle (RV) size was normal, with RV systolic pressure 21 mm Hg.” [sec:2 ¶5]
- ✓ Aortic valve sclerosis → –  (candidate)  
  “Aortic stenosis was excluded, with serial TTEs showing stable mild aortic sclerosis.” [sec:2 ¶6]
- ✓ NOT Aortic valve stenosis → Aortic valve stenosis HP:0001650 (grounded)  
  “Aortic stenosis was excluded, with serial TTEs showing stable mild aortic sclerosis.” [sec:2 ¶6]
- ✓ NOT Elevated right ventricular pressure → –  (candidate)  
  “Cardiac amyloidosis was unlikely due to absence of typical echocardiographic features (elevated RV pressure, apical sparing, biventricular hypertrophy, valve thickening; sensitivity 93%, specificity 82%) [4].” [sec:2 ¶6]
- ✓ NOT Apical sparing pattern on echocardiography → –  (candidate)  
  “Cardiac amyloidosis was unlikely due to absence of typical echocardiographic features (elevated RV pressure, apical sparing, biventricular hypertrophy, valve thickening; sensitivity 93%, specificity 82%) [4].” [sec:2 ¶6]
- ✓ NOT Biventricular hypertrophy → Biventricular hypertrophy HP:0200128 (grounded)  
  “Cardiac amyloidosis was unlikely due to absence of typical echocardiographic features (elevated RV pressure, apical sparing, biventricular hypertrophy, valve thickening; sensitivity 93%, specificity 82%) [4].” [sec:2 ¶6]
- ✓ NOT Cardiac valve thickening → –  (candidate)  
  “Cardiac amyloidosis was unlikely due to absence of typical echocardiographic features (elevated RV pressure, apical sparing, biventricular hypertrophy, valve thickening; sensitivity 93%, specificity 82%) [4].” [sec:2 ¶6]
- ✓ NOT Syncope → Syncope HP:0001279 (grounded)  
  “Hypertrophic cardiomyopathy was excluded due to lack of asymmetric hypertrophy, SAM, syncope, or family history.” [sec:2 ¶6]
- ✓ NOT Coronary artery disease (normal coronary angiography) → –  (candidate)  
  “Routine coronary angiography showed normal coronaries, unchanged from 9 years prior.” [sec:2 ¶5]
- ✓ Myocardial microvascular ischemia → –  (candidate)  
  “During an episode of chest pain, she was treated as acute coronary syndrome with dual antiplatelet therapy for elevated high-sensitivity troponin I; the chronic elevation was later attributed to stable FD-related microvascular ischemia.” [sec:2 ¶6]
- ~ NOT Cardiomegaly → Cardiomegaly HP:0001640 (grounded)  
  “Figure Figure 2: Chest X-ray – no cardiomegaly, intact implantable cardioverter-defibrillator leads, no pleural effusion.” [fig:2]
- ~ NOT Pleural effusion → Pleural effusion HP:0002202 (grounded)  
  “Figure Figure 2: Chest X-ray – no cardiomegaly, intact implantable cardioverter-defibrillator leads, no pleural effusion.” [fig:2]

## Treatments

- ✓ drug: migalastat · response improved  
  “Medications included candesartan 16 mg once a day, atenolol 50 mg twice a day, rivaroxaban 20 mg once a day, metformin 1 g twice a day, frusemide 40 mg once a day, ezetimibe 10 mg once a day, perindopril 5 mg once a day, and migalastat 123 mg a day, commenced in 2016.” [sec:2 ¶2]
- ✓ drug: candesartan · response not_stated  
  “Medications included candesartan 16 mg once a day, atenolol 50 mg twice a day, rivaroxaban 20 mg once a day, metformin 1 g twice a day, frusemide 40 mg once a day, ezetimibe 10 mg once a day, perindopril 5 mg once a day, and migalastat 123 mg a day, commenced in 2016.” [sec:2 ¶2]
- ✓ drug: atenolol · response not_stated  
  “Medications included candesartan 16 mg once a day, atenolol 50 mg twice a day, rivaroxaban 20 mg once a day, metformin 1 g twice a day, frusemide 40 mg once a day, ezetimibe 10 mg once a day, perindopril 5 mg once a day, and migalastat 123 mg a day, commenced in 2016.” [sec:2 ¶2]
- ✓ drug: rivaroxaban · response not_stated  
  “Medications included candesartan 16 mg once a day, atenolol 50 mg twice a day, rivaroxaban 20 mg once a day, metformin 1 g twice a day, frusemide 40 mg once a day, ezetimibe 10 mg once a day, perindopril 5 mg once a day, and migalastat 123 mg a day, commenced in 2016.” [sec:2 ¶2]
- ✓ drug: metformin · response not_stated  
  “Medications included candesartan 16 mg once a day, atenolol 50 mg twice a day, rivaroxaban 20 mg once a day, metformin 1 g twice a day, frusemide 40 mg once a day, ezetimibe 10 mg once a day, perindopril 5 mg once a day, and migalastat 123 mg a day, commenced in 2016.” [sec:2 ¶2]
- ✓ drug: frusemide · response not_stated  
  “Medications included candesartan 16 mg once a day, atenolol 50 mg twice a day, rivaroxaban 20 mg once a day, metformin 1 g twice a day, frusemide 40 mg once a day, ezetimibe 10 mg once a day, perindopril 5 mg once a day, and migalastat 123 mg a day, commenced in 2016.” [sec:2 ¶2]
- ✓ drug: ezetimibe · response not_stated  
  “Medications included candesartan 16 mg once a day, atenolol 50 mg twice a day, rivaroxaban 20 mg once a day, metformin 1 g twice a day, frusemide 40 mg once a day, ezetimibe 10 mg once a day, perindopril 5 mg once a day, and migalastat 123 mg a day, commenced in 2016.” [sec:2 ¶2]
- ✓ drug: perindopril · response not_stated  
  “Medications included candesartan 16 mg once a day, atenolol 50 mg twice a day, rivaroxaban 20 mg once a day, metformin 1 g twice a day, frusemide 40 mg once a day, ezetimibe 10 mg once a day, perindopril 5 mg once a day, and migalastat 123 mg a day, commenced in 2016.” [sec:2 ¶2]
- ✓ other: implantable cardioverter-defibrillator · response not_stated  
  “An implantable cardioverter-defibrillator (ICD) (Boston Scientific D177) was inserted for non-sustained ventricular tachycardia in the setting of LVH.” [sec:2 ¶2]
- ✓ supportive: fluid restriction · response not_stated  
  “She remained on long-term diuretics and a 1.5-L fluid restriction for prior pericardial effusion.” [sec:2 ¶2]
- ✓ drug: dual antiplatelet therapy · response not_stated  
  “During an episode of chest pain, she was treated as acute coronary syndrome with dual antiplatelet therapy for elevated high-sensitivity troponin I; the chronic elevation was later attributed to stable FD-related microvascular ischemia.” [sec:2 ¶6]

## Outcome

Alive at 9 years of migalastat therapy. LVMI declined overall (regression slope −6.52 g/m2 per year, 95% CI −11.3 to −1.7, P = 0.015; 97.30 g/m2 in 2025), systolic function remained preserved, E/e’ declined in later years, and comorbidities were well controlled.

## Model summary (not source text)

A 71-year-old woman was diagnosed with Fabry disease in 1995 by genetic testing showing a heterozygous GLA N224S (c.671A>G) missense variant, after evaluation of her son with classic Fabry disease. She had recurrent emergency presentations with central chest pain at rest, mild orthopnea, atrial fibrillation, hypertension, hyperlipidaemia, type 2 diabetes and an ICD for non-sustained ventricular tachycardia in the setting of left ventricular hypertrophy. Recent laboratory tests showed high-sensitivity troponin I 1857 ng/L (chronically, moderately elevated with stable trend and attributed to Fabry-related microvascular ischemia), BNP 202 ng/L, creatinine 89 μmol/L and eGFR 57 mL/min/1.73 m2; coronary angiography was normal. Cardiac MRI in 2013 showed asymmetric septal hypertrophy with increased LV mass (83 g/m2) and subtle late enhancement; the most recent TTE showed a small LV with EF 60%, concentric wall thickening, normal RV, RV systolic pressure 21 mm Hg and a small pericardial effusion. Hypertensive LVH, aortic stenosis and hypertrophic cardiomyopathy were excluded and cardiac amyloidosis considered unlikely, so the concentric LVH was attributed to Fabry disease. On migalastat 123 mg a day since 2016, serial TTE over 9 years showed an overall decline in LVMI from 176.20 to 97.30 g/m2 with preserved systolic function and a fall in E/e'.

## Extractor notes

- Age: abstract and introduction state '71-year-old'; the case report says 'a woman in her 70s'. P71Y is taken as age at last follow-up (time of report) and used for age_at_presentation as the recent examination; age at diagnosis (1995) and age at onset are not stated and were not estimated.
- The son with classic Fabry disease on ERT is mentioned only for context with no data of his own; recorded under family.relatives_in_paper.
- Laboratory specimen for troponin I, BNP, creatinine and eGFR is not stated (serum/plasma); recorded as 'blood'. Vital signs and imaging-derived numbers are recorded with specimen 'other'.
- No enzyme activity, lyso-Gb3 or Gb3 measurement is reported for this patient; the statement about reduced alpha-galactosidase A levels in sec:1 ¶1 refers to the N224S variant in general, not to this individual.
- BNP 202 ng/L, creatinine 89 μmol/L and eGFR 57 mL/min/1.73 m2 are given without reference ranges or author interpretation (authors only state 'renal function remained stable'); interpretation left UNKNOWN.
- Table 1 interpretations: EF marked NORMAL because authors state systolic function 'remained preserved throughout follow-up' (including the 55% value in 2024); LVMI, IVSd and PWd marked HIGH because authors report LVH/concentric wall thickening throughout; BSA, LVEDD and E/e' left UNKNOWN as no author interpretation is given. E/e' is missing ('–') for 2018, 2019, 2022 and 2025; no TTE for 2021 (COVID-19).
- Apparent conflict: CMR in 2013 showed 'asymmetric septal hypertrophy', whereas sec:2 ¶6 excludes hypertrophic cardiomyopathy due to 'lack of asymmetric hypertrophy' and the most recent TTE shows concentric thickening; both recorded as stated.
- The LVMI regression slope (−6.52 g/m2 per year, 95% CI −11.3 to −1.7, P = 0.015) is a derived statistic and is recorded in outcome.text rather than as a measurement.
- Variant classification 'pathogenic' is taken from the introduction's statement that the N224S variant 'is recognized as pathogenic' (sec:1 ¶1); the case report itself calls it a 'missense mutation'. Genetic testing method and transcript are not given.
- 'Hypertensive left ventricular hypertrophy' was an initial attribution later excluded by the authors; recorded as REVISED_FROM. Cardiac amyloidosis was called 'unlikely' rather than excluded, so recorded as DIFFERENTIAL.