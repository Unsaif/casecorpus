"""reconevidence CLI.

  reconevidence audit MODEL.mat --scope ~/Documents/casecorpus/casecorpus-work/scope --out reconevidence-work/recox
  reconevidence worklist reconevidence-work/recox            # IEM reactions with a GPR and no reference
  reconevidence goldset-uniprot GENES.txt --out reconevidence-work/goldset/uniprot.json
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import pandas as pd
import typer

from . import __version__

app = typer.Typer(add_completion=False, no_args_is_help=True, help=__doc__)


@app.command()
def audit(model: Path, scope: Optional[Path] = None, out: Path = Path("reconevidence-work/audit")):
    """Baseline audit of a .mat reconstruction (balance, dead ends, GPRs, annotations, IEM slice)."""
    from .audit import audit as _audit
    from .model import load_mat
    m = load_mat(model)
    res = _audit(m, scope)
    out.mkdir(parents=True, exist_ok=True)
    rx = res["reactions"].copy()
    rx["equation"] = [m.equation(j) for j in range(len(rx))]
    for c in ("genes", "iem_genes", "iem_diseases", "dead_end_mets", "imbalance"):
        rx[c] = rx[c].map(lambda v: json.dumps(v) if isinstance(v, (list, dict)) else v)
    rx.to_csv(out / "reactions.csv", index=False)
    rx.to_parquet(out / "reactions.parquet", index=False)
    res["dead_ends"].to_csv(out / "dead_end_metabolites.csv", index=False)
    m.metabolites.to_csv(out / "metabolites.csv", index=False)
    (out / "summary.json").write_text(json.dumps(res["summary"], indent=1, default=str))
    typer.echo(json.dumps(res["summary"], indent=1, default=str))


@app.command()
def worklist(audit_dir: Path, all_reactions: bool = False, limit: Optional[int] = None):
    """Reactions the evidence layer should read the literature for first."""
    from .audit import worklist as _wl
    rx = pd.read_parquet(audit_dir / "reactions.parquet")
    for c in ("genes", "iem_genes", "iem_diseases"):
        rx[c] = rx[c].map(lambda v: json.loads(v) if isinstance(v, str) else v)
    w = _wl(rx, iem_only=not all_reactions)
    if limit:
        w = w.head(limit)
    w.to_csv(audit_dir / "worklist.csv", index=False)
    typer.echo(f"{len(w)} reactions -> {audit_dir / 'worklist.csv'}")


@app.command()
def goldset_uniprot(genes_file: Path, out: Path = Path("reconevidence-work/goldset/uniprot.json")):
    """UniProt catalytic-activity gold set for a list of gene symbols (needs rest.uniprot.org)."""
    from .goldset.uniprot import build_goldset
    genes = [l.strip() for l in genes_file.read_text().splitlines() if l.strip()]
    typer.echo(json.dumps(build_goldset(genes, out), indent=1))


if __name__ == "__main__":  # pragma: no cover
    app()
