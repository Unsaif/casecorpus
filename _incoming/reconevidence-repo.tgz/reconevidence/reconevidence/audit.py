"""Baseline audit of a reconstruction: what do we know about each reaction before any literature is read?

Per reaction: kind, subsystem, GPR present, genes, mass/charge balance, dead-end involvement, existing
annotations (EC, KEGG, references) when the model carries them, IEM flag (gene in the casecorpus IEM
scope or subsystem tagged IMD). The result is the worklist for the evidence layer: reactions with no
citation are exactly the ones literature mining should try to support or contradict.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd

from .checks.balance import check_balance
from .checks.structure import dead_end_metabolites, topologically_blocked_reactions
from .model import Model, genes_of


def load_scope_genes(scope_dir: Path | None) -> set[str]:
    if not scope_dir:
        return set()
    p = Path(scope_dir) / "genes.txt"
    return {l.strip() for l in p.read_text().splitlines() if l.strip()} if p.exists() else set()


def load_scope_gene_diseases(scope_dir: Path | None) -> dict[str, list[str]]:
    """gene symbol -> disease labels (from casecorpus scope.json)."""
    if not scope_dir or not (Path(scope_dir) / "scope.json").exists():
        return {}
    scope = json.load(open(Path(scope_dir) / "scope.json"))
    out: dict[str, list[str]] = {}
    for d in scope["diseases"]:
        for g in d.get("genes", []):
            out.setdefault(g, []).append(d["label"])
    return out


def audit(model: Model, scope_dir: Path | None = None) -> dict[str, Any]:
    rx = model.reactions.copy()
    rx["genes"] = rx["gpr"].map(lambda g: sorted(genes_of(g)) if g else [])
    rx["n_genes"] = rx["genes"].map(len)
    scope_genes = load_scope_genes(scope_dir)
    gene_dis = load_scope_gene_diseases(scope_dir)
    rx["iem_genes"] = rx["genes"].map(lambda gs: [g for g in gs if g in scope_genes])
    rx["iem_subsystem"] = rx["subsystem"].str.contains("IMD|IEM|inborn", case=False, regex=True)
    rx["iem"] = (rx["iem_genes"].map(len) > 0) | rx["iem_subsystem"]
    rx["iem_diseases"] = rx["iem_genes"].map(lambda gs: sorted({d for g in gs for d in gene_dis.get(g, [])})[:6])

    bal = check_balance(model).set_index("id")
    rx = rx.join(bal[["mass_status", "imbalance", "charge_status", "charge_balance", "only_H_imbalance"]], on="id")
    de = dead_end_metabolites(model)
    blocked = topologically_blocked_reactions(model, de).set_index("id")
    rx = rx.join(blocked[["blocked_by_dead_end", "dead_end_mets"]], on="id")

    ref_col = next((c for c in rx.columns if c in ("ann_rxnReferences", "ann_rxnNotes")), None)
    rx["has_reference"] = rx[ref_col].str.strip().ne("") if ref_col else False
    ec_col = next((c for c in rx.columns if c == "ann_rxnECNumbers"), None)
    rx["has_ec"] = rx[ec_col].str.strip().ne("") if ec_col else False

    internal = rx[rx["kind"].isin(["internal", "transport"])]
    summary = {
        **model.summary(),
        "internal_or_transport": len(internal),
        "no_gpr": int((internal["gpr"] == "").sum()),
        "mass_balanced": int((internal["mass_status"] == "balanced").sum()),
        "mass_unbalanced": int((internal["mass_status"] == "unbalanced").sum()),
        "mass_unbalanced_only_H": int(internal["only_H_imbalance"].fillna(False).sum()),
        "mass_generic": int((internal["mass_status"] == "generic").sum()),
        "charge_unbalanced": int((internal["charge_status"] == "unbalanced").sum()),
        "dead_end_metabolites": int((de["status"] == "dead_end").sum()),
        "orphan_metabolites": int((de["status"] == "orphan").sum()),
        "reactions_blocked_by_dead_end": int(internal["blocked_by_dead_end"].fillna(False).sum()),
        "has_reference_annotation": int(internal["has_reference"].sum()) if ref_col else None,
        "has_ec_annotation": int(internal["has_ec"].sum()) if ec_col else None,
        "iem_scope_genes_in_model": len(scope_genes & set(model.genes)) if scope_genes else None,
        "iem_reactions": int(internal["iem"].sum()),
        "iem_reactions_by_gene": int((internal["iem_genes"].map(len) > 0).sum()),
        "iem_reactions_unbalanced": int(((internal["iem"]) & (internal["mass_status"] == "unbalanced")).sum()),
        "iem_reactions_blocked_by_dead_end": int(((internal["iem"]) & internal["blocked_by_dead_end"].fillna(False)).sum()),
        "iem_reactions_no_gpr": int(((internal["iem_subsystem"]) & (internal["gpr"] == "")).sum()),
    }
    return {"summary": summary, "reactions": rx, "dead_ends": de}


def worklist(rx: pd.DataFrame, iem_only: bool = True) -> pd.DataFrame:
    """Reactions that the evidence layer should look at first: IEM-related, internal/transport, with a GPR
    (so that a literature query can be built from gene/enzyme names) and no existing reference."""
    w = rx[rx["kind"].isin(["internal", "transport"]) & (rx["gpr"] != "")]
    if iem_only:
        w = w[w["iem"]]
    if "has_reference" in w:
        w = w[~w["has_reference"].fillna(False)]
    cols = ["id", "name", "kind", "subsystem", "gpr", "iem_genes", "iem_diseases", "mass_status", "charge_status", "blocked_by_dead_end"]
    return w[cols].reset_index(drop=True)
