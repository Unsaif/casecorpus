"""Elemental mass and charge balance from model formulas/charges (no external chemistry needed).

Formulas may contain generic groups (R, X, FULLR, *) — such reactions are reported as 'generic'
rather than balanced/unbalanced. Charge balance uses metCharges.
"""
from __future__ import annotations

import re
from collections import Counter
from typing import Any

import pandas as pd

from ..model import Model

_TOKEN = re.compile(r"([A-Z][a-z]?)(\d+\.\d+|\d+)?")
_GENERIC = re.compile(r"FULLR|R\d*(?![a-z])|X\d*(?![a-z])|\*|(?<![A-Za-z])Z(?![a-z])")


def parse_formula(f: str) -> tuple[Counter, bool]:
    """Return (element counts, is_generic)."""
    f = (f or "").strip()
    if not f:
        return Counter(), True
    generic = bool(_GENERIC.search(f))
    cleaned = _GENERIC.sub("", f)
    counts: Counter = Counter()
    pos = 0
    for m in _TOKEN.finditer(cleaned):
        el, num = m.group(1), m.group(2)
        counts[el] += float(num) if num else 1.0  # noqa
        pos = m.end()
    return counts, generic


def check_balance(model: Model, kinds: tuple[str, ...] = ("internal", "transport"), tol: float = 1e-6) -> pd.DataFrame:
    mets = model.metabolites
    formulas = {mid: parse_formula(f) for mid, f in zip(mets["id"], mets["formula"])}
    charges = dict(zip(mets["id"], mets["charge"]))
    rows = []
    for j, r in model.reactions.iterrows():
        if r["kind"] not in kinds:
            continue
        st = model.stoichiometry(j)
        total: Counter = Counter()
        generic = False
        charge = 0.0
        charge_ok = True
        for mid, coef in st.items():
            cnt, g = formulas[mid]
            generic |= g
            for el, n in cnt.items():
                total[el] += coef * n
            c = charges.get(mid)
            if c is None or pd.isna(c):
                charge_ok = False
            else:
                charge += coef * c
        imbalance = {el: round(v, 4) for el, v in total.items() if abs(v) > tol}
        status = "generic" if generic else ("balanced" if not imbalance else "unbalanced")
        rows.append({"id": r["id"], "kind": r["kind"], "subsystem": r["subsystem"], "mass_status": status, "imbalance": imbalance,
                     "charge_balance": (round(charge, 4) if charge_ok else None), "charge_status": ("unknown" if not charge_ok else ("balanced" if abs(charge) < tol else "unbalanced")),
                     "only_H_imbalance": status == "unbalanced" and set(imbalance) <= {"H"}})
    return pd.DataFrame(rows)
