"""Structural network checks that need no solver: dead-end metabolites, orphan/single-reaction
metabolites, reactions that cannot carry flux for purely topological reasons.

(Flux-based checks — blocked reactions via FVA, energy-generating cycles, ATP-from-nothing — live in
checks/flux.py and need cobrapy + a solver; they are run on the user's machine.)
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import scipy.sparse as sp

from ..model import Model


def dead_end_metabolites(model: Model) -> pd.DataFrame:
    """A metabolite is a dead end if, considering reaction reversibility, it can only be produced or
    only consumed by the model's reactions (exchanges/demands/sinks included, since they are real outlets)."""
    S = sp.csr_matrix(model.S)
    lb = model.reactions["lb"].to_numpy()
    ub = model.reactions["ub"].to_numpy()
    rows = []
    for i in range(S.shape[0]):
        row = S.getrow(i)
        can_produce = can_consume = False
        n_rxn = len(row.indices)
        for j, v in zip(row.indices, row.data):
            fwd, rev = ub[j] > 0, lb[j] < 0
            if (v > 0 and fwd) or (v < 0 and rev):
                can_produce = True
            if (v < 0 and fwd) or (v > 0 and rev):
                can_consume = True
        rows.append({"id": model.metabolites.iloc[i]["id"], "name": model.metabolites.iloc[i]["name"], "n_reactions": n_rxn,
                     "can_produce": can_produce, "can_consume": can_consume,
                     "status": "orphan" if n_rxn == 0 else ("dead_end" if not (can_produce and can_consume) else "ok")})
    return pd.DataFrame(rows)


def topologically_blocked_reactions(model: Model, dead_ends: pd.DataFrame) -> pd.DataFrame:
    """Reactions touching a dead-end metabolite cannot carry steady-state flux (necessary, not sufficient)."""
    de = set(dead_ends.loc[dead_ends["status"] != "ok", "id"])
    S = sp.csc_matrix(model.S)
    met_ids = model.metabolites["id"].to_numpy()
    rows = []
    for j, r in model.reactions.iterrows():
        touched = [met_ids[i] for i in S.getcol(j).indices if met_ids[i] in de]
        rows.append({"id": r["id"], "kind": r["kind"], "subsystem": r["subsystem"], "blocked_by_dead_end": bool(touched), "dead_end_mets": touched})
    return pd.DataFrame(rows)
