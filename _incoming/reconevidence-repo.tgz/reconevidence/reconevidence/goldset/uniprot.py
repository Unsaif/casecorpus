"""Gold set from UniProt: catalytic-activity annotations with Rhea ids and PubMed evidence.

For each human gene symbol, UniProt (reviewed, human) lists "Catalytic activity" comments with a Rhea
reaction id and evidence codes that cite PMIDs (ECO:0000269 = experimental, ECO:0000305 = curator
inference, ECO:0000250 = by similarity ...). That gives (gene, protein, Rhea reaction, PMID, ECO)
tuples: a curated set of literature-backed reaction claims to measure the claim extractor against,
and a direct source of evidence for the reconstruction's reactions.

Runs where rest.uniprot.org is reachable (the user's machine); the same query can be executed through
the Cowork browser pane for small pilots (see scripts/uniprot_browser.js).
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Iterable

import requests

UNIPROT = "https://rest.uniprot.org/uniprotkb/search"
FIELDS = "accession,gene_primary,protein_name,ec,cc_catalytic_activity,cc_subcellular_location,xref_rhea,lit_pubmed_id"


def query_for_genes(genes: Iterable[str], batch: int = 25) -> Iterable[dict[str, Any]]:
    genes = list(genes)
    s = requests.Session()
    for i in range(0, len(genes), batch):
        chunk = genes[i:i + batch]
        q = "(organism_id:9606) AND (reviewed:true) AND (" + " OR ".join(f"gene_exact:{g}" for g in chunk) + ")"
        r = s.get(UNIPROT, params={"query": q, "fields": FIELDS, "format": "json", "size": 500}, timeout=120)
        r.raise_for_status()
        for e in r.json().get("results", []):
            yield e
        time.sleep(0.3)


def parse_entry(e: dict[str, Any]) -> list[dict[str, Any]]:
    """Flatten one UniProt entry into (gene, accession, rhea, ec, pmid, eco) rows."""
    gene = next((g["geneName"]["value"] for g in e.get("genes", []) if "geneName" in g), None)
    acc = e.get("primaryAccession")
    rows = []
    for c in e.get("comments", []):
        if c.get("commentType") != "CATALYTIC ACTIVITY":
            continue
        rxn = c.get("reaction", {})
        rhea = [x["id"] for x in rxn.get("reactionCrossReferences", []) if x.get("database") == "Rhea" and x["id"].startswith("RHEA:")]
        ec = rxn.get("ecNumber")
        evs = rxn.get("evidences", []) or []
        if not evs:
            rows.append({"gene": gene, "accession": acc, "rhea": rhea[0] if rhea else None, "rhea_all": rhea, "ec": ec, "equation": rxn.get("name"), "pmid": None, "eco": None})
        for ev in evs:
            rows.append({"gene": gene, "accession": acc, "rhea": rhea[0] if rhea else None, "rhea_all": rhea, "ec": ec, "equation": rxn.get("name"),
                         "pmid": ev.get("id") if ev.get("source") == "PubMed" else None, "eco": ev.get("evidenceCode")})
    return rows


def build_goldset(genes: Iterable[str], out: Path) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    n_entries = 0
    for e in query_for_genes(genes):
        n_entries += 1
        rows.extend(parse_entry(e))
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rows, indent=1))
    pm = {r["pmid"] for r in rows if r["pmid"]}
    return {"entries": n_entries, "claims": len(rows), "with_rhea": sum(1 for r in rows if r["rhea"]), "with_pmid": sum(1 for r in rows if r["pmid"]),
            "unique_pmids": len(pm), "experimental_ECO0000269": sum(1 for r in rows if r["eco"] == "ECO:0000269")}
