"""Load a COBRA-style MATLAB reconstruction (.mat) into plain tables, without requiring cobrapy.

Works with Recon3D / Recon4IMD / RecoX / AGORA-style structs: fields rxns, rxnNames, S, lb, ub,
grRules (or rules), subSystems, mets, metNames, metFormulas, metCharges, genes; optional annotation
fields (rxnECNumbers, rxnKEGGID, rxnReferences, rxnNotes, metCHEBIID, metInChIString, metHMDBID ...)
are picked up when present.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import scipy.io
import scipy.sparse as sp

_OPTIONAL_RXN = ["rxnECNumbers", "rxnKEGGID", "rxnKeggID", "rxnReferences", "rxnNotes", "rxnConfidenceScores", "rxnReconMap", "rxnSBOTerms", "rxnMetaNetXID", "rxnRheaID", "rxnSEEDID", "rxnBiGGID", "rxnCOG", "rxnKeggOrthology", "rxnEnzymes"]
_OPTIONAL_MET = ["metCHEBIID", "metChEBIID", "metInChIString", "metInchiString", "metHMDBID", "metKEGGID", "metPubChemID", "metSmiles", "metSMILES", "metMetaNetXID", "metBiGGID", "metSEEDID", "metPdMap", "metReconMap"]


def _s(x: Any) -> str:
    if x is None:
        return ""
    if isinstance(x, (list, tuple, np.ndarray)):
        return "; ".join(_s(i) for i in x)
    s = str(x)
    return "" if s in ("nan", "[]") else s


@dataclass
class Model:
    id: str
    name: str
    reactions: pd.DataFrame
    metabolites: pd.DataFrame
    genes: list[str]
    S: sp.csc_matrix
    compartments: dict[str, str] = field(default_factory=dict)
    source: str = ""

    def stoichiometry(self, rxn_index: int) -> dict[str, float]:
        col = self.S.getcol(rxn_index)
        return {self.metabolites.iloc[i]["id"]: float(v) for i, v in zip(col.indices, col.data)}

    def equation(self, rxn_index: int, names: bool = False) -> str:
        st = self.stoichiometry(rxn_index)
        key = "name" if names else "id"
        lookup = dict(zip(self.metabolites["id"], self.metabolites[key]))
        lhs = [f"{-c:g} {lookup[m]}" if c != -1 else lookup[m] for m, c in st.items() if c < 0]
        rhs = [f"{c:g} {lookup[m]}" if c != 1 else lookup[m] for m, c in st.items() if c > 0]
        r = self.reactions.iloc[rxn_index]
        arrow = "<=>" if r["lb"] < 0 < r["ub"] else ("-->" if r["ub"] > 0 else "<--")
        return f"{' + '.join(lhs)} {arrow} {' + '.join(rhs)}"

    def summary(self) -> dict[str, Any]:
        rx = self.reactions
        return {
            "model": self.id, "name": self.name, "reactions": len(rx), "metabolites": len(self.metabolites), "genes": len(self.genes),
            "exchange_like": int(rx["kind"].isin(["exchange", "demand", "sink"]).sum()), "transport": int((rx["kind"] == "transport").sum()),
            "internal": int((rx["kind"] == "internal").sum()), "with_gpr": int((rx["gpr"] != "").sum()),
            "reversible": int(((rx["lb"] < 0) & (rx["ub"] > 0)).sum()), "subsystems": int(rx["subsystem"].nunique()),
            "annotation_fields": [c for c in rx.columns if c.startswith("ann_")] + [c for c in self.metabolites.columns if c.startswith("ann_")],
        }


def _find_struct(mat: dict[str, Any]) -> tuple[str, Any]:
    for k, v in mat.items():
        if k.startswith("__"):
            continue
        if hasattr(v, "_fieldnames") and "rxns" in v._fieldnames:
            return k, v
    raise ValueError("no COBRA model struct found in .mat file")


def load_mat(path: str | Path) -> Model:
    mat = scipy.io.loadmat(str(path), squeeze_me=True, struct_as_record=False)
    key, m = _find_struct(mat)
    rxns = [_s(x) for x in np.atleast_1d(m.rxns)]
    n = len(rxns)
    get = lambda f, default: getattr(m, f) if f in m._fieldnames else default  # noqa: E731
    gpr_field = "grRules" if "grRules" in m._fieldnames else None
    gprs = [_s(x) for x in np.atleast_1d(get(gpr_field, [""] * n))] if gpr_field else [""] * n
    genes = [_s(x) for x in np.atleast_1d(get("genes", []))]
    if not gpr_field and "rules" in m._fieldnames:  # x(12) style rules -> gene symbols
        rules = [_s(x) for x in np.atleast_1d(m.rules)]
        gprs = [re.sub(r"x\((\d+)\)", lambda mm: genes[int(mm.group(1)) - 1], r).replace("&", "and").replace("|", "or") for r in rules]
    subs = [_s(x) for x in np.atleast_1d(get("subSystems", [""] * n))]
    lb = np.asarray(get("lb", np.full(n, -1000.0)), dtype=float).reshape(-1)
    ub = np.asarray(get("ub", np.full(n, 1000.0)), dtype=float).reshape(-1)
    S = sp.csc_matrix(m.S)
    mets = [_s(x) for x in np.atleast_1d(m.mets)]

    def kind(rid: str, j: int) -> str:
        if rid.startswith("EX_"):
            return "exchange"
        if rid.startswith("DM_"):
            return "demand"
        if rid.lower().startswith("sink_") or rid.startswith("SK_"):
            return "sink"
        comps = {re.search(r"\[([a-z])\]$", mets[i]).group(1) for i in S.getcol(j).indices if re.search(r"\[([a-z])\]$", mets[i])}
        return "transport" if len(comps) > 1 else "internal"

    rx = pd.DataFrame({
        "id": rxns, "name": [_s(x) for x in np.atleast_1d(get("rxnNames", rxns))], "subsystem": subs, "gpr": gprs, "lb": lb, "ub": ub,
        "kind": [kind(r, j) for j, r in enumerate(rxns)],
    })
    for f in _OPTIONAL_RXN:
        if f in m._fieldnames:
            rx["ann_" + f] = [_s(x) for x in np.atleast_1d(getattr(m, f))]
    charges = get("metCharges", None)
    md = pd.DataFrame({
        "id": mets, "name": [_s(x) for x in np.atleast_1d(get("metNames", mets))],
        "formula": [_s(x) for x in np.atleast_1d(get("metFormulas", [""] * len(mets)))],
        "charge": np.asarray(charges, dtype=float).reshape(-1) if charges is not None else np.full(len(mets), np.nan),
        "compartment": [re.search(r"\[([a-z])\]$", x).group(1) if re.search(r"\[([a-z])\]$", x) else "" for x in mets],
    })
    md["base_id"] = md["id"].str.replace(r"\[[a-z]\]$", "", regex=True)
    for f in _OPTIONAL_MET:
        if f in m._fieldnames:
            md["ann_" + f] = [_s(x) for x in np.atleast_1d(getattr(m, f))]
    comps = dict(zip([_s(x) for x in np.atleast_1d(get("comps", []))], [_s(x) for x in np.atleast_1d(get("compNames", []))]))
    return Model(id=_s(get("modelID", key)), name=_s(get("modelName", key)), reactions=rx, metabolites=md, genes=genes, S=S, compartments=comps, source=str(path))


def genes_of(gpr: str) -> set[str]:
    return {g for g in re.split(r"[\s()]+", gpr.replace(" and ", " ").replace(" or ", " ")) if g and g.lower() not in ("and", "or")}
