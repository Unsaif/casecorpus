"""reconevidence — the assertion layer for metabolic reconstructions.

Literature claims (from casecorpus) are checked against chemistry (structures, mass/charge balance,
reaction identity), thermodynamics, gene-protein-reaction rules and the model itself before they
become evidence-coded assertions over a reconstruction.
"""

__version__ = "0.1.0"
