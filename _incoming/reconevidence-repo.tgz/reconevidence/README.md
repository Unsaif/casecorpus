# reconevidence

The **assertion layer** for metabolic reconstructions. `casecorpus` turns papers into verbatim-anchored
*claims* (reactions, transport, localization, presence/absence, kinetics); `reconevidence` decides what
a reconstruction should *believe*: it resolves structures, checks mass/charge balance, maps reactions to
Rhea/VMH, tests thermodynamics and GPRs, runs the model, and writes evidence-coded assertions over
Recon/AGORA-style models. Nothing crosses from claims to the model without passing the checks.

## What exists now (v0.1)

| Piece | Status |
|---|---|
| `model.py` — load COBRA `.mat` (Recon3D / Recon4IMD / RecoX / AGORA) into tables without cobrapy | working |
| `checks/balance.py` — elemental mass + charge balance from model formulas, generic-group aware | working |
| `checks/structure.py` — dead-end metabolites, topologically blocked reactions | working |
| `audit.py` + `reconevidence audit` — baseline audit + IEM slice (via casecorpus scope genes) + worklist | working |
| `goldset/uniprot.py` — UniProt catalytic-activity claims (Rhea + PMID + ECO) for a gene list | written, needs network (run on your machine) |
| `casecorpus/schema/reaction_claim.schema.json` — the claim schema (in the casecorpus repo) | v0.1 draft |
| structure resolution (ChEBI/PubChem/OPSIN → InChIKey → VMH), Rhea/MetaNetX mapping, thermodynamics (eQuilibrator), flux checks (cobrapy: FVA, energy-generating cycles), claim → assertion ingest | to do |

## First result: baseline audit of RecoX (10 Sept 2026)

`reconevidence audit recox.mat --scope <casecorpus scope>` on the RecoX file (22,417 reactions, 13,637
metabolites, 3,402 genes; no annotation fields in the file):

- 19,965 internal/transport reactions; 4,887 without a GPR; 655 dead-end metabolites; 616 reactions
  blocked by a dead end; 1,020 charge-unbalanced; **2,781 mass-unbalanced**.
- 658 of the 1,225 IEM-scope genes are in the model; 8,198 reactions are IEM-related (5,333 by gene).
- Tracing the imbalance patterns to their shared metabolites found **three wrong cofactor formulas**:
  free coenzyme A carries a C5 enoyl-CoA formula (`C26H38N7O17P3S`, identical to tiglyl-CoA) instead of
  `C21H32N7O16P3S`; L-carnitine carries 5-hydroxyhexanoylcarnitine's formula (`C13H25NO5`) instead of
  `C7H15NO3`; PAPS carries PAP's formula (`C10H11N5O10P2`, missing SO3). Correcting CoA and carnitine
  alone takes mass-unbalanced reactions from 2,781 to 547; PAPS accounts for 145 of the rest and most of
  the remainder are single-proton imbalances. Details: `docs/audit-recox-2026-09-10.md`,
  `reconevidence-work/audit-recox/`.

## Install

```bash
pip install -e .            # pulls casecorpus from GitHub
pip install -e '.[chem]'    # rdkit, cobrapy, equilibrator for the check chain
reconevidence audit path/to/model.mat --scope ~/Documents/casecorpus/casecorpus-work/scope --out reconevidence-work/audit
reconevidence worklist reconevidence-work/audit
reconevidence goldset-uniprot reconevidence-work/audit/iem_genes.txt
```

## Design

See the project document *design/02-reconstruction-evidence.md* (claim layer vs assertion layer,
claim types, check chain, gold sets, workstreams). Short version: literature is one evidence stream;
chemistry and the model are the truth; the model proposes, tools decide, curators sign.
